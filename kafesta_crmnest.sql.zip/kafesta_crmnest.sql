-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 22, 2021 at 02:02 AM
-- Server version: 10.3.30-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kafesta_crmnest`
--

-- --------------------------------------------------------

--
-- Table structure for table `a_c_m_s`
--

CREATE TABLE `a_c_m_s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `a_c_m_s`
--

INSERT INTO `a_c_m_s` (`id`, `name`, `created_at`, `updated_at`) VALUES
(4, 'No Asbestos Identified', '2020-09-22 17:52:20', '2020-09-22 17:52:20'),
(5, 'Sample Taken', '2020-09-22 17:52:27', '2020-09-22 17:52:27'),
(6, 'Potential Asbestos Containing Material Identified', '2020-09-22 17:52:36', '2020-09-22 17:52:36');

-- --------------------------------------------------------

--
-- Table structure for table `boilerchoises`
--

CREATE TABLE `boilerchoises` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boiler_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `boilerchoises`
--

INSERT INTO `boilerchoises` (`id`, `name`, `boiler_id`, `created_at`, `updated_at`) VALUES
(11, 'First Regular Boiler Choice', 1, '2020-09-03 01:05:22', '2020-09-03 01:05:22'),
(12, 'Second Regular Boiler Choice', 1, '2020-09-03 01:05:22', '2020-09-03 01:05:22'),
(13, 'Third Regular Boiler Choice', 1, '2020-09-03 01:05:22', '2020-09-03 01:05:22'),
(14, 'First System Boiler Choice', 2, '2020-09-03 01:05:46', '2020-09-03 01:05:46'),
(15, 'Second System Boiler Choice', 2, '2020-09-03 01:05:46', '2020-09-03 01:05:46'),
(16, 'Third System Boiler Choice', 2, '2020-09-03 01:05:46', '2020-09-03 01:05:46'),
(17, 'First Combi Boiler Choice', 3, '2020-09-03 01:06:08', '2020-09-03 01:06:08'),
(18, 'Second Combi Boiler Choice', 3, '2020-09-03 01:06:08', '2020-09-03 01:06:08'),
(19, 'Third Combi Boiler Choice', 3, '2020-09-03 01:06:08', '2020-09-03 01:06:08'),
(20, 'First Combi Boiler Choice', 4, '2020-09-03 01:07:09', '2020-09-03 01:07:09'),
(21, 'Second Combi Boiler Choice', 4, '2020-09-03 01:07:09', '2020-09-03 01:07:09'),
(22, 'Third Combi Boiler Choice', 4, '2020-09-03 01:07:09', '2020-09-03 01:07:09');

-- --------------------------------------------------------

--
-- Table structure for table `boilers`
--

CREATE TABLE `boilers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `boilers`
--

INSERT INTO `boilers` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Regular', NULL, NULL),
(2, 'System', NULL, NULL),
(3, 'Combi', NULL, NULL),
(4, 'Electric', NULL, NULL),
(5, 'Oil', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `boilertypechildrens`
--

CREATE TABLE `boilertypechildrens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boilerchoise_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `boilertypes`
--

CREATE TABLE `boilertypes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boilertype` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `boilerchoise_id` int(11) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warranty` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apr1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalpay1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apr2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalpay2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apr3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalpay3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `boilertypes`
--

INSERT INTO `boilertypes` (`id`, `company`, `boilertype`, `price`, `boilerchoise_id`, `image`, `warranty`, `apr1`, `duration1`, `totalpay1`, `monthly1`, `apr2`, `duration2`, `totalpay2`, `monthly2`, `apr3`, `duration3`, `totalpay3`, `monthly3`, `created_at`, `updated_at`) VALUES
(265, 'Viessmann', 'Viessmann Vitodens 100-W Compact 13 kW', 2241, 1, 'public/storage/uploadimage/1619756398144.jpg', '5', '8.2%', '120', '3240', '27', '8.2%', '60', '2760', '46', '0%', '12', '2240.75', '187', '2020-10-21 19:06:55', '2021-04-30 17:03:59'),
(266, 'Viessmann', 'Viessmann Vitodens 100-W Compact 16 kW', 2280, 1, 'public/storage/uploadimage/1619756578195.jpg', '5', '8.2%', '120', '3360', '28', '8.2%', '60', '2760', '46', '0%', '12', '2279.75', '190', '2020-10-21 19:07:47', '2021-04-30 17:04:31'),
(272, 'Ideal', 'Ideal Logic Plus System S15 ERP', 2294, 2, 'public/storage/uploadimage/1619759613114.2', '2', '8.2%', '120', '3360', '28', '8.2%', '60', '2820', '47', '0%', '12', '2293.56', '191', '2020-10-21 19:14:45', '2021-04-30 17:05:01'),
(281, 'Viessmann', 'Viessmann Vitodens 100-W Compact 19 kW', 2306, 1, 'public/storage/uploadimage/1603263919192.jpg', '5', '8.2%', '120', '3360', '28', '8.2%', '60', '2820', '47', '0%', '12', '2305.75', '192', '2020-10-21 19:35:19', '2021-04-30 17:04:32'),
(282, 'Viessmann', 'Viessmann Vitodens 100-W Compact 26 kW|', 2358, 1, 'public/storage/uploadimage/1619756705102.jpg', '5', '8.2%', '120', '3480', '29', '8.2%', '60', '2880', '48', '0%', '12', '2357.75', '196', '2020-10-21 19:36:32', '2021-04-30 17:04:33'),
(283, 'Viessmann', 'Viessmann Vitodens 100-W Compact 35 kW', 2761, 1, 'public/storage/uploadimage/1619756981110.jpg', '5', '8.2%', '120', '4080', '34', '8.2%', '60', '3360', '56', '0%', '12', '2760.75', '230', '2020-10-21 19:37:13', '2021-04-30 17:04:38'),
(284, 'ideal', 'Ideal Logic Plus Regular H12 ERP', 2199, 1, 'public/storage/uploadimage/1619757047148.jpg', '7', '8.2%', '120', '3240', '27', '8.2%', '60', '2700', '45', '0%', '12', '2199.44', '183', '2020-10-21 19:38:28', '2021-04-30 17:04:20'),
(304, 'Viessmann', 'Viessmann Vitodens 050-W 29 kW', 2026, 3, 'public/storage/uploadimage/1616492766191.jpg', '5', '8.2%', '120', '3000', '25', '8.2%', '60', '2460', '41', '0%', '12', '2026', '169', '2021-03-23 22:16:06', '2021-04-30 17:14:13'),
(305, 'Viessmann', 'Viessmann Vitodens 050-W 35 kW', 2200, 3, 'public/storage/uploadimage/1616492881115.jpg', '5', '8.2%', '120', '3240', '27', '8.2%', '60', '2700', '45', '0%', '12', '2200', '183', '2021-03-23 22:18:01', '2021-04-30 17:14:11'),
(306, 'High12', 'JKuiooo', 5000, 5, 'public/storage/uploadimage/1616566078200.jpg', '1', '8.2%', '120', '7320', '61', '8.2%', '60', '6120', '102', '0%', '12', '5000', '417', '2021-03-24 00:07:53', '2021-03-24 18:37:58'),
(308, 'High63', 'JK', 450, 5, 'public/storage/uploadimage/1616566878184.jpg', '1', '8.2%', '120', '720', '6', '8.2%', '60', '540', '9', '0%', '12', '450', '38', '2021-03-24 18:51:18', '2021-04-30 17:14:02'),
(311, 'Ideal', 'Ideal Logic Plus System S18 ERP', 2341, 2, 'public/storage/uploadimage/1619759832135.', '3', '8.2%', '120', '3480', '29', '8.2%', '60', '2880', '48', '0%', '12', '2341.47', '195', '2021-03-26 00:36:33', '2021-04-30 17:05:05'),
(313, 'Viessmann', 'Viessmann Vitodens 050-W 29 kW', 2026, 4, 'public/storage/uploadimage/1619776804156.jpg', '5', '8.2%', '120', '3000', '25', '8.2%', '60', '2460', '41', '0%', '12', '2026', '169', '2021-04-20 19:46:02', '2021-04-30 19:30:16'),
(314, 'ideal', 'Ideal Logic Plus Regular H15 ERP', 2240, 1, 'public/storage/uploadimage/1619758091133.jpg', '2', '8.2%', '120', '3240', '27', '8.2%', '60', '2760', '46', '0%', '12', '2240', '187', '2021-04-30 14:18:11', '2021-04-30 17:04:25'),
(316, 'ideal', 'Vokera Easi Heat Regular 18', 1875, 1, 'public/storage/uploadimage/1619758726116.jpg', '2', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1874.666', '156', '2021-04-30 14:28:46', '2021-04-30 17:34:41'),
(321, 'Viessmann', 'Viessmann Vitodens 100-W 26 kW', 2171, 3, 'public/storage/uploadimage/1622733756151.png', '10', '8.2%', '120', '3240', '27', '8.2%', '60', '2640', '44', '0%', '12', '2171', '181', '2021-04-30 14:37:44', '2021-06-04 00:52:55'),
(322, 'Viessmann', 'Viessmann Vitodens 050-W 35 kW', 2200, 4, 'public/storage/uploadimage/1619776820110.jpg', '5', '8.2%', '120', '3240', '27', '8.2%', '60', '2700', '45', '0%', '12', '2200', '183', '2021-04-30 14:40:37', '2021-04-30 19:31:25'),
(323, 'High', 'JKPACK', 450, 5, 'public/storage/uploadimage/1619759522115.jpg', '1', '8.2%', '120', '720', '6', '8.2%', '60', '540', '9', '0%', '12', '450', '38', '2021-04-30 14:42:02', '2021-04-30 14:42:02'),
(324, 'Ideal', 'Ideal Logic Plus System S24 ERP', 2379, 2, 'public/storage/uploadimage/1619760163125.jpg', '2', '8.2%', '120', '3480', '29', '8.2%', '60', '2880', '48', '0%', '12', '2379.12', '198', '2021-04-30 14:52:43', '2021-04-30 17:05:10'),
(325, 'Ideal', 'Ideal Logic Plus System S30 ERP|', 2424, 2, 'public/storage/uploadimage/1619760484159.jpg', '2', '8.2%', '120', '3600', '30', '8.2%', '60', '2940', '49', '0%', '12', '2424.05', '202', '2021-04-30 14:58:04', '2021-04-30 17:05:15'),
(326, 'Navien', 'Navien 20kW System', 2030, 2, 'public/storage/uploadimage/1619760909159.jpg', '7', '8.2%', '120', '3000', '25', '8.2%', '60', '2460', '41', '0%', '12', '2030.15', '169', '2021-04-30 15:05:09', '2021-04-30 17:05:20'),
(327, 'Navien', 'Navien 23kW System', 2054, 2, 'public/storage/uploadimage/1619761037119.jpg', '7', '8.2%', '120', '3000', '25', '8.2%', '60', '2520', '42', '0%', '12', '2053.55', '171', '2021-04-30 15:07:17', '2021-04-30 17:05:25'),
(328, 'Navien', 'Navien 28kW System', 2217, 2, 'public/storage/uploadimage/1619761075111.jpg', '7', '8.2%', '120', '3240', '27', '8.2%', '60', '2700', '45', '0%', '12', '2217.35', '185', '2021-04-30 15:07:55', '2021-04-30 17:05:30'),
(329, 'Navien', 'Navien 33kW System', 2241, 2, 'public/storage/uploadimage/1619761109125.jpg', '7', '8.2%', '120', '3240', '27', '8.2%', '60', '2760', '46', '0%', '12', '2240.75', '187', '2021-04-30 15:08:29', '2021-04-30 17:05:34'),
(330, 'Vokera', 'Vokera Easi-Heat System 24s', 1847, 2, 'public/storage/uploadimage/1619761240146.jpg', '5', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1846.85', '154', '2021-04-30 15:10:40', '2021-04-30 17:05:38'),
(331, 'Vokera', 'Vokera Easi-Heat System 30s', 1877, 2, 'public/storage/uploadimage/1619761289194.jpg', '5', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1876.55', '156', '2021-04-30 15:11:29', '2021-04-30 17:05:44'),
(332, 'Viessmann', 'Viessmann Vitodens 100-W 30 kW', 2674, 3, 'public/storage/uploadimage/1622733761190.png', '10', '8.2%', '120', '3960', '33', '8.2%', '60', '3240', '54', '0%', '12', '2674', '223', '2021-04-30 15:38:04', '2021-06-04 00:52:52'),
(334, 'Viessmann', 'Viessmann Vitodens 200-W 29 kW', 3508, 3, 'public/storage/uploadimage/1619768232168.jpg', '5', '8.2%', '120', '5160', '43', '8.2%', '60', '4260', '71', '0%', '12', '3508', '292', '2021-04-30 17:07:12', '2021-04-30 17:14:07'),
(335, 'Viessmann', 'Viessmann Vitodens 111-W 35 kW Storage Combi', 3508, 3, 'public/storage/uploadimage/1619768408127.jpg', '5', '8.2%', '120', '5160', '43', '8.2%', '60', '4260', '71', '0%', '12', '3508', '292', '2021-04-30 17:10:08', '2021-04-30 17:14:06'),
(336, 'Viessmann', 'Viessmann Vitodens 111-W 26 kW Storage Combi', 4341, 3, 'public/storage/uploadimage/1619768462173.jpg', '5', '8.2%', '120', '6360', '53', '8.2%', '60', '5280', '88', '0%', '12', '4341', '362', '2021-04-30 17:11:02', '2021-04-30 17:14:06'),
(337, 'Ideal', 'Ideal Atlantic 24C Combi', 1787, 3, 'public/storage/uploadimage/1619768588179.jpg', '3', '8.2%', '120', '2640', '22', '8.2%', '60', '2160', '36', '0%', '12', '1787', '149', '2021-04-30 17:13:08', '2021-04-30 17:36:33'),
(341, 'Ideal', 'Ideal Atlantic 30C Combi', 1844, 3, 'public/storage/uploadimage/1619769941183.jpg', '3', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1844', '154', '2021-04-30 17:34:07', '2021-04-30 17:36:31'),
(342, 'LKL', 'JKLPACK', 550, 1, 'public/storage/uploadimage/1619769866200.jpg', '1', '8.2%', '120', '840', '7', '8.2%', '60', '660', '11', '0%', '12', '550.45', '46', '2021-04-30 17:34:26', '2021-04-30 17:34:26'),
(343, 'Ideal', 'Ideal Atlantic 35C Combi', 1917, 3, 'public/storage/uploadimage/1619770000167.jpg', '3', '8.2%', '120', '2760', '23', '8.2%', '60', '2340', '39', '0%', '12', '1917', '160', '2021-04-30 17:36:40', '2021-04-30 17:36:40'),
(344, 'Ideal', 'Ideal Independent +C24', 2268, 3, 'public/storage/uploadimage/1619770043130.jpg', '3', '8.2%', '120', '3360', '28', '8.2%', '60', '2760', '46', '0%', '12', '2268', '189', '2021-04-30 17:37:23', '2021-04-30 17:37:23'),
(345, 'Ideal', 'Ideal Independent +C30', 2346, 3, 'public/storage/uploadimage/1619774243170.jpg', '3', '8.2%', '120', '3480', '29', '8.2%', '60', '2880', '48', '0%', '12', '2346', '196', '2021-04-30 18:47:23', '2021-04-30 18:47:23'),
(346, 'Ideal', 'Ideal Independent +C35', 2450, 3, 'public/storage/uploadimage/1619774304105.jpg', '3', '8.2%', '120', '3600', '30', '8.2%', '60', '3000', '50', '0%', '12', '2450', '204', '2021-04-30 18:48:24', '2021-04-30 18:48:24'),
(347, 'Navien', 'Navien 24kW Combi', 1879, 3, 'public/storage/uploadimage/1619774403195.jpg', '7', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1879', '157', '2021-04-30 18:50:03', '2021-04-30 18:50:03'),
(348, 'Navien 28kW Combi', 'Navien 28kW Combi', 1899, 3, 'public/storage/uploadimage/1619774474137.jpg', '7', '8.2%', '120', '2760', '23', '8.2%', '60', '2340', '39', '0%', '12', '1899', '158', '2021-04-30 18:51:14', '2021-04-30 18:51:14'),
(349, 'Navien', 'Navien 34kW Combi', 2068, 3, 'public/storage/uploadimage/1619774515172.jpg', '7', '8.2%', '120', '3000', '25', '8.2%', '60', '2520', '42', '0%', '12', '2068', '172', '2021-04-30 18:51:55', '2021-04-30 18:51:55'),
(350, 'Navien', 'Navien 40kW Combi', 2068, 3, 'public/storage/uploadimage/1619774611120.jpg', '7', '8.2%', '120', '3000', '25', '8.2%', '60', '2520', '42', '0%', '12', '2068', '172', '2021-04-30 18:53:31', '2021-04-30 18:53:31'),
(351, 'Vokera', 'Vokera Easi Plus 25c', 1644, 3, 'public/storage/uploadimage/1619774881174.jpg', '5', '8.2%', '120', '2400', '20', '8.2%', '60', '1980', '33', '0%', '12', '1644', '137', '2021-04-30 18:58:01', '2021-04-30 18:58:01'),
(352, 'Vokera', 'Vokera Easi Plus 29c', 1670, 3, 'public/storage/uploadimage/1619774981176.jpg', '5', '8.2%', '120', '2400', '20', '8.2%', '60', '2040', '34', '0%', '12', '1670', '139', '2021-04-30 18:59:41', '2021-04-30 18:59:41'),
(353, 'Vokera', 'Vokera Easi Plus 32c', 1904, 3, 'public/storage/uploadimage/1619775031178.jpg', '5', '8.2%', '120', '2760', '23', '8.2%', '60', '2340', '39', '0%', '12', '1904', '159', '2021-04-30 19:00:31', '2021-04-30 19:00:31'),
(354, 'Elektra', 'Elektra 12kW Combi Boiler With Inbuilt Cylinder [Compact]', 3785, 3, 'public/storage/uploadimage/1619775169166.jpg', '5', '8.2%', '120', '5520', '46', '8.2%', '60', '4620', '77', '0%', '12', '3785', '315', '2021-04-30 19:02:49', '2021-04-30 19:02:49'),
(355, 'Elektra', 'Elektra 12kW Combi [Inbuilt Cylinder]', 3518, 3, 'public/storage/uploadimage/1619775208139.jpg', '5', '8.2%', '120', '5160', '43', '8.2%', '60', '4320', '72', '0%', '12', '3518', '293', '2021-04-30 19:03:28', '2021-04-30 19:03:28'),
(356, 'Elektra', 'Elektra 12kW Combi [Small]', 3000, 3, 'public/storage/uploadimage/1619775254104.jpg', '5', '8.2%', '120', '4440', '37', '8.2%', '60', '3660', '61', '0%', '12', '3000', '250', '2021-04-30 19:04:14', '2021-04-30 19:04:14'),
(357, 'Elektra', 'Elektra 12kW System Boiler', 3000, 3, 'public/storage/uploadimage/1619775297135.jpg', '5', '8.2%', '120', '4440', '37', '8.2%', '60', '3660', '61', '0%', '12', '3000', '250', '2021-04-30 19:04:57', '2021-04-30 19:04:57'),
(358, 'Viessmann', 'Viessmann Vitodens 100-W 26 kW', 2171, 4, 'public/storage/uploadimage/1619776938112.jpg', '5', '8.2%', '120', '3240', '27', '8.2%', '60', '2640', '44', '0%', '12', '2171', '181', '2021-04-30 19:32:18', '2021-04-30 19:32:18'),
(359, 'Viessmann', 'Viessmann Vitodens 100-W 29 kW', 2674, 4, 'public/storage/uploadimage/1619776990148.jpg', '5', '8.2%', '120', '3960', '33', '8.2%', '60', '3240', '54', '0%', '12', '2674', '223', '2021-04-30 19:33:10', '2021-04-30 19:33:10'),
(360, 'Viessmann', 'Viessmann Vitodens 100-W 35 kW', 2774, 4, 'public/storage/uploadimage/1619777071168.jpg', '5', '8.2%', '120', '4080', '34', '8.2%', '60', '3420', '57', '0%', '12', '2774', '231', '2021-04-30 19:34:31', '2021-04-30 19:34:31'),
(361, 'Viessmann', 'Viessmann Vitodens 200-W 29 kW', 3508, 4, 'public/storage/uploadimage/1619777132133.jpg', '5', '8.2%', '120', '5160', '43', '8.2%', '60', '4260', '71', '0%', '12', '3508', '292', '2021-04-30 19:35:32', '2021-04-30 19:35:32'),
(362, 'Viessmann', 'Viessmann Vitodens 111-W 35 kW Storage Combi', 3508, 4, 'public/storage/uploadimage/1619777166185.jpg', '5', '8.2%', '120', '5160', '43', '8.2%', '60', '4260', '71', '0%', '12', '3508', '292', '2021-04-30 19:36:06', '2021-04-30 19:36:06'),
(363, 'Viessmann', 'Viessmann Vitodens 111-W 26 kW Storage Combi', 4340, 4, 'public/storage/uploadimage/1619777193186.jpg', '5', '8.2%', '120', '6360', '53', '8.2%', '60', '5280', '88', '0%', '12', '4340', '362', '2021-04-30 19:36:33', '2021-04-30 19:36:33'),
(364, 'ideal', 'Ideal Atlantic 24C Combi', 1787, 4, 'public/storage/uploadimage/1620652239154.jpg', '5', '8.2%', '120', '2640', '22', '8.2%', '60', '2160', '36', '0%', '12', '1787', '149', '2021-05-10 22:40:39', '2021-05-10 22:40:39'),
(365, 'ideal', 'Ideal Atlantic 30C Combi', 1844, 4, 'public/storage/uploadimage/1620652307112.jpg', '5', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1844', '154', '2021-05-10 22:41:47', '2021-05-10 22:41:47'),
(366, 'ideal', 'Ideal Atlantic 35C Combi', 1917, 4, 'public/storage/uploadimage/1620652373197.jpg', '5', '8.2%', '120', '2760', '23', '8.2%', '60', '2340', '39', '0%', '12', '1917', '160', '2021-05-10 22:42:53', '2021-05-10 22:42:53'),
(367, 'ideal', 'Ideal Independent +C24', 2268, 4, 'public/storage/uploadimage/1620652456188.jpg', '5', '8.2%', '120', '3360', '28', '8.2%', '60', '2760', '46', '0%', '12', '2268', '189', '2021-05-10 22:44:16', '2021-05-10 22:44:16'),
(368, 'ideal', 'Ideal Independent +C30', 2346, 4, 'public/storage/uploadimage/1620652501132.jpg', '5', '8.2%', '120', '3480', '29', '8.2%', '60', '2880', '48', '0%', '12', '2346', '196', '2021-05-10 22:45:01', '2021-05-10 22:45:01'),
(369, 'ideal', 'Ideal Independent +C35', 2450, 4, 'public/storage/uploadimage/1620652595133.jpg', '5', '8.2%', '120', '3600', '30', '8.2%', '60', '3000', '50', '0%', '12', '2450', '204', '2021-05-10 22:46:35', '2021-05-10 22:46:35'),
(370, 'Navien', 'Navien 24kW Combi', 1879, 4, 'public/storage/uploadimage/1620652935188.jpg', '7', '8.2%', '120', '2760', '23', '8.2%', '60', '2280', '38', '0%', '12', '1879', '157', '2021-05-10 22:52:15', '2021-05-10 22:52:15'),
(371, 'Navien', 'Navien 28kW Combi', 1899, 4, 'public/storage/uploadimage/1620653044157.jpg', '7', '8.2%', '120', '2760', '23', '8.2%', '60', '2340', '39', '0%', '12', '1899', '158', '2021-05-10 22:54:04', '2021-05-10 22:54:04'),
(372, 'Navien', 'Navien 34kW Combi', 2068, 4, 'public/storage/uploadimage/1620735805135.jpg', '7', '8.2%', '120', '3000', '25', '8.2%', '60', '2520', '42', '0%', '12', '2068', '172', '2021-05-11 21:53:25', '2021-05-11 21:53:25'),
(373, 'Navien', 'Navien 40kW Combi', 2068, 4, 'public/storage/uploadimage/1620735879182.jpg', '7', '8.2%', '120', '3000', '25', '8.2%', '60', '2520', '42', '0%', '12', '2068', '172', '2021-05-11 21:54:39', '2021-05-11 21:54:39'),
(374, 'Vokera', 'Vokera Easi Plus 25c', 1644, 4, 'public/storage/uploadimage/1620736012189.jpg', '5', '8.2%', '120', '2400', '20', '8.2%', '60', '1980', '33', '0%', '12', '1644', '137', '2021-05-11 21:56:52', '2021-05-11 21:56:52'),
(375, 'Vokera', 'Vokera Easi Plus 29c', 1644, 4, 'public/storage/uploadimage/1620736051125.jpg', '5', '8.2%', '120', '2400', '20', '8.2%', '60', '1980', '33', '0%', '12', '1644', '137', '2021-05-11 21:57:31', '2021-05-11 21:57:31'),
(376, 'Vokera', 'Vokera Easi Plus 32c', 1904, 4, 'public/storage/uploadimage/1620736086129.jpg', '5', '8.2%', '120', '2760', '23', '8.2%', '60', '2340', '39', '0%', '12', '1904', '159', '2021-05-11 21:58:06', '2021-05-11 21:58:06'),
(377, 'Elektra', 'Elektra 12kW Combi Boiler With Inbuilt Cylinder [Compact]', 3785, 4, 'public/storage/uploadimage/1620736308192.jpg', '2', '8.2%', '120', '5520', '46', '8.2%', '60', '4620', '77', '0%', '12', '3785', '315', '2021-05-11 22:01:48', '2021-05-11 22:01:48'),
(378, 'Elektra', 'Elektra 12kW Combi [Inbuilt Cylinder]', 3518, 4, 'public/storage/uploadimage/1620736382136.jpg', '2', '8.2%', '120', '5160', '43', '8.2%', '60', '4320', '72', '0%', '12', '3518', '293', '2021-05-11 22:03:02', '2021-05-11 22:03:02'),
(379, 'Elektra', 'Elektra 12kW Combi [Small]', 3000, 4, 'public/storage/uploadimage/1620736436180.jpg', '2', '8.2%', '120', '4440', '37', '8.2%', '60', '3660', '61', '0%', '12', '3000', '250', '2021-05-11 22:03:56', '2021-05-11 22:03:56'),
(380, 'Elektra', 'Elektra 12kW System Boiler', 3000, 4, 'public/storage/uploadimage/1620736477125.jpg', '2', '8.2%', '120', '4440', '37', '8.2%', '60', '3660', '61', '0%', '12', '3000', '250', '2021-05-11 22:04:37', '2021-05-11 22:04:37'),
(381, 'Viessmann', 'Viessmann Vitodens 100-W 35 kW', 2790, 3, 'public/storage/uploadimage/1622733730189.png', '10', '8.2%', '120', '4080', '34', '8.2%', '60', '3420', '57', '0%', '12', '2790', '233', '2021-06-04 00:52:10', '2021-06-04 00:52:10');

-- --------------------------------------------------------

--
-- Table structure for table `boiler_controls`
--

CREATE TABLE `boiler_controls` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pack` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `boiler_controls`
--

INSERT INTO `boiler_controls` (`id`, `pack`, `price`, `created_at`, `updated_at`) VALUES
(71, '(1x) Navien Internet Connected [Free]', '0', '2020-10-15 00:33:54', '2021-04-30 14:31:55'),
(72, '(1x) Ideal Plug In [Free]', '0', '2020-10-15 00:34:01', '2020-10-15 00:34:01'),
(74, '(1x) Vokera Analogue Control [Free]', '0', '2020-10-15 00:34:16', '2021-04-30 14:32:59'),
(75, '(1x) Viessmann Digital [Free]', '0', '2020-10-15 00:34:23', '2021-04-30 14:33:20'),
(76, '(1x) Viessmann Vitotrol', '99', '2020-10-15 00:34:30', '2021-04-30 14:33:41'),
(77, '(1x) RF2 Viessmann 100', '108.83', '2020-10-15 00:34:36', '2021-04-30 14:34:22'),
(79, '(1x) Tado Viessmann', '164.44', '2020-10-15 00:34:52', '2021-04-30 14:34:45'),
(80, '(1x) EPH 1 Zone', '26.37', '2020-10-15 00:34:59', '2021-04-30 14:35:06'),
(81, '(1x) EPH 2 Zone', '44', '2020-10-15 00:35:05', '2021-04-30 14:35:28'),
(82, '(1x) Salus RT500', '81.99', '2020-10-15 00:35:11', '2021-04-30 14:36:13'),
(83, '(1x) Salus Smart Home Hub', '115', '2020-10-15 00:35:18', '2021-04-30 14:36:36'),
(84, '(1x) Nest Internet Stat', '169', '2020-10-15 00:35:24', '2021-04-30 14:37:01'),
(90, '(1x) Connect on to Existing [Free with Vokera]', '0', '2021-03-23 22:44:57', '2021-04-30 14:31:28'),
(91, '(1x) Hive Internet Stat', '134.99', '2021-04-30 14:37:28', '2021-04-30 14:37:28'),
(92, '(1x) Vokera Besmart Connected Thermostat', '129', '2021-04-30 14:37:47', '2021-04-30 14:37:47'),
(93, '(1x) Vokera RF VOK20101743', '57.23', '2021-04-30 14:38:08', '2021-04-30 14:38:08');

-- --------------------------------------------------------

--
-- Table structure for table `boltschoosens`
--

CREATE TABLE `boltschoosens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unique_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boltsid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `total_price` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `boltschoosens`
--

INSERT INTO `boltschoosens` (`id`, `unique_id`, `boltsid`, `value`, `qty`, `total_price`, `created_at`, `updated_at`) VALUES
(1, 'MPH05155048', '19', 250, 1, 250, '2021-05-15 19:52:08', '2021-05-15 19:52:08'),
(2, 'MPH05175824', '7', 0, 3, 0, '2021-05-17 16:58:41', '2021-05-17 16:58:41'),
(3, 'MPH05172556', '15', 56, 6, 336, '2021-05-17 19:45:44', '2021-05-17 19:45:44'),
(4, 'MPH05172556', '19', 250, 8, 2000, '2021-05-17 19:45:52', '2021-05-17 19:45:52'),
(5, 'MPH05170805', '19', 250, 2, 500, '2021-05-17 20:08:48', '2021-05-17 20:08:48'),
(6, 'MPH05172216', '19', 250, 2, 500, '2021-05-17 20:22:50', '2021-05-17 20:22:50'),
(7, 'MPH05170107', '19', 250, 2, 500, '2021-05-17 21:02:04', '2021-05-17 21:02:04'),
(8, 'MPH05170539', '20', 0, 1, 0, '2021-05-17 21:06:14', '2021-05-17 21:06:14'),
(9, 'MPH05171436', '19', 250, 1, 250, '2021-05-17 21:15:10', '2021-05-17 21:15:10'),
(10, 'MPH05171850', '18', 0, 6, 0, '2021-05-17 21:19:21', '2021-05-17 21:19:21'),
(11, 'MPH05173202', '19', 250, 4, 1000, '2021-05-17 21:32:29', '2021-05-17 21:32:29'),
(12, 'MPH05173605', '21', 0, 4, 0, '2021-05-17 21:36:30', '2021-05-17 21:36:30'),
(13, 'MPH05174020', '15', 56, 5, 280, '2021-05-17 21:40:40', '2021-05-17 21:40:40'),
(14, 'MPH05174947', '20', 0, 7, 0, '2021-05-17 21:50:12', '2021-05-17 21:50:12'),
(15, 'MPH05175919', '15', 56, 6, 336, '2021-05-17 21:59:42', '2021-05-17 21:59:42'),
(16, 'MPH05170613', '15', 56, 6, 336, '2021-05-17 22:06:36', '2021-05-17 22:06:36'),
(17, 'MPH05171057', '23', 0, 7, 0, '2021-05-17 22:11:20', '2021-05-17 22:11:20'),
(18, 'MPH05171956', '21', 0, 8, 0, '2021-05-17 22:20:25', '2021-05-17 22:20:25'),
(19, 'MPH05172855', '21', 0, 7, 0, '2021-05-17 22:29:14', '2021-05-17 22:29:14'),
(20, 'MPH05173422', '20', 0, 6, 0, '2021-05-17 22:34:41', '2021-05-17 22:34:41'),
(21, 'MPH05175049', '19', 250, 1, 250, '2021-05-17 22:51:24', '2021-05-17 22:51:24'),
(22, 'MPH05175541', '19', 250, 1, 250, '2021-05-17 22:56:11', '2021-05-17 22:56:11'),
(23, 'MPH05171425', '15', 56, 8, 448, '2021-05-17 23:14:50', '2021-05-17 23:14:50'),
(24, 'MPH05180413', '19', 250, 1, 250, '2021-05-18 20:06:16', '2021-05-18 20:06:16'),
(25, 'MPH05182129', '20', 0, 4, 0, '2021-05-18 20:22:10', '2021-05-18 20:22:10'),
(26, 'MPH05182421', '19', 250, 1, 250, '2021-05-18 20:24:59', '2021-05-18 20:24:59'),
(27, 'MPH05182714', '20', 0, 5, 0, '2021-05-18 20:27:37', '2021-05-18 20:27:37'),
(28, 'MPH05183655', '19', 250, 1, 250, '2021-05-18 20:37:34', '2021-05-18 20:37:34'),
(29, 'MPH05184104', '19', 250, 1, 250, '2021-05-18 20:41:32', '2021-05-18 20:41:32'),
(30, 'MPH05184440', '15', 56, 1, 56, '2021-05-18 20:45:17', '2021-05-18 20:45:17'),
(31, 'MPH05180022', '18', 0, 6, 0, '2021-05-18 21:00:40', '2021-05-18 21:00:40'),
(32, 'MPH05181816', '18', 0, 4, 0, '2021-05-18 21:18:38', '2021-05-18 21:18:38'),
(33, 'MPH05182626', '19', 250, 1, 250, '2021-05-18 21:29:19', '2021-05-18 21:29:19'),
(34, 'MPH05183646', '19', 250, 4, 1000, '2021-05-18 21:37:22', '2021-05-18 21:37:22'),
(35, 'MPH05184922', '19', 250, 8, 2000, '2021-05-18 21:49:49', '2021-05-18 21:49:49'),
(36, 'MPH05184922', '24', 50, 9, 450, '2021-05-18 21:49:57', '2021-05-18 21:49:57'),
(37, 'MPH05185835', '15', 56, 8, 448, '2021-05-18 21:58:57', '2021-05-18 21:58:57'),
(38, 'MPH05180644', '23', 0, 8, 0, '2021-05-18 22:07:04', '2021-05-18 22:07:04'),
(39, 'MPH05180644', '25', 0, 5, 0, '2021-05-18 22:07:10', '2021-05-18 22:07:10'),
(40, 'MPH05181502', '24', 50, 7, 350, '2021-05-18 22:15:26', '2021-05-18 22:15:26'),
(41, 'MPH05182326', '23', 0, 6, 0, '2021-05-18 22:23:43', '2021-05-18 22:23:43'),
(42, 'MPH05180322', '19', 250, 1, 250, '2021-05-18 23:04:02', '2021-05-18 23:04:02'),
(43, 'MPH05191224', '19', 250, 1, 250, '2021-05-19 14:13:58', '2021-05-19 14:13:58'),
(44, 'MPH05205933', '19', 250, 1, 250, '2021-05-20 16:01:13', '2021-05-20 16:01:13'),
(45, 'MPH05201311', '21', 0, 7, 0, '2021-05-20 20:13:30', '2021-05-20 20:13:30'),
(46, 'MPH05201915', '23', 0, 7, 0, '2021-05-20 20:19:45', '2021-05-20 20:19:45'),
(47, 'MPH05201216', '19', 250, 1, 250, '2021-05-20 21:13:05', '2021-05-20 21:13:05'),
(48, 'MPH05202357', '19', 250, 1, 250, '2021-05-20 21:24:24', '2021-05-20 21:24:24'),
(49, 'MPH05204235', '19', 250, 1, 250, '2021-05-20 21:43:18', '2021-05-20 21:43:18'),
(50, 'MPH05200955', '19', 250, 1, 250, '2021-05-20 22:10:50', '2021-05-20 22:10:50'),
(51, 'MPH05210542', '19', 250, 1, 250, '2021-05-21 14:06:21', '2021-05-21 14:06:21'),
(52, 'MPH05244803', '7', 0, 1, 0, '2021-05-24 22:48:33', '2021-05-24 22:48:33'),
(53, 'MPH05244803', '15', 56, 1, 56, '2021-05-24 22:48:37', '2021-05-24 22:48:37'),
(54, 'MPH06095021', '15', 56, 6, 336, '2021-06-09 19:53:09', '2021-06-09 19:53:09'),
(55, 'MPH06095905', '18', 0, 1, 0, '2021-06-09 19:59:44', '2021-06-09 19:59:44'),
(56, 'MPH06090051', '8', 0, 5, 0, '2021-06-09 20:01:12', '2021-06-09 20:01:12'),
(57, 'MPH06090452', '19', 250, 1, 250, '2021-06-09 20:05:21', '2021-06-09 20:05:21'),
(58, 'MPH06094000', '19', 250, 1, 250, '2021-06-09 20:42:06', '2021-06-09 20:42:06');

-- --------------------------------------------------------

--
-- Table structure for table `bolt_ons`
--

CREATE TABLE `bolt_ons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bolt_ons`
--

INSERT INTO `bolt_ons` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(7, '[1x] System to Combi Change', '0', '2020-09-17 17:59:02', '2020-10-15 00:48:47'),
(8, '[1x] Heat On/System', '0', '2020-09-17 17:59:19', '2020-10-15 00:48:43'),
(15, '[1x] Boiler Move', '56', '2020-10-15 00:41:59', '2021-04-17 14:35:26'),
(18, '[1x] Upgrade to Vertical Flue', '0', '2020-10-15 00:50:53', '2020-10-15 00:50:53'),
(19, '[1x] Joinery / Builder Work', '250', '2020-10-15 00:51:03', '2021-03-22 23:51:41'),
(20, '[1x] Shower Upgrade', '0', '2020-10-15 00:51:09', '2020-10-15 00:51:09'),
(21, '[1x] Condensate Pump or Soakaway', '0', '2020-10-15 00:51:15', '2020-10-15 00:51:15'),
(22, '[1x] Vented Cylinder', '69', '2020-10-15 00:51:23', '2021-04-26 15:07:56'),
(23, '[1x] Unvented Cylinder', '0', '2020-10-15 00:51:44', '2020-10-15 00:51:44'),
(24, '[1x] Rad Valves sets', '50', '2020-10-15 00:51:52', '2021-04-26 15:07:51'),
(25, '[1x] Radiators Including TRV / Up to 7 TRV Replacement', '0', '2020-10-15 00:52:11', '2020-10-15 00:52:11'),
(26, 'ert', '57', '2021-03-22 21:18:40', '2021-03-22 21:19:59');

-- --------------------------------------------------------

--
-- Table structure for table `calls`
--

CREATE TABLE `calls` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `user_id` int(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `calls`
--

INSERT INTO `calls` (`id`, `duration`, `call_status`, `lead_id`, `user_id`, `created_at`, `updated_at`) VALUES
(9, '00:00:10', 'Hello............', 4, 1, '2021-05-20 16:05:49', '2021-05-20 16:05:49'),
(10, '00:00:05', 'ddd', 6, 1, '2021-05-20 16:06:40', '2021-05-20 16:06:40'),
(11, '00:00:07', 'OGL', 8, 1, '2021-05-20 16:14:05', '2021-05-20 16:14:05'),
(13, '00:00:09', 'Test Here', 10, 1, '2021-05-20 17:30:09', '2021-05-20 17:30:09'),
(14, '00:00:10', 'Hello World.......', 10, 1, '2021-05-20 17:30:35', '2021-05-20 17:30:35'),
(15, '00:00:08', 'OKG........', 5, 1, '2021-05-20 17:36:10', '2021-05-20 17:36:10'),
(16, '00:00:12', 'JK OP..........', 3, 1, '2021-05-20 17:38:24', '2021-05-20 17:38:24'),
(17, '00:00:10', 'LOP', 3, 1, '2021-05-20 17:39:08', '2021-05-20 17:39:08'),
(18, '00:00:10', 'GHLOP', 3, 1, '2021-05-20 18:14:51', '2021-05-20 18:14:51'),
(19, '00:00:06', 'Hi 9', 9, 1, '2021-05-20 19:11:15', '2021-05-20 19:11:15'),
(20, '00:00:07', 'OK BOS.......', 6, 11, '2021-05-20 20:01:52', '2021-05-20 20:01:52'),
(21, '00:00:03', 'gh', 9, 1, '2021-05-20 20:06:40', '2021-05-20 20:06:40'),
(22, '00:00:05', 'ANDR', 8, 1, '2021-05-20 20:07:14', '2021-05-20 20:07:14'),
(23, '00:00:14', 'ANDR', NULL, 1, '2021-05-20 20:07:23', '2021-05-20 20:07:23'),
(24, '00:00:16', 'ANDR', NULL, 1, '2021-05-20 20:07:24', '2021-05-20 20:07:24'),
(26, '00:00:05', 'OK..........', 8, 1, '2021-05-20 20:46:22', '2021-05-20 20:46:22'),
(30, '00:00:03', 'OK', 10, 1, '2021-05-20 20:54:12', '2021-05-20 20:54:12'),
(32, '00:00:06', 'Call later', 4, 1, '2021-05-20 21:02:51', '2021-05-20 21:02:51'),
(33, '00:00:04', 'here', 2, 1, '2021-05-20 21:03:11', '2021-05-20 21:03:11'),
(34, '00:00:05', 'ok..........', 2, 1, '2021-05-20 21:04:07', '2021-05-20 21:04:07'),
(39, '00:00:08', 'LOP', 2, 1, '2021-05-21 14:15:51', '2021-05-21 14:15:51');

-- --------------------------------------------------------

--
-- Table structure for table `call_note`
--

CREATE TABLE `call_note` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unqid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_id` int(11) DEFAULT NULL,
  `calls` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_id` int(255) DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `attachment_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `call_note`
--

INSERT INTO `call_note` (`id`, `unqid`, `notes`, `note_id`, `calls`, `call_id`, `duration`, `date`, `type`, `note`, `status`, `schedule_id`, `title`, `user_id`, `lead_id`, `attachment_file`, `created_at`, `updated_at`, `format`, `filename`) VALUES
(10, NULL, NULL, NULL, 'Hello............', 9, '00:00:10', NULL, 'call', NULL, NULL, NULL, NULL, 1, 4, NULL, '2021-05-20 16:05:49', '2021-05-20 16:05:49', NULL, NULL),
(11, NULL, NULL, NULL, 'ddd', 10, '00:00:05', NULL, 'call', NULL, NULL, NULL, NULL, 1, 6, NULL, '2021-05-20 16:06:40', '2021-05-20 16:06:40', NULL, NULL),
(12, NULL, NULL, NULL, 'OGL', 11, '00:00:07', NULL, 'call', NULL, NULL, NULL, NULL, 1, 8, NULL, '2021-05-20 16:14:05', '2021-05-20 16:14:05', NULL, NULL),
(14, NULL, NULL, NULL, 'Test Here', 13, '00:00:09', NULL, 'call', NULL, NULL, NULL, NULL, 1, 10, NULL, '2021-05-20 17:30:09', '2021-05-20 17:30:09', NULL, NULL),
(15, NULL, NULL, NULL, 'Hello World.......', 14, '00:00:10', NULL, 'call', NULL, NULL, NULL, NULL, 1, 10, NULL, '2021-05-20 17:30:35', '2021-05-20 17:30:35', NULL, NULL),
(16, NULL, NULL, NULL, 'OKG........', 15, '00:00:08', NULL, 'call', NULL, NULL, NULL, NULL, 1, 5, NULL, '2021-05-20 17:36:10', '2021-05-20 17:36:10', NULL, NULL),
(17, NULL, NULL, NULL, 'JK OP..........', 16, '00:00:12', NULL, 'call', NULL, NULL, NULL, NULL, 1, 3, NULL, '2021-05-20 17:38:24', '2021-05-20 17:38:24', NULL, NULL),
(18, NULL, NULL, NULL, 'LOP', 17, '00:00:10', NULL, 'call', NULL, NULL, NULL, NULL, 1, 3, NULL, '2021-05-20 17:39:08', '2021-05-20 17:39:08', NULL, NULL),
(19, NULL, NULL, NULL, 'GHLOP', 18, '00:00:10', NULL, 'call', NULL, NULL, NULL, NULL, 1, 3, NULL, '2021-05-20 18:14:51', '2021-05-20 18:14:51', NULL, NULL),
(20, NULL, NULL, NULL, 'Hi 9', 19, '00:00:06', NULL, 'call', NULL, NULL, NULL, NULL, 1, 9, NULL, '2021-05-20 19:11:15', '2021-05-20 19:11:15', NULL, NULL),
(21, NULL, NULL, NULL, 'OK BOS.......', 20, '00:00:07', NULL, 'call', NULL, NULL, NULL, NULL, 11, 6, NULL, '2021-05-20 20:01:52', '2021-05-20 20:01:52', NULL, NULL),
(22, NULL, NULL, NULL, 'gh', 21, '00:00:03', NULL, 'call', NULL, NULL, NULL, NULL, 1, 9, NULL, '2021-05-20 20:06:40', '2021-05-20 20:06:40', NULL, NULL),
(23, NULL, NULL, NULL, 'ANDR', 22, '00:00:05', NULL, 'call', NULL, NULL, NULL, NULL, 1, 8, NULL, '2021-05-20 20:07:14', '2021-05-20 20:07:14', NULL, NULL),
(24, NULL, NULL, NULL, 'ANDR', 23, '00:00:14', NULL, 'call', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2021-05-20 20:07:23', '2021-05-20 20:07:23', NULL, NULL),
(25, NULL, NULL, NULL, 'ANDR', 24, '00:00:16', NULL, 'call', NULL, NULL, NULL, NULL, 1, NULL, NULL, '2021-05-20 20:07:24', '2021-05-20 20:07:24', NULL, NULL),
(27, NULL, NULL, NULL, NULL, NULL, NULL, '2021/05/20 19:00', 'meeting', 'avc1', 'upcoming', 23, 'avc', 1, 10, NULL, '2021-05-20 20:19:02', '2021-05-20 20:19:02', NULL, NULL),
(28, NULL, NULL, NULL, 'OK..........', 26, '00:00:05', NULL, 'call', NULL, NULL, NULL, NULL, 1, 8, NULL, '2021-05-20 20:46:22', '2021-05-20 20:46:22', NULL, NULL),
(32, NULL, NULL, NULL, 'OK', 30, '00:00:03', NULL, 'call', NULL, NULL, NULL, NULL, 1, 10, NULL, '2021-05-20 20:54:12', '2021-05-20 20:54:12', NULL, NULL),
(36, NULL, NULL, NULL, 'Call later', 32, '00:00:06', NULL, 'call', NULL, NULL, NULL, NULL, 1, 4, NULL, '2021-05-20 21:02:51', '2021-05-20 21:02:51', NULL, NULL),
(37, NULL, NULL, NULL, 'here', 33, '00:00:04', NULL, 'call', NULL, NULL, NULL, NULL, 1, 2, NULL, '2021-05-20 21:03:11', '2021-05-20 21:03:11', NULL, NULL),
(38, NULL, NULL, NULL, 'ok..........', 34, '00:00:05', NULL, 'call', NULL, NULL, NULL, NULL, 1, 2, NULL, '2021-05-20 21:04:07', '2021-05-20 21:04:07', NULL, NULL),
(42, NULL, 'ok', 117, NULL, NULL, NULL, NULL, 'note', NULL, NULL, NULL, NULL, 1, 10, NULL, '2021-05-20 21:10:44', '2021-05-20 21:10:44', NULL, NULL),
(43, NULL, NULL, NULL, NULL, NULL, NULL, '2021/05/20 20:00', 'meeting', 'SC BY ADMIN TODAY', 'upcoming', 27, 'SC BY ADMIN TODAY', 1, 10, NULL, '2021-05-20 21:11:33', '2021-05-20 21:11:33', NULL, NULL),
(44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 10, 'CHECK.PNG', '2021-05-20 21:14:20', '2021-05-20 21:14:20', 'PNG', 'CHECK.PNG'),
(49, NULL, NULL, NULL, NULL, NULL, NULL, '2021/05/21 09:58', 'meeting', 'check final', 'upcoming', 29, 'final', 1, 11, NULL, '2021-05-21 13:58:24', '2021-05-21 13:58:24', NULL, NULL),
(53, NULL, NULL, NULL, 'LOP', 39, '00:00:08', NULL, 'call', NULL, NULL, NULL, NULL, 1, 2, NULL, '2021-05-21 14:15:51', '2021-05-21 14:15:51', NULL, NULL),
(54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2, 'CHECK.PNG', '2021-05-21 14:16:09', '2021-05-21 14:16:09', 'PNG', 'CHECK.PNG'),
(55, NULL, NULL, NULL, NULL, NULL, NULL, '2021/05/25 14:17', 'meeting', 'broken boiler', 'upcoming', 30, 'boiler lead app', 1, 12, NULL, '2021-05-24 22:47:51', '2021-05-24 22:47:51', NULL, NULL),
(56, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/01 10:30', 'meeting', 'fb\r\n1 bed 1 bath \r\nupgraded\r\n1 adult lives alone', 'upcoming', 31, 'Sales app', 1, 14, NULL, '2021-06-01 19:01:44', '2021-06-01 19:01:44', NULL, NULL),
(57, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/01 13:00', 'meeting', 'b2\r\n4 bed 3 bath\r\nupgraded\r\n2 adults confirmed', 'upcoming', 32, 'Sales app', 1, 15, NULL, '2021-06-01 19:04:02', '2021-06-01 19:04:02', NULL, NULL),
(58, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/01 13:00', 'meeting', 'CURRENTLY ONLY HAS A HOT WATER TANK - HE IS RUNNNG ELECTRIC HEATERS FROM ASDA', 'upcoming', 33, 'Sales app', 1, 16, NULL, '2021-06-01 19:06:22', '2021-06-01 19:06:22', NULL, NULL),
(59, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/01 18:00', 'meeting', 'PCP\r\nBROKEN\r\n4 BED 2 BATH\r\n2 ADULTS CONFIRMED', 'upcoming', 34, 'Sales app', 1, 17, NULL, '2021-06-01 19:08:38', '2021-06-01 19:08:38', NULL, NULL),
(60, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/02 10:30', 'meeting', 'B2u\r\n\r\ncurrent boiler is getting old so looking for prices to upgrade\r\n\r\nboth to be there', 'upcoming', 35, 'Sales app', 1, 19, NULL, '2021-06-01 19:11:20', '2021-06-01 19:11:20', NULL, NULL),
(61, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/03 19:00', 'meeting', 'pcp\r\n4 bed 2 bath\r\nwants bosch\r\n2 adults confirmed', 'upcoming', 36, 'Sales app', 1, 20, NULL, '2021-06-01 19:13:41', '2021-06-01 19:13:41', NULL, NULL),
(62, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/04 12:00', 'meeting', 'Pick up booked for fri 4th', 'upcoming', 37, 'Sales app', 1, 21, NULL, '2021-06-01 19:15:51', '2021-06-01 19:15:51', NULL, NULL),
(63, NULL, NULL, NULL, NULL, NULL, NULL, '2021/06/09 17:00', 'meeting', 'checking1 checking1', 'upcoming', 38, 'checking1', 1, 7, NULL, '2021-06-09 20:22:27', '2021-06-09 20:22:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `folder_id` int(11) DEFAULT NULL,
  `campaign_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`id`, `folder_id`, `campaign_name`, `slug`, `count`, `created_at`, `updated_at`) VALUES
(1, 4, 'abcde', 'abcde', NULL, '2021-03-22 19:22:56', '2021-03-22 19:22:56'),
(2, 1, '265484848', '265484848', NULL, '2021-03-22 19:23:40', '2021-03-22 19:23:40'),
(3, 2, 'Hii You need to call your customer on time 6.04 pm so please ready for that', 'hii-you-need-to-call-your-customer-on-time-604-pm-so-please-ready-for-that', NULL, '2021-03-22 19:34:43', '2021-03-22 19:34:43'),
(4, 2, 'fhdfghf  cxfghdfzgz', 'fhdfghf-cxfghdfzgz', NULL, '2021-03-22 19:35:06', '2021-03-22 19:35:06'),
(6, 2, 'fhdfghf  cxfghdfzgz  dsgdfg', 'fhdfghf-cxfghdfzgz-dsgdfg', NULL, '2021-03-22 19:35:57', '2021-03-22 19:35:57');

-- --------------------------------------------------------

--
-- Table structure for table `chemical_system_treatments`
--

CREATE TABLE `chemical_system_treatments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chemical_system_treatments`
--

INSERT INTO `chemical_system_treatments` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(27, 'Chemical Flush and Inhibitor', 0, '2020-09-21 22:31:18', '2020-09-21 22:31:18'),
(28, 'MagnaCleanse and Inhibitor', 100, '2020-09-21 22:31:23', '2020-10-15 19:27:39'),
(36, 'DFGH', 5667, '2021-03-22 23:43:36', '2021-03-22 23:43:46');

-- --------------------------------------------------------

--
-- Table structure for table `condensate_terminations`
--

CREATE TABLE `condensate_terminations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `condensate_terminations`
--

INSERT INTO `condensate_terminations` (`id`, `name`, `created_at`, `updated_at`) VALUES
(7, 'Existing Condense Connection', '2020-09-18 17:21:59', '2020-09-18 17:21:59'),
(8, 'Drain', '2020-09-18 17:22:04', '2020-09-18 17:22:04'),
(9, 'Bath', '2020-09-18 17:22:08', '2020-09-18 17:22:08'),
(10, 'Sink', '2020-09-18 17:22:15', '2020-09-18 17:22:15'),
(11, 'Soil Vent Pipe', '2020-09-18 17:22:20', '2020-09-18 17:22:20'),
(12, 'External Gully', '2020-09-18 17:22:25', '2020-09-18 17:22:25'),
(13, 'External Waste Point', '2020-09-18 17:22:53', '2020-09-18 17:22:53'),
(14, 'Pumped', '2020-09-18 17:23:02', '2020-09-18 17:23:02'),
(17, 'Soakaway Trap', '2020-09-18 17:24:00', '2020-09-18 17:24:00'),
(20, 'FIGHTOP', '2021-03-22 23:26:08', '2021-03-22 23:26:23');

-- --------------------------------------------------------

--
-- Table structure for table `contact_lists`
--

CREATE TABLE `contact_lists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `generated_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_lead_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_stage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_amount` int(11) NOT NULL,
  `deal_closing_date` date NOT NULL,
  `deal_owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cupboard_need_alts`
--

CREATE TABLE `cupboard_need_alts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cupboard_need_alts`
--

INSERT INTO `cupboard_need_alts` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(5, 'No alterations required', 0, '2020-09-21 21:47:37', '2020-09-21 21:47:37'),
(6, 'Altered by MPH', 0, '2020-09-21 21:48:02', '2020-09-21 21:48:02'),
(7, 'Permanently removed by customer', 69, '2020-09-21 21:48:20', '2021-04-17 14:36:25'),
(8, 'Permanently removed by MPH', 0, '2020-09-21 21:48:26', '2020-09-21 21:48:26'),
(9, 'At the advice of the installer (during installation)', 0, '2020-09-21 21:48:33', '2020-09-21 21:48:33'),
(14, 'TIGHTUI', 90, '2021-03-22 23:40:55', '2021-03-22 23:41:06');

-- --------------------------------------------------------

--
-- Table structure for table `current_boiler_locations`
--

CREATE TABLE `current_boiler_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `current_boiler_locations`
--

INSERT INTO `current_boiler_locations` (`id`, `name`, `created_at`, `updated_at`) VALUES
(8, 'Kitchen', '2020-09-17 19:51:31', '2020-10-15 18:24:44'),
(9, 'Airing Cupboard', '2020-09-17 19:51:36', '2020-09-17 19:51:36'),
(25, 'Loft', '2020-10-15 17:55:33', '2020-10-15 17:55:33'),
(26, 'Garage', '2020-10-15 17:55:38', '2020-10-15 17:55:38'),
(27, 'Lounge', '2020-10-15 17:55:43', '2020-10-15 17:55:43'),
(28, 'Utility Room', '2020-10-15 17:55:48', '2020-10-15 17:55:48'),
(29, 'Bathroom', '2020-10-15 17:55:52', '2020-10-15 17:55:52'),
(30, 'WC', '2020-10-15 17:55:58', '2020-10-15 17:55:58'),
(31, 'Pantry', '2020-10-15 17:56:01', '2020-10-15 17:56:01'),
(32, 'Basement', '2020-10-15 17:56:05', '2020-10-15 17:56:05'),
(33, 'Outdoor Room', '2020-10-15 17:56:09', '2020-10-15 17:56:09'),
(34, 'Bedroom', '2020-10-15 17:56:13', '2021-03-22 21:29:22'),
(35, 'Other Room', '2020-10-15 17:56:17', '2020-10-15 17:56:17');

-- --------------------------------------------------------

--
-- Table structure for table `current_boiler_types`
--

CREATE TABLE `current_boiler_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `current_boiler_types`
--

INSERT INTO `current_boiler_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(16, 'Combi', '2020-10-15 17:45:26', '2020-10-15 17:45:26'),
(17, 'Conventional Wall Hung', '2020-10-15 17:45:31', '2020-10-15 17:45:31'),
(18, 'System', '2020-10-15 17:45:37', '2020-10-15 17:45:37');

-- --------------------------------------------------------

--
-- Table structure for table `current_flues`
--

CREATE TABLE `current_flues` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `current_flues`
--

INSERT INTO `current_flues` (`id`, `name`, `created_at`, `updated_at`) VALUES
(10, 'Horizontal Flue', '2020-09-17 21:33:59', '2020-09-17 21:33:59'),
(11, 'Vertical Flue', '2020-09-17 21:34:05', '2020-09-17 21:34:05'),
(12, 'Balanced Flue', '2020-09-17 21:34:11', '2020-09-17 21:34:11'),
(17, 'High1', '2021-03-22 21:37:39', '2021-03-22 21:37:45');

-- --------------------------------------------------------

--
-- Table structure for table `deals`
--

CREATE TABLE `deals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `deal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `deal_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `idealproposal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `followup` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `negotation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lost` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `won` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `electrical_work_requireds`
--

CREATE TABLE `electrical_work_requireds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `electrical_work_requireds`
--

INSERT INTO `electrical_work_requireds` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(3, 'Connect on to existing wiring', 0, '2020-09-22 00:07:58', '2020-09-22 00:07:58'),
(4, 'New fused spur required', 0, '2020-09-22 00:08:06', '2020-09-22 00:08:06'),
(5, 'New fused spur + run required', 60, '2020-09-22 00:08:14', '2021-04-17 14:38:06'),
(6, 'Earth bonding', 0, '2020-09-22 00:08:20', '2020-09-22 00:08:20'),
(7, 'Full system rewire', 0, '2020-09-22 00:08:26', '2020-09-22 00:08:26'),
(13, 'DFTY', 90, '2021-03-23 00:00:38', '2021-03-23 00:00:49');

-- --------------------------------------------------------

--
-- Table structure for table `existing_showers`
--

CREATE TABLE `existing_showers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `existing_showers`
--

INSERT INTO `existing_showers` (`id`, `name`, `created_at`, `updated_at`) VALUES
(5, 'Electric Shower', '2020-09-17 23:03:19', '2020-09-17 23:03:19'),
(6, 'Power Shower', '2020-09-17 23:03:25', '2020-09-17 23:03:25'),
(7, 'Mixer Shower', '2020-09-17 23:03:30', '2020-09-17 23:03:30'),
(8, 'Digital Shower', '2020-09-17 23:03:36', '2020-09-17 23:03:36'),
(10, 'rertererte', '2020-10-16 00:43:06', '2020-10-16 00:43:12'),
(11, 'gher1', '2021-03-22 21:57:22', '2021-03-22 21:57:51'),
(12, 'ExisRT', '2021-03-22 22:25:37', '2021-03-22 22:26:06');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flue_kits`
--

CREATE TABLE `flue_kits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flue_kits`
--

INSERT INTO `flue_kits` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(5, '(1x) Horizontal Flue Kit', 0, '2020-09-22 19:35:14', '2020-09-22 19:35:14'),
(6, '(1x) Telescopic Flue Kit', 30, '2020-09-22 19:35:20', '2021-04-17 14:38:25'),
(7, '(1x) Vertical Flue Terminal', 0, '2020-09-22 19:35:26', '2020-09-22 19:35:26');

-- --------------------------------------------------------

--
-- Table structure for table `flue_kit_details`
--

CREATE TABLE `flue_kit_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flue_kit_details`
--

INSERT INTO `flue_kit_details` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(8, '(1x) 45° Flue Elbow [Pair]', '20', '2020-09-22 22:59:58', '2020-10-15 20:14:34'),
(9, '(1x) 87° Flue Elbow', '20', '2020-09-22 23:00:09', '2020-10-15 20:14:32'),
(10, '(2x) 87° Flue Elbow', '41', '2020-09-22 23:00:27', '2020-10-15 20:14:30'),
(11, '(1x) 1m Flue Extension', '40', '2020-09-22 23:00:37', '2020-10-15 20:14:29'),
(12, '(2x) 1m Flue Extension', '80', '2020-09-22 23:01:12', '2020-10-15 20:14:29'),
(15, '(3x) 1m Flue Extension', '120', '2020-09-22 23:01:42', '2020-10-15 20:14:28'),
(16, '(4x) 1m Flue Extension', '160', '2020-09-22 23:01:54', '2020-10-15 20:14:27'),
(17, '(1x) 2m Flue Extension', '40', '2020-09-22 23:02:03', '2020-10-15 20:14:26'),
(18, '(1x) 0.5m Flue Extension', '40', '2020-09-22 23:02:13', '2020-10-15 20:14:25');

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `folder_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id`, `folder_name`, `created_at`, `updated_at`) VALUES
(1, 'Home Visits', '2020-08-28 21:41:41', '2020-08-28 21:41:41'),
(2, 'Quote Calls', '2020-08-28 21:41:47', '2020-08-28 21:41:47'),
(3, 'new task', '2020-08-28 21:41:53', '2020-08-28 21:41:53'),
(4, 'new folder', '2020-08-31 21:36:05', '2020-08-31 21:36:05');

-- --------------------------------------------------------

--
-- Table structure for table `gas_supply_lengths`
--

CREATE TABLE `gas_supply_lengths` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gas_supply_lengths`
--

INSERT INTO `gas_supply_lengths` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(3, '0-3m', 30, '2020-09-22 00:47:42', '2020-10-15 19:45:37'),
(4, '3-6m', 60, '2020-09-22 00:47:48', '2020-10-15 19:45:43'),
(5, '6-9m', 120, '2020-09-22 00:47:54', '2020-10-15 19:45:47'),
(6, '9-12m', 150, '2020-09-22 00:48:00', '2020-10-15 19:45:50'),
(7, '12-15m', 200, '2020-09-22 00:48:06', '2020-10-15 19:45:56');

-- --------------------------------------------------------

--
-- Table structure for table `gas_supply_requirements`
--

CREATE TABLE `gas_supply_requirements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gas_supply_requirements`
--

INSERT INTO `gas_supply_requirements` (`id`, `name`, `created_at`, `updated_at`) VALUES
(6, 'Current gas supply deemed satisfactory', '2020-09-21 23:32:46', '2020-09-21 23:32:46'),
(7, 'Adaptation to existing gas supply required', '2020-09-21 23:32:53', '2020-09-21 23:32:53'),
(8, 'New external gas supply required', '2020-09-21 23:33:00', '2020-09-21 23:33:00'),
(9, 'New internal gas supply requiredyu', '2020-09-21 23:33:06', '2021-03-22 23:47:02');

-- --------------------------------------------------------

--
-- Table structure for table `heights`
--

CREATE TABLE `heights` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `heights`
--

INSERT INTO `heights` (`id`, `name`, `created_at`, `updated_at`) VALUES
(3, '300', '2020-10-14 19:23:40', '2020-10-14 19:23:40'),
(4, '400', '2020-10-14 19:23:42', '2020-10-14 19:23:42'),
(5, '500', '2020-10-14 19:23:44', '2020-10-14 19:23:44'),
(6, '600', '2020-10-14 19:23:45', '2020-10-14 19:23:45'),
(7, '700', '2020-10-14 19:23:46', '2020-10-14 19:23:46'),
(8, '800', '2020-10-14 19:23:48', '2020-10-14 19:23:48'),
(9, '900', '2020-10-14 19:23:53', '2020-10-14 19:23:53'),
(10, '1000', '2020-10-14 19:23:56', '2020-10-14 19:23:56'),
(11, '1100', '2020-10-14 19:23:58', '2020-10-14 19:23:58'),
(12, '1111', '2021-03-23 00:32:48', '2021-03-23 00:32:48');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `town` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobilenumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `landlinenumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leadsource` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userAssign_id` int(11) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `firstname`, `surname`, `address`, `postcode`, `town`, `country`, `email`, `mobilenumber`, `landlinenumber`, `leadsource`, `userAssign_id`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(2, 'sam', 'curran', 'Aylworth', '548', 'Gloucestershire', 'united kingdom', 'sam@gmail.com', '54886544', '65661311', 'Social Media', 10, 'NI Lead', '10', '2021-05-15 19:20:04', '2021-06-01 18:54:11'),
(3, 'shane', 'watson', 'Ayton Castle', '548', 'Berwickshire', 'united kingdom', 'shane@gmail.com', '89566', '65661311', 'Existing Customer', 13, 'NI Lead', '13', '2021-05-17 19:44:35', '2021-06-01 18:53:48'),
(4, 'jos', 'butler', 'Aywick', 'ea456', 'Shetland', 'united kingdom', 'jos1@gmail.com', '856998', '25566555', 'Social Media', 13, 'NI Lead', '13', '2021-05-18 19:46:26', '2021-06-01 18:53:30'),
(5, 'Alisha', 'Wilson', 'Ayshford', '751010', 'Devon', 'united kingdom', 'alisha@qtonix.com', '31551051245', NULL, 'Price Engine', 10, 'NI Lead', '10', '2021-05-18 20:44:21', '2021-06-01 18:53:13'),
(6, 'Test', 'Lead', 'Auldhouse', '751001', 'Lanarkshire', 'united kingdom', 'test@gmail.com', '4546455454', '5555555', 'Social Media', 11, 'NI Lead', '11', '2021-05-18 21:18:09', '2021-05-28 22:23:47'),
(7, 'struat', 'board', 'Aydon Road Estate', '459', 'Northumberland', 'united kingdom', 'struat@gmail.com', '85639', '23365589', 'Social Media', 14, 'Hot Lead', '14', '2021-05-18 21:25:40', '2021-06-09 20:36:33'),
(8, 'andrew', 'flintoff', 'Ayton Castle', '5896', 'Berwickshire', 'united kingdom', 'andrew@gmail.com', '55662', '56669090', 'Existing Customer', 13, 'NI Lead', '13', '2021-05-19 14:53:07', '2021-05-28 22:22:18'),
(10, 'Filter', 'Test', 'Auldhouse', '751001', 'Lanarkshire', 'united kingdom', 'info.test@gmail.com', '4546455454', '900465654654', 'PPC', 10, 'NI Lead', '10', '2021-05-20 16:16:53', '2021-05-28 22:19:31'),
(11, 'andrew', 'flintoff', 'Ayton Castle', '5896', 'Berwickshire', 'united kingdom', 'andrew@gmail.com', '55662', '65661311', 'Guide', 14, 'NI Lead', '14', '2021-05-20 20:51:12', '2021-06-09 20:20:57'),
(12, 'test', 'test', 'test', 'test', 'test', 'united kingdom', 'test@test.com', 'test', 'test', 'PPC', 1, 'NI Lead', '1', '2021-05-24 22:47:33', '2021-05-28 22:18:43'),
(13, 'Heather', 'Harvey', 'ML', 'ML74JN', 'ML', 'united kingdom', 'heatherimh1991@gmail.com', '07597970999', NULL, 'Organic Boiler', 1, 'New Lead', '1', '2021-05-28 22:17:54', '2021-05-28 22:17:54'),
(14, 'Pauline', 'Street', 'Uddingston', 'G71 7QP', 'g', 'united kingdom', 'streetpauline1@gmail.com', '07578094836', NULL, 'Social Media', 16, 'Hot Lead', '16', '2021-06-01 19:01:01', '2021-06-01 19:01:17'),
(15, 'steven', 'manson', 'Whitehill', 'EH22 2QH', 'Edin', 'united kingdom', 'smjmanson@gmail.com', '07973975729', NULL, 'Organic Boiler', 16, 'Hot Lead', '16', '2021-06-01 19:03:02', '2021-06-01 19:03:26'),
(16, 'nikita', 'cowan', 'Dunning', 'PH2 0QT', 'ph', 'united kingdom', 'cowannikita22@gmail.com', '07881453772', NULL, 'Organic Boiler', 15, 'Hot Lead', '15', '2021-06-01 19:05:03', '2021-06-01 19:05:11'),
(17, 'STUART', 'MCKASCILL', 'Perth', 'PH1 1RP', 'p', 'united kingdom', 'j@n.com', '07707982885', NULL, 'PPC', 15, 'Hot Lead', '15', '2021-06-01 19:08:03', '2021-06-01 19:08:16'),
(18, 'Abraham', ',', 'Glenrothes', 'KY7 5EA', 'Fife', 'united kingdom', 'shybijose007@yahoo.co.uk', '07902874749', NULL, 'Organic Boiler', 15, 'Cold Lead', '15', '2021-06-01 19:09:58', '2021-06-01 19:10:38'),
(19, 'Abraham', ',', 'Glenrothes', 'KY7 5EA', 'Fife', 'united kingdom', 'shybijose007@yahoo.co.uk', '07902874749', NULL, 'Organic Boiler', 15, 'New Lead', '15', '2021-06-01 19:09:59', '2021-06-01 19:09:59'),
(20, 'neil', 'fangster', 'Arbroath', 'DD11 4GU', 'd', 'united kingdom', 'b@b.com', '0748282799', NULL, 'PPC', 15, 'New Lead', '15', '2021-06-01 19:13:06', '2021-06-01 19:13:06'),
(21, 'Lukasz', 'wawrszczyk', 'Perth', 'PH1 2QZ', 'ph', 'united kingdom', 'wawrszczyklukasz@poczta.onet.pl', '07533505009', NULL, 'Organic Boiler', 15, 'New Lead', '15', '2021-06-01 19:15:12', '2021-06-01 19:15:12'),
(22, 'Mark', 'Mitchell', 'ab', 'AB24 2BL', 'ab', 'united kingdom', 'arablade49@yahoo.co.uk', '07714219730', NULL, 'Organic Boiler', 15, 'New Lead', '15', '2021-06-04 00:44:30', '2021-06-04 00:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `lead_quotations`
--

CREATE TABLE `lead_quotations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `main_uniqid` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_type_required` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_regular_boiler_choice` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `second_regular_boiler_choice` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `third_regular_boiler_choice` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_boiler_controls` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `second_boiler_controls` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `third_boiler_controls` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bolt_ons` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cus_firstname` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cus_surname` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cus_email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cus_installation_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cus_postal_code` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cus_street_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_boiler_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_boiler_location` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_flue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `existing_shower` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_fuel_type` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_boiler_yype` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_boiler_location` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_flue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_flue_location` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condensate_termination` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_controls` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_the_new_boiler_being_fitted_in_a_cupboard` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_the_newboiler_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `removals` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `materials_check` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `materials_check_options` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chemical_system_treatment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supply_change` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gas_supply_length` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `electrical_work_required` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `asbestos_containing_materials` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parking_requirements` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sixty_hundred_mm_flue_kit` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gchoice` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condesnate` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condesnate_input` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_height` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_width` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_color` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_psd` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trv_size_from` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trv_size_to` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trv_quantity` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_height` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_width` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `torv_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `torv_angel` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `torv_number` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oe_description` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oe_quantity` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oe_price` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `60_100mm_flue_kit_details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `magnetic_system_filter` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_central_heating_parts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condensate_components` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_condensate_components` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vented_cylinder_dimensions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `radiator_requirements` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_many_days_of_engineer_labour` int(11) DEFAULT NULL,
  `radiator_measurement_location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `radiator_measurement_height` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `radiator_measurement_width` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `radiator_measurement_sign` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thermostatic_radiator_size` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thermostatic_radiator_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thermostatic_radiator_qty` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes_to_officer_engineer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_1_guide_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_2_guide_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_3_guide_price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_1_Amend` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `will_the_cupboard_need_altering` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_2_Amend` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler_3_Amend` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boiler1_total_price` int(255) DEFAULT NULL,
  `boiler2_total_price` int(255) DEFAULT NULL,
  `boiler3_total_price` int(255) DEFAULT NULL,
  `deposit_required` int(11) DEFAULT NULL,
  `email_quote_to_customer_now` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `userrole` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_quotations`
--

INSERT INTO `lead_quotations` (`id`, `main_uniqid`, `lead_id`, `boiler_type_required`, `first_regular_boiler_choice`, `second_regular_boiler_choice`, `third_regular_boiler_choice`, `first_boiler_controls`, `second_boiler_controls`, `third_boiler_controls`, `bolt_ons`, `cus_firstname`, `cus_surname`, `cus_email`, `cus_installation_address`, `cus_postal_code`, `cus_street_address`, `current_boiler_type`, `current_boiler_location`, `current_flue`, `existing_shower`, `new_fuel_type`, `new_boiler_yype`, `new_boiler_location`, `new_flue`, `new_flue_location`, `condensate_termination`, `new_controls`, `is_the_new_boiler_being_fitted_in_a_cupboard`, `is_the_newboiler_status`, `removals`, `materials_check`, `materials_check_options`, `chemical_system_treatment`, `supply_change`, `gas_supply_length`, `electrical_work_required`, `asbestos_containing_materials`, `parking_requirements`, `sixty_hundred_mm_flue_kit`, `gchoice`, `condesnate`, `condesnate_input`, `rml_location`, `rml_height`, `rml_width`, `trm_color`, `rml_psd`, `trv_size_from`, `trv_size_to`, `trv_quantity`, `trm_location`, `trm_height`, `trm_width`, `torv_type`, `torv_angel`, `torv_number`, `oe_description`, `oe_quantity`, `oe_price`, `60_100mm_flue_kit_details`, `magnetic_system_filter`, `additional_central_heating_parts`, `condensate_components`, `additional_condensate_components`, `vented_cylinder_dimensions`, `radiator_requirements`, `how_many_days_of_engineer_labour`, `radiator_measurement_location`, `radiator_measurement_height`, `radiator_measurement_width`, `radiator_measurement_sign`, `thermostatic_radiator_size`, `thermostatic_radiator_type`, `thermostatic_radiator_qty`, `additional_notes`, `notes_to_officer_engineer`, `boiler_1_guide_price`, `boiler_2_guide_price`, `boiler_3_guide_price`, `boiler_1_Amend`, `will_the_cupboard_need_altering`, `boiler_2_Amend`, `boiler_3_Amend`, `boiler1_total_price`, `boiler2_total_price`, `boiler3_total_price`, `deposit_required`, `email_quote_to_customer_now`, `user_id`, `userrole`, `created_at`, `updated_at`) VALUES
(6, 'MPH05205933', '9', '2', '311', '325', '328', '82', '91', '82', NULL, 'struat', 'flintoff', 'andrew@gmail.com', 'Ayton Castle', '5896', 'Berwickshire', NULL, NULL, NULL, NULL, '6', NULL, NULL, NULL, NULL, NULL, '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', 'Not Required|0', NULL, NULL, NULL, NULL, NULL, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, '2752.99', '2888.99', '2628.99', NULL, NULL, NULL, NULL, 2753, 2889, 2629, NULL, NULL, 13, 2, '2021-05-20 15:59:33', '2021-05-20 16:12:59'),
(7, 'MPH05201311', '10', '1', '281', '281', '281', '84', '82', '83', NULL, 'Filter', 'Test', 'info.test@gmail.com', 'Auldhouse', '751001', 'Lanarkshire', '16', '32', '12', '8', '7', '4', '27', '13', '6', '11', '7', 'Yes', NULL, '[\"4\"]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '2021-05-20 20:13:11', '2021-05-20 20:14:02'),
(8, 'MPH05201915', '6', '2', '324', '325', '325', '80', '81', '79', NULL, 'Test', 'Lead', 'test@gmail.com', 'Auldhouse', '751001', 'Lanarkshire', '16', '9', '11', '6', '6', '4', '33', '14', '9', '12', '6', 'Yes', NULL, '[\"5\"]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 11, 2, '2021-05-20 20:19:15', '2021-05-20 20:20:21'),
(14, 'MPH05244803', '12', '3', '304', '348', '352', '76', '71', '74', NULL, 'test', 'test', 'test@test.com', 'test', 'test', 'test', '16', '8', '10', '7', '5', '3', '8', '13', '5', '7', '8', 'Yes', NULL, '[\"3\"]', '5', NULL, '28', '6', '3', '[\"3\"]', '4', '2', NULL, NULL, 'Not Required|0', '[\"(1x) Condense Pump|0\"]', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', 'Not Required|0', NULL, NULL, '7', NULL, 1, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, '2311', '2085', '1856', '100', '5', '100', '100', 2411, 2185, 1956, 100, 'No', 1, 1, '2021-05-24 22:48:03', '2021-05-24 22:49:41'),
(15, 'MPH06034436', '22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-04 00:44:36', '2021-06-04 00:44:36'),
(16, 'MPH06035329', '22', '3', '321', '332', '381', '76', '76', '76', NULL, 'Mark', 'Mitchell', 'arablade49@yahoo.co.uk', 'ab', 'AB24 2BL', 'ab', '16', '35', '10', '7', '5', '3', '35', '13', '5', '7', '8', 'No', NULL, '[\"3\"]', '5', NULL, '28', '6', NULL, '[\"3\"]', '4', '3', NULL, NULL, 'Not Required|0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1200 x 600', '1', '300', NULL, '4', 'Not Required|0', NULL, NULL, NULL, '[\"radiotorsreq\"]', 1, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, '3570', '4073', '4189', '230', NULL, '-173', '-189', 3800, 3900, 4000, 0, 'No', 1, 1, '2021-06-04 00:53:29', '2021-06-09 20:03:58'),
(17, 'MPH06094857', '22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-09 19:48:57', '2021-06-09 19:48:57'),
(18, 'MPH06095021', '22', '1', '282', '281', '282', '77', '77', '79', NULL, 'Mark', 'Mitchell', 'arablade49@yahoo.co.uk', 'ab', 'AB24 2BL', 'ab', '16', '25', '12', '7', '6', '4', '28', '14', '8', '10', '8', 'Yes', NULL, '[\"4\"]', NULL, NULL, '27', '7', '5', '[\"3\"]', '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', 'Not Required|0', NULL, NULL, NULL, NULL, NULL, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, '3177.83', '3125.83', '3233.44', '1', '7', '2', '3', 3178, 3127, 3236, 55, 'Yes', 1, 1, '2021-06-09 19:50:21', '2021-06-09 19:54:19'),
(19, 'MPH06095500', '20', '2', '327', '328', '329', NULL, NULL, NULL, NULL, 'neil', 'fangster', 'b@b.com', 'Arbroath', 'DD11 4GU', 'd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '2021-06-09 19:55:00', '2021-06-09 19:55:28'),
(20, 'MPH06095905', '20', '1', '281', '282', '314', '79', '80', '82', NULL, 'neil', 'fangster', 'b@b.com', 'Arbroath', 'DD11 4GU', 'd', '16', '27', '12', '5', '6', '3', '29', '14', '6', '9', '8', NULL, NULL, NULL, '6', NULL, '28', '7', '5', '[\"5\"]', '5', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', 'Not Required|0', NULL, NULL, NULL, '[\"trvs\"]', NULL, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, '2906.44', '2820.37', '2757.99', NULL, NULL, NULL, NULL, 2906, 2820, 2758, NULL, NULL, 1, 1, '2021-06-09 19:59:05', '2021-06-09 20:03:09'),
(23, 'MPH06094000', '11', '3', '337', '341', '343', '77', '79', '80', NULL, 'andrew', 'flintoff', 'andrew@gmail.com', 'Ayton Castle', '5896', 'Berwickshire', '16', '27', '11', '7', '6', '4', '28', '13', '6', '9', '8', 'Yes', NULL, NULL, '6', '[\"12\"]', '28', '7', '4', '[\"5\"]', '5', '4', NULL, NULL, 'Required|0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test', '2', '100', NULL, '5', 'Not Required|0', NULL, NULL, NULL, NULL, NULL, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, '2764.83', '2877.44', '2812.37', NULL, '7', NULL, NULL, 2765, 2877, 2812, NULL, NULL, 14, 2, '2021-06-09 20:40:00', '2021-06-09 21:07:05'),
(24, 'MPH06162818', '7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'struat', 'board', 'struat@gmail.com', 'Aydon Road Estate', '459', 'Northumberland', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4', 'Not Required|0', NULL, NULL, NULL, NULL, NULL, 'Bedroom 1', '300', '400', 'P+', '8mm', 'Straight TRV', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 14, 2, '2021-06-16 18:28:18', '2021-06-16 18:28:40');

-- --------------------------------------------------------

--
-- Table structure for table `magnetic_system_filters`
--

CREATE TABLE `magnetic_system_filters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `magnetic_system_filters`
--

INSERT INTO `magnetic_system_filters` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(4, '(1x) 22mm Adey Magnaclean Filter', 0, '2020-09-22 21:49:24', '2020-09-22 21:49:24'),
(5, '(1x) 28mm Adey Magnaclean Filter', 80, '2020-09-22 21:49:29', '2021-04-17 14:38:31');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2014_10_12_000000_create_users_table', 1),
(8, '2014_10_12_100000_create_password_resets_table', 1),
(9, '2019_08_19_000000_create_failed_jobs_table', 1),
(10, '2019_10_22_064309_create_contact_lists_table', 1),
(11, '2020_06_04_112454_create_leads_table', 1),
(12, '2020_06_05_101922_add_status_to_leads_table', 1),
(13, '2020_06_10_093501_create_notes_table', 1),
(14, '2020_06_10_093629_create_calls_table', 1),
(15, '2020_06_17_063758_create_call_note_table', 1),
(16, '2020_06_17_071501_add_duration_column_to_call_note_table', 1),
(17, '2020_06_17_105237_create_scheduletasks_table', 1),
(18, '2020_06_18_064940_add_lead_id_to_scheduletasks', 1),
(19, '2020_06_18_065020_add_user_id_to_scheduletasks', 1),
(20, '2020_06_18_080636_add_status_to_scheduletasks_table', 1),
(21, '2020_06_24_103500_add_attachment_file_to_call_note_table', 1),
(22, '2020_06_25_060625_add_format_to_call_note', 1),
(23, '2020_06_25_062510_add_filename_to_call_note_table', 1),
(24, '2020_07_04_125937_create_boilers_table', 1),
(25, '2020_07_04_144610_create_boilerchoises_table', 1),
(26, '2020_07_06_054725_create_boilertypechildrens_table', 1),
(27, '2020_07_14_121605_create_deals_table', 1),
(28, '2020_07_15_092117_add_order_to_deals', 1),
(29, '2020_07_15_110038_add_ideal_proposal_and_followup_and_negotiation_and_lost_own_to_deals_table', 1),
(30, '2020_07_17_021919_create_tasks_table', 1),
(31, '2020_07_17_022118_create_statuses_table', 1),
(32, '2020_07_17_064449_add_price_to_tasks', 1),
(33, '2020_07_17_072058_add_lead_id_to_tasks', 1),
(34, '2020_07_17_074402_add_lead_id_to_statuses', 1),
(35, '2020_07_30_163828_create_notifications_table', 1),
(36, '2020_07_31_112948_add_notification_type_to_notifications_tabls', 1),
(37, '2020_07_31_114656_add_created_by_notifications_table', 1),
(38, '2020_08_03_140326_aletr_table_call_note', 1),
(39, '2020_08_03_140352_alter_table_call_note', 1),
(40, '2020_08_27_174102_create_templates_table', 1),
(41, '2020_08_27_184008_create_campaigns_table', 1),
(42, '2020_08_27_184334_create_folders_table', 1),
(43, '2020_08_28_140528_create_postcodes_table', 2),
(44, '2020_08_31_134607_add_slug_table_to_campaigns_table', 3),
(45, '2020_08_31_145105_add_publish_to_templates_table', 4),
(46, '2020_09_07_111906_create_boilertypes_table', 5),
(47, '2020_09_11_105248_create_selectradiocheckboxchoices_table', 6),
(48, '2020_09_16_150927_create_boiler_controls_table', 7),
(49, '2020_09_17_102834_create_bolt_ons_table', 8),
(50, '2020_09_17_114444_create_current_boiler_types_table', 9),
(51, '2020_09_17_121813_create_current_boiler_locations_table', 10),
(52, '2020_09_17_141717_create_current_flues_table', 11),
(53, '2020_09_17_154522_create_existing_showers_table', 12),
(54, '2020_09_17_162356_create_newfule_types_table', 13),
(55, '2020_09_17_173552_create_new_boiler_types_table', 14),
(56, '2020_09_18_091229_create_new_flues_table', 15),
(57, '2020_09_18_093246_create_new_flue_locations_table', 16),
(58, '2020_09_18_094850_create_condensate_terminations_table', 17),
(59, '2020_09_18_102800_create_new_controls_table', 18),
(60, '2020_09_18_104458_create_removals_table', 19),
(61, '2020_09_21_121231_create_cupboard_need_alts_table', 20),
(62, '2020_09_21_145907_create_chemical_system_treatments_table', 21),
(63, '2020_09_21_154321_create_gas_supply_requirements_table', 22),
(64, '2020_09_21_164239_create_electrical_work_requireds_table', 23),
(65, '2020_09_21_171019_create_gas_supply_lengths_table', 24),
(66, '2020_09_22_102544_create_a_c_m_s_table', 25),
(67, '2020_09_22_105321_create_parking_requirements_table', 26),
(68, '2020_09_22_111641_create_flue_kits_table', 27),
(69, '2020_09_22_123836_create_magnetic_system_filters_table', 28),
(70, '2020_09_22_145659_create_flue_kit_details_table', 29),
(71, '2020_09_22_160947_create_vented_cylinder_dimensions_table', 30),
(72, '2020_09_22_163112_create_radiator_requirements_table', 31),
(73, '2020_09_25_120022_create_optional_extras_table', 32),
(74, '2020_09_28_112839_create_qtn_radiator_measurement_locations_table', 33),
(75, '2020_09_28_124218_create_qtn_thermostatic_radiator_valves_table', 34),
(76, '2020_09_28_142857_create_qtn_towel_rail_measurements_table', 35),
(77, '2020_09_28_151731_create_qtn_towel_rail_valves_table', 36),
(78, '2020_09_28_164500_create_qtn_optional_descriptions_table', 37),
(79, '2020_09_29_111820_create_lead_quotations_table', 38),
(80, '2020_10_14_120439_create_heights_table', 39),
(81, '2020_10_14_122422_create_widths_table', 40),
(82, '2021_04_21_122216_create_boltschoosens_table', 41);

-- --------------------------------------------------------

--
-- Table structure for table `newfule_types`
--

CREATE TABLE `newfule_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `newfule_types`
--

INSERT INTO `newfule_types` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(5, 'Gas', 0, '2020-09-18 00:26:57', '2020-09-18 00:26:57'),
(6, 'Oil', 80, '2020-09-18 00:27:06', '2021-04-17 14:35:49'),
(7, 'LPG', 0, '2020-09-18 00:27:16', '2020-09-18 00:27:16'),
(8, 'Electric', 0, '2020-09-18 00:27:24', '2020-09-18 00:27:24'),
(14, 'RTLFG', 655, '2021-03-22 22:35:36', '2021-03-22 22:35:56');

-- --------------------------------------------------------

--
-- Table structure for table `new_boiler_types`
--

CREATE TABLE `new_boiler_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_boiler_types`
--

INSERT INTO `new_boiler_types` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(3, 'Combi', 0, '2020-09-18 01:07:53', '2020-09-18 01:07:53'),
(4, 'Conventional', 60, '2020-09-18 01:08:01', '2021-04-17 14:35:54'),
(5, 'System', 0, '2020-09-18 01:08:09', '2020-09-18 01:08:09');

-- --------------------------------------------------------

--
-- Table structure for table `new_controls`
--

CREATE TABLE `new_controls` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_controls`
--

INSERT INTO `new_controls` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(4, 'Connect on to Existing', 0, '2020-09-18 17:42:33', '2020-09-18 17:42:33'),
(5, 'Customer to Supply', 0, '2020-09-18 17:42:41', '2020-09-18 17:42:41'),
(6, 'New Programmer Only', 0, '2020-09-18 17:42:47', '2020-09-18 17:42:47'),
(7, 'New Thermostat Only', 89, '2020-09-18 17:43:00', '2021-04-17 14:36:15'),
(8, 'New Programmer + Thermostat', 0, '2020-09-18 17:43:06', '2020-09-18 17:43:06'),
(9, 'New Programmable Thermostat', 0, '2020-09-18 17:43:15', '2020-09-18 17:43:15'),
(14, 'RIGHTYUGH', 45, '2021-03-22 23:32:20', '2021-03-22 23:32:30');

-- --------------------------------------------------------

--
-- Table structure for table `new_flues`
--

CREATE TABLE `new_flues` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_flues`
--

INSERT INTO `new_flues` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(13, 'Horizontal', 0, '2020-09-18 16:30:32', '2020-10-15 18:48:54'),
(14, 'Vertical', 46, '2020-09-18 16:30:37', '2021-04-17 14:36:05'),
(20, 'DFGH', 45, '2021-03-22 23:16:49', '2021-03-22 23:16:56');

-- --------------------------------------------------------

--
-- Table structure for table `new_flue_locations`
--

CREATE TABLE `new_flue_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_flue_locations`
--

INSERT INTO `new_flue_locations` (`id`, `name`, `created_at`, `updated_at`) VALUES
(5, 'Ground Floor', '2020-09-18 16:46:41', '2020-09-18 16:46:41'),
(6, 'First Floor', '2020-09-18 16:46:47', '2020-09-18 16:46:47'),
(7, 'Second Floor', '2020-09-18 16:46:53', '2020-09-18 16:46:53'),
(8, 'Third Floor', '2020-09-18 16:46:59', '2020-09-18 16:46:59'),
(9, 'Fourth Floor', '2020-09-18 16:47:07', '2020-09-18 16:47:07'),
(10, 'Fifth Floor', '2020-09-18 16:47:14', '2020-09-18 16:47:14');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unqid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `user_id` int(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `unqid`, `message`, `lead_id`, `user_id`, `created_at`, `updated_at`) VALUES
(112, NULL, 'Test...............', 2, 1, '2021-05-17 19:43:01', '2021-05-17 19:43:01'),
(117, NULL, 'ok', 10, 1, '2021-05-20 21:10:44', '2021-05-20 21:10:44');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deal_id` int(11) DEFAULT NULL,
  `call_id` int(11) DEFAULT NULL,
  `scheduletask_id` int(11) DEFAULT NULL,
  `note_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `update_user` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `notificationType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userAssign_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `lead_id`, `user_id`, `deal_id`, `call_id`, `scheduletask_id`, `note_id`, `status`, `update_user`, `created_at`, `updated_at`, `notificationType`, `userAssign_id`, `created_by`) VALUES
(1, 2, 1, 4, NULL, NULL, NULL, 0, 0, '2021-05-17 18:13:23', '2021-05-17 18:13:23', 'deal', 11, 1),
(2, 2, 11, 5, NULL, NULL, NULL, 0, 0, '2021-05-17 18:16:20', '2021-05-17 18:16:20', 'deal', 11, 11),
(3, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 18:18:01', '2021-05-17 18:18:01', 'meeting', NULL, 1),
(4, 2, 11, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 18:19:44', '2021-05-17 18:19:44', 'meeting', NULL, 11),
(5, 2, 1, 6, NULL, NULL, NULL, 0, 0, '2021-05-17 18:42:18', '2021-05-17 18:42:18', 'deal', 11, 1),
(6, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 18:42:54', '2021-05-17 18:42:54', 'meeting', NULL, 1),
(7, 2, 11, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 18:44:20', '2021-05-17 18:44:20', 'meeting', NULL, 11),
(8, 2, 1, 7, NULL, NULL, NULL, 0, 0, '2021-05-17 18:46:24', '2021-05-17 18:46:24', 'deal', 10, 1),
(9, 2, 11, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 18:50:25', '2021-05-17 18:50:25', 'meeting', NULL, 11),
(10, 2, 1, 8, NULL, NULL, NULL, 0, 0, '2021-05-17 19:25:35', '2021-05-17 19:25:35', 'deal', 10, 1),
(11, 2, 1, 9, NULL, NULL, NULL, 0, 0, '2021-05-17 19:26:16', '2021-05-17 19:26:16', 'deal', 10, 1),
(12, 2, 1, 10, NULL, NULL, NULL, 0, 0, '2021-05-17 19:35:43', '2021-05-17 19:35:43', 'deal', 11, 1),
(13, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 19:43:01', '2021-05-17 19:43:01', 'note', NULL, 1),
(14, 3, 12, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 19:44:35', '2021-05-17 19:44:35', 'lead', NULL, 0),
(15, 3, 1, 11, NULL, NULL, NULL, 0, 0, '2021-05-17 19:45:04', '2021-05-17 19:45:04', 'deal', 12, 1),
(16, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 19:46:36', '2021-05-17 19:46:36', 'meeting', NULL, 1),
(17, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 19:55:52', '2021-05-17 19:55:52', 'meeting', NULL, 1),
(18, 2, 1, 12, NULL, NULL, NULL, 0, 0, '2021-05-17 19:59:25', '2021-05-17 19:59:25', 'deal', 10, 1),
(19, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 19:59:36', '2021-05-17 19:59:36', 'meeting', NULL, 1),
(20, 1, 10, 13, NULL, NULL, NULL, 0, 0, '2021-05-17 20:01:12', '2021-05-17 20:01:12', 'deal', 10, 10),
(21, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 20:03:29', '2021-05-17 20:03:29', 'meeting', NULL, 1),
(22, 1, 1, 14, NULL, NULL, NULL, 0, 0, '2021-05-17 20:08:23', '2021-05-17 20:08:23', 'deal', 10, 1),
(23, 1, 10, 15, NULL, NULL, NULL, 0, 0, '2021-05-17 20:10:32', '2021-05-17 20:10:32', 'deal', 10, 10),
(24, 2, 1, 16, NULL, NULL, NULL, 0, 0, '2021-05-17 21:26:09', '2021-05-17 21:26:09', 'deal', 11, 1),
(25, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-17 22:22:25', '2021-05-17 22:22:25', 'note', NULL, 1),
(26, 4, 13, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:46:26', '2021-05-18 19:46:26', 'lead', NULL, 0),
(27, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:48:18', '2021-05-18 19:48:18', 'note', NULL, 1),
(28, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:49:02', '2021-05-18 19:49:02', 'call', NULL, 1),
(29, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:50:40', '2021-05-18 19:50:40', 'meeting', NULL, 1),
(30, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:53:08', '2021-05-18 19:53:08', 'meeting', NULL, 1),
(31, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:55:39', '2021-05-18 19:55:39', 'meeting', NULL, 1),
(32, 4, 13, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 19:57:17', '2021-05-18 19:57:17', 'meeting', NULL, 13),
(33, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 20:00:04', '2021-05-18 20:00:04', 'meeting', NULL, 1),
(34, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 20:01:36', '2021-05-18 20:01:36', 'meeting', NULL, 1),
(35, 5, 10, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 20:44:21', '2021-05-18 20:44:21', 'lead', NULL, 0),
(36, 6, 11, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 21:18:09', '2021-05-18 21:18:09', 'lead', NULL, 0),
(37, 7, 13, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 21:25:40', '2021-05-18 21:25:40', 'lead', NULL, 0),
(38, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 22:53:13', '2021-05-18 22:53:13', 'call', NULL, 1),
(39, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 22:54:34', '2021-05-18 22:54:34', 'call', NULL, 1),
(40, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-18 22:58:51', '2021-05-18 22:58:51', 'meeting', NULL, 1),
(41, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:36:24', '2021-05-19 14:36:24', 'meeting', NULL, 1),
(42, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:45:29', '2021-05-19 14:45:29', 'meeting', NULL, 1),
(43, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:47:32', '2021-05-19 14:47:32', 'meeting', NULL, 1),
(44, 7, 13, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:48:32', '2021-05-19 14:48:32', 'meeting', NULL, 13),
(45, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:52:50', '2021-05-19 14:52:50', 'meeting', NULL, 1),
(46, 8, 13, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:53:07', '2021-05-19 14:53:07', 'lead', NULL, 0),
(47, 6, 11, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:54:29', '2021-05-19 14:54:29', 'meeting', NULL, 11),
(48, 9, 12, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 14:54:31', '2021-05-19 14:54:31', 'lead', NULL, 0),
(49, 8, 1, 17, NULL, NULL, NULL, 0, 0, '2021-05-19 14:55:43', '2021-05-19 14:55:43', 'deal', 13, 1),
(50, 6, 1, 1, NULL, NULL, NULL, 0, 0, '2021-05-19 15:02:21', '2021-05-19 15:02:21', 'deal', 11, 1),
(51, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:04:01', '2021-05-19 15:04:01', 'call', NULL, 1),
(52, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:04:37', '2021-05-19 15:04:37', 'call', NULL, 1),
(53, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:04:47', '2021-05-19 15:04:47', 'call', NULL, 1),
(54, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:05:33', '2021-05-19 15:05:33', 'call', NULL, 1),
(55, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:06:58', '2021-05-19 15:06:58', 'call', NULL, 1),
(56, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:08:52', '2021-05-19 15:08:52', 'call', NULL, 1),
(57, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:09:16', '2021-05-19 15:09:16', 'call', NULL, 1),
(58, 8, 1, 2, NULL, NULL, NULL, 0, 0, '2021-05-19 15:25:35', '2021-05-19 15:25:35', 'deal', 13, 1),
(59, 8, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:32:50', '2021-05-19 15:32:50', 'meeting', NULL, 1),
(60, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:51:54', '2021-05-19 15:51:54', 'call', NULL, 1),
(61, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:54:34', '2021-05-19 15:54:34', 'call', NULL, 1),
(62, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 15:55:14', '2021-05-19 15:55:14', 'call', NULL, 1),
(63, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 16:09:08', '2021-05-19 16:09:08', 'call', NULL, 1),
(64, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 16:09:49', '2021-05-19 16:09:49', 'call', NULL, 1),
(65, 5, 10, 3, NULL, NULL, NULL, 0, 0, '2021-05-19 16:32:03', '2021-05-19 16:32:03', 'deal', 10, 10),
(66, 2, 10, 4, NULL, NULL, NULL, 0, 0, '2021-05-19 16:38:57', '2021-05-19 16:38:57', 'deal', 10, 10),
(67, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 16:40:05', '2021-05-19 16:40:05', 'call', NULL, 1),
(68, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:02:10', '2021-05-19 19:02:10', 'call', NULL, 1),
(69, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:12:34', '2021-05-19 19:12:34', 'call', NULL, 1),
(70, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:23:40', '2021-05-19 19:23:40', 'call', NULL, 1),
(71, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:25:15', '2021-05-19 19:25:15', 'call', NULL, 1),
(72, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:32:02', '2021-05-19 19:32:02', 'call', NULL, 1),
(73, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:32:28', '2021-05-19 19:32:28', 'call', NULL, 1),
(74, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:34:27', '2021-05-19 19:34:27', 'call', NULL, 1),
(75, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:40:05', '2021-05-19 19:40:05', 'call', NULL, 1),
(76, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 19:46:05', '2021-05-19 19:46:05', 'call', NULL, 1),
(77, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:14:15', '2021-05-19 20:14:15', 'call', NULL, 1),
(78, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:32:36', '2021-05-19 20:32:36', 'call', NULL, 1),
(79, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:43:19', '2021-05-19 20:43:19', 'call', NULL, 1),
(80, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:43:28', '2021-05-19 20:43:28', 'call', NULL, 1),
(81, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:43:32', '2021-05-19 20:43:32', 'call', NULL, 1),
(82, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:47:22', '2021-05-19 20:47:22', 'call', NULL, 1),
(83, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:50:08', '2021-05-19 20:50:08', 'call', NULL, 1),
(84, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:50:28', '2021-05-19 20:50:28', 'call', NULL, 1),
(85, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:50:36', '2021-05-19 20:50:36', 'call', NULL, 1),
(86, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 20:59:26', '2021-05-19 20:59:26', 'call', NULL, 1),
(87, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:01:30', '2021-05-19 21:01:30', 'call', NULL, 1),
(88, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:01:30', '2021-05-19 21:01:30', 'call', NULL, 1),
(89, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:01:52', '2021-05-19 21:01:52', 'call', NULL, 1),
(90, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:07:41', '2021-05-19 21:07:41', 'call', NULL, 1),
(91, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:07:41', '2021-05-19 21:07:41', 'call', NULL, 1),
(92, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:08:22', '2021-05-19 21:08:22', 'call', NULL, 1),
(93, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:08:22', '2021-05-19 21:08:22', 'call', NULL, 1),
(94, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:14:47', '2021-05-19 21:14:47', 'call', NULL, 1),
(95, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:14:47', '2021-05-19 21:14:47', 'call', NULL, 1),
(96, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:16:39', '2021-05-19 21:16:39', 'call', NULL, 1),
(97, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:16:39', '2021-05-19 21:16:39', 'call', NULL, 1),
(98, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:19:10', '2021-05-19 21:19:10', 'call', NULL, 1),
(99, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:19:10', '2021-05-19 21:19:10', 'call', NULL, 1),
(100, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:20:50', '2021-05-19 21:20:50', 'call', NULL, 1),
(101, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:21:09', '2021-05-19 21:21:09', 'call', NULL, 1),
(102, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:21:09', '2021-05-19 21:21:09', 'call', NULL, 1),
(103, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:23:46', '2021-05-19 21:23:46', 'call', NULL, 1),
(104, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:26:10', '2021-05-19 21:26:10', 'call', NULL, 1),
(105, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:29:01', '2021-05-19 21:29:01', 'call', NULL, 1),
(106, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:29:10', '2021-05-19 21:29:10', 'call', NULL, 1),
(107, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:30:36', '2021-05-19 21:30:36', 'call', NULL, 1),
(108, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:42:52', '2021-05-19 21:42:52', 'call', NULL, 1),
(109, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:43:10', '2021-05-19 21:43:10', 'call', NULL, 1),
(110, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:44:37', '2021-05-19 21:44:37', 'call', NULL, 1),
(111, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:45:59', '2021-05-19 21:45:59', 'call', NULL, 1),
(112, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 21:49:01', '2021-05-19 21:49:01', 'call', NULL, 1),
(113, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 22:09:54', '2021-05-19 22:09:54', 'call', NULL, 1),
(114, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 22:10:31', '2021-05-19 22:10:31', 'call', NULL, 1),
(115, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 22:11:57', '2021-05-19 22:11:57', 'call', NULL, 1),
(116, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 22:14:16', '2021-05-19 22:14:16', 'call', NULL, 1),
(117, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-19 22:15:11', '2021-05-19 22:15:11', 'call', NULL, 1),
(118, 9, 13, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 14:47:50', '2021-05-20 14:47:50', 'call', NULL, 13),
(119, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 15:07:39', '2021-05-20 15:07:39', 'call', NULL, 1),
(120, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 15:07:45', '2021-05-20 15:07:45', 'call', NULL, 1),
(121, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 15:08:09', '2021-05-20 15:08:09', 'call', NULL, 1),
(122, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 15:09:13', '2021-05-20 15:09:13', 'call', NULL, 1),
(123, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 15:09:28', '2021-05-20 15:09:28', 'call', NULL, 1),
(124, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 15:52:02', '2021-05-20 15:52:02', 'meeting', NULL, 1),
(125, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 16:05:49', '2021-05-20 16:05:49', 'call', NULL, 1),
(126, 6, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 16:06:40', '2021-05-20 16:06:40', 'call', NULL, 1),
(127, 8, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 16:14:05', '2021-05-20 16:14:05', 'call', NULL, 1),
(128, 10, 10, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 16:16:53', '2021-05-20 16:16:53', 'lead', NULL, 0),
(129, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 16:17:08', '2021-05-20 16:17:08', 'call', NULL, 1),
(130, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 17:30:09', '2021-05-20 17:30:09', 'call', NULL, 1),
(131, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 17:30:35', '2021-05-20 17:30:35', 'call', NULL, 1),
(132, 5, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 17:36:10', '2021-05-20 17:36:10', 'call', NULL, 1),
(133, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 17:38:24', '2021-05-20 17:38:24', 'call', NULL, 1),
(134, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 17:39:08', '2021-05-20 17:39:08', 'call', NULL, 1),
(135, 3, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 18:14:51', '2021-05-20 18:14:51', 'call', NULL, 1),
(136, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 19:11:15', '2021-05-20 19:11:15', 'call', NULL, 1),
(137, 6, 11, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:01:52', '2021-05-20 20:01:52', 'call', NULL, 11),
(138, 9, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:06:40', '2021-05-20 20:06:40', 'call', NULL, 1),
(139, 8, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:07:14', '2021-05-20 20:07:14', 'call', NULL, 1),
(140, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:07:23', '2021-05-20 20:07:23', 'call', NULL, 1),
(141, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:07:24', '2021-05-20 20:07:24', 'call', NULL, 1),
(142, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:08:31', '2021-05-20 20:08:31', 'call', NULL, 1),
(143, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:19:02', '2021-05-20 20:19:02', 'meeting', NULL, 1),
(144, 8, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:46:22', '2021-05-20 20:46:22', 'call', NULL, 1),
(145, 11, 14, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:51:12', '2021-05-20 20:51:12', 'lead', NULL, 0),
(146, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:53:36', '2021-05-20 20:53:36', 'call', NULL, 1),
(147, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:53:51', '2021-05-20 20:53:51', 'call', NULL, 1),
(148, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:54:07', '2021-05-20 20:54:07', 'call', NULL, 1),
(149, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:54:12', '2021-05-20 20:54:12', 'call', NULL, 1),
(150, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:58:23', '2021-05-20 20:58:23', 'note', NULL, 1),
(151, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 20:59:15', '2021-05-20 20:59:15', 'note', NULL, 1),
(152, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:00:06', '2021-05-20 21:00:06', 'call', NULL, 1),
(153, 4, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:02:51', '2021-05-20 21:02:51', 'call', NULL, 1),
(154, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:03:11', '2021-05-20 21:03:11', 'call', NULL, 1),
(155, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:04:07', '2021-05-20 21:04:07', 'call', NULL, 1),
(156, 7, 14, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:04:19', '2021-05-20 21:04:19', 'meeting', NULL, 14),
(157, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:05:30', '2021-05-20 21:05:30', 'meeting', NULL, 1),
(158, 11, 14, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:09:02', '2021-05-20 21:09:02', 'meeting', NULL, 14),
(159, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:10:44', '2021-05-20 21:10:44', 'note', NULL, 1),
(160, 7, 1, 5, NULL, NULL, NULL, 0, 0, '2021-05-20 21:11:18', '2021-05-20 21:11:18', 'deal', 14, 1),
(161, 10, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-20 21:11:33', '2021-05-20 21:11:33', 'meeting', NULL, 1),
(162, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 13:55:30', '2021-05-21 13:55:30', 'note', NULL, 1),
(163, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 13:55:49', '2021-05-21 13:55:49', 'note', NULL, 1),
(164, 11, 14, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 13:56:22', '2021-05-21 13:56:22', 'call', NULL, 14),
(165, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 13:57:00', '2021-05-21 13:57:00', 'meeting', NULL, 1),
(166, 11, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 13:58:24', '2021-05-21 13:58:24', 'meeting', NULL, 1),
(167, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 14:08:10', '2021-05-21 14:08:10', 'call', NULL, 1),
(168, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 14:08:23', '2021-05-21 14:08:23', 'call', NULL, 1),
(169, 11, 14, 6, NULL, NULL, NULL, 0, 0, '2021-05-21 14:12:47', '2021-05-21 14:12:47', 'deal', 14, 14),
(170, 11, 14, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 14:14:02', '2021-05-21 14:14:02', 'call', NULL, 14),
(171, 2, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-21 14:15:51', '2021-05-21 14:15:51', 'call', NULL, 1),
(172, 12, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-24 22:47:33', '2021-05-24 22:47:33', 'lead', NULL, 0),
(173, 12, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-24 22:47:51', '2021-05-24 22:47:51', 'meeting', NULL, 1),
(174, 12, 1, 7, NULL, NULL, NULL, 0, 0, '2021-05-24 22:50:44', '2021-05-24 22:50:44', 'deal', 1, 1),
(175, 13, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-05-28 22:17:54', '2021-05-28 22:17:54', 'lead', NULL, 0),
(176, 14, 16, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:01:01', '2021-06-01 19:01:01', 'lead', NULL, 0),
(177, 14, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:01:44', '2021-06-01 19:01:44', 'meeting', NULL, 1),
(178, 15, 16, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:03:02', '2021-06-01 19:03:02', 'lead', NULL, 0),
(179, 15, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:04:02', '2021-06-01 19:04:02', 'meeting', NULL, 1),
(180, 16, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:05:03', '2021-06-01 19:05:03', 'lead', NULL, 0),
(181, 16, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:06:22', '2021-06-01 19:06:22', 'meeting', NULL, 1),
(182, 17, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:08:03', '2021-06-01 19:08:03', 'lead', NULL, 0),
(183, 17, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:08:38', '2021-06-01 19:08:38', 'meeting', NULL, 1),
(184, 18, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:09:58', '2021-06-01 19:09:58', 'lead', NULL, 0),
(185, 19, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:09:59', '2021-06-01 19:09:59', 'lead', NULL, 0),
(186, 19, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:11:20', '2021-06-01 19:11:20', 'meeting', NULL, 1),
(187, 20, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:13:06', '2021-06-01 19:13:06', 'lead', NULL, 0),
(188, 20, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:13:41', '2021-06-01 19:13:41', 'meeting', NULL, 1),
(189, 21, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:15:12', '2021-06-01 19:15:12', 'lead', NULL, 0),
(190, 21, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-01 19:15:51', '2021-06-01 19:15:51', 'meeting', NULL, 1),
(191, 22, 15, NULL, NULL, NULL, NULL, 0, 0, '2021-06-04 00:44:30', '2021-06-04 00:44:30', 'lead', NULL, 0),
(192, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-09 20:22:27', '2021-06-09 20:22:27', 'meeting', NULL, 1),
(193, 7, 1, 8, NULL, NULL, NULL, 0, 0, '2021-06-09 20:25:26', '2021-06-09 20:25:26', 'deal', 14, 1),
(194, 7, 1, NULL, NULL, NULL, NULL, 0, 0, '2021-06-09 20:28:39', '2021-06-09 20:28:39', 'note', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `optional_extras`
--

CREATE TABLE `optional_extras` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parking_requirements`
--

CREATE TABLE `parking_requirements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parking_requirements`
--

INSERT INTO `parking_requirements` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'Driveway', '2020-09-22 18:12:26', '2020-09-22 18:12:26'),
(3, 'Street Outside House', '2020-09-22 18:12:32', '2020-09-22 18:12:32'),
(4, 'Pay and Display', '2020-09-22 18:12:38', '2020-09-22 18:12:38'),
(5, 'Permit (To be Provided by Customer)', '2020-09-22 18:12:59', '2020-09-22 18:12:59'),
(6, 'Parking Elsewhere', '2020-09-22 18:13:06', '2020-09-22 18:13:06');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('mukeshpradhan1993@gmail.com', '$2y$10$iBE02N234QPfajpweNdTn..wMA54XFefzNLNWknI5l9sUgumIQ3w6', '2020-12-10 19:56:35'),
('prabhat.qtonix@gmail.com', '$2y$10$aAwu9e8HvjPXCmUcEALL0OdTM0CjVW4RdcfAEwcXYNciTw/L9/Erm', '2020-12-15 17:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `postcodes`
--

CREATE TABLE `postcodes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `postcodes`
--

INSERT INTO `postcodes` (`id`, `state`, `city`, `postcode`, `created_at`, `updated_at`) VALUES
(1, 'Surrey', 'Aaron\'s Hill', 'GU7 2', '2020-08-28 21:11:23', '2020-08-28 21:11:23'),
(2, 'Somerset', 'Abbas Combe', 'BA8 0', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(3, 'Worcestershire', 'Abberley', 'WR6 6', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(4, 'Essex', 'Abberton', 'CO5 7', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(5, 'Worcestershire', 'Abberton', 'WR10 2', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(6, 'Northumberland', 'Abberwick', 'NE66 2', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(7, 'Essex', 'Abbess End', 'CM5 0', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(8, 'Essex', 'Abbess Roding', 'CM5 0', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(9, 'Devon', 'Abbey', 'EX14 4', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(10, 'Powys', 'Abbeycwmhir / Abaty Cwm-hir', 'LD1 6', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(11, 'Gloucestershire', 'Abbeydale', 'GL4 4', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(12, 'South Yorkshire', 'Abbeydale', 'S8 0', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(13, 'Worcestershire', 'Abbeydale', 'B98 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(14, 'South Yorkshire', 'Abbeydale Park', 'S17 3', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(15, 'Herefordshire', 'Abbey Dore', 'HR2 0', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(16, 'Warwickshire', 'Abbey End', 'CV8 1', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(17, 'Essex', 'Abbey Field', 'CO2 7', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(18, 'Warwickshire', 'Abbey Fields', 'CV8 1', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(19, 'Devon', 'Abbey Gate', 'EX13 5', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(20, 'Shropshire', 'Abbey Green', 'SY13 2', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(21, 'Staffordshire', 'Abbey Green', 'ST13 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(22, 'Greater Manchester', 'Abbey Hey', 'M18 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(23, 'City of Edinburgh', 'Abbeyhill', 'EH7 5', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(24, 'Staffordshire', 'Abbey Hulton', 'ST2 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(25, 'Surrey', 'Abbey Mead', 'KT16 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(26, 'Wiltshire', 'Abbey Meads', 'SN25 4', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(27, 'Fife', 'Abbey Parks', 'KY12 7', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(28, 'Berwickshire', 'Abbey St Bathans', 'TD11 3', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(29, 'Lancashire', 'Abbeystead', 'LA2 9', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(30, 'Cumbria', 'Abbeytown', 'CA7 4', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(31, 'Lancashire', 'Abbey Village', 'PR6 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(32, 'Greater London', 'Abbey Wood', 'SE2 9', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(33, 'The Stewartry of Kirkcudbright', 'Abbey Yard', 'DG7 2', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(34, 'Roxburgh, Ettrick and Lauderdale', 'Abbotrule', 'TD9 8', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(35, 'Devon', 'Abbots Bickington', 'EX22 7', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(36, 'Staffordshire', 'Abbots Bromley', 'WS15 3', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(37, 'Devon', 'Abbotsbury', 'TQ12 2', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(38, 'Dorset', 'Abbotsbury', 'DT3 4', '2020-08-28 21:11:25', '2020-08-28 21:11:25'),
(39, 'West Sussex', 'Abbotsford', 'RH15 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(40, 'Devon', 'Abbotsham', 'EX39 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(41, 'Gloucestershire', 'Abbotside', 'GL12 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(42, 'Devon', 'Abbotskerswell', 'TQ12 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(43, 'Hertfordshire', 'Abbots Langley', 'WD5 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(44, 'Somerset', 'Abbots Leigh', 'BS8 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(45, 'Cambridgeshire', 'Abbotsley', 'PE19 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(46, 'Cumbria', 'Abbotsmead', 'LA13 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(47, 'Cheshire', 'Abbot\'s Mead', 'CH1 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(48, 'Cheshire', 'Abbot\'s Meads', 'CH1 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(49, 'Worcestershire', 'Abbots Morton', 'WR7 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(50, 'Cambridgeshire', 'Abbots Ripton', 'PE28 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(51, 'Warwickshire', 'Abbot\'s Salford', 'WR11 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(52, 'Hampshire', 'Abbotstone', 'SO24 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(53, 'Hampshire', 'Abbotswood', 'SO51 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(54, 'Surrey', 'Abbotswood', 'GU1 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(55, 'Worcestershire', 'Abbotswood', 'WR5 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(56, 'Hampshire', 'Abbots Worthy', 'SO21 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(57, 'Hampshire', 'Abbotts Ann', 'SP11 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(58, 'Hampshire', 'Abbotts Barton', 'SO23 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(59, 'Shropshire', 'Abcott', 'SY7 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(60, 'Shropshire', 'Abdon', 'SY7 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(61, 'South Yorkshire', 'Abdy', 'S62 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(62, 'Gloucestershire', 'Abenhall', 'GL17 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(63, 'Dyfed', 'Aber', 'SA40 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(64, 'Powys', 'Aber', 'LD3 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(65, 'Dyfed', 'Aberaeron', 'SA46 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(66, 'Mid Glamorgan', 'Aberaman', 'CF44 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(67, 'Gwynedd', 'Aberangell', 'SY20 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(68, 'Dyfed', 'Aber-Arad', 'SA38 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(69, 'Inverness', 'Aberarder', 'PH20 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(70, 'Perth and Kinross', 'Aberargie', 'PH2 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(71, 'Dyfed', 'Aberarth', 'SA46 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(72, 'West Glamorgan', 'Aberavon', 'SA12 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(73, 'Dyfed', 'Aber-banc', 'SA44 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(74, 'Gwent', 'Aberbargoed / Aberbargod', 'CF81 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(75, 'Powys', 'Aberbechan', 'SY16 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(76, 'Gwent', 'Aberbeeg / Aber-big', 'NP13 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(77, 'Powys', 'Aberbran', 'LD3 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(78, 'Mid Glamorgan', 'Abercanaid', 'CF48 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(79, 'Gwent', 'Abercarn', 'NP11 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(80, 'Dyfed', 'Abercastle', 'SA62 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(81, 'Powys', 'Abercegir', 'SY20 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(82, 'Inverness', 'Aberchalder', 'PH35 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(83, 'Banffshire', 'Aberchirder', 'AB54 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(84, 'West Glamorgan', 'Aber-Clydach', 'SA6 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(85, 'West Lothian', 'Abercorn', 'EH30 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(86, 'Powys', 'Abercrave / Abercraf', 'SA9 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(87, 'West Glamorgan', 'Abercregan', 'SA13 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(88, 'Fife', 'Abercrombie', 'KY10 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(89, 'Mid Glamorgan', 'Abercwmboi', 'CF44 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(90, 'Dyfed', 'Abercych', 'SA37 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(91, 'Mid Glamorgan', 'Abercynon', 'CF45 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(92, 'Gwynedd', 'Aber-Cywarch', 'SY20 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(93, 'Perth and Kinross', 'Aberdalgie', 'PH2 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(94, 'Mid Glamorgan', 'Aberdare / Aberdâr', 'CF44 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(95, 'Gwynedd', 'Aberdaron', 'LL53 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(96, 'City of Aberdeen', 'Aberdeen', 'AB24 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(97, 'Gwynedd', 'Aberdesach', 'LL54 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(98, 'Fife', 'Aberdour', 'KY3 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(99, 'Gwynedd', 'Aberdovey / Aberdyfi', 'LL35 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(100, 'West Glamorgan', 'Aberdulais', 'SA10 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(101, 'Powys', 'Aberedw', 'LD2 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(102, 'Dyfed', 'Aber Eiddy', 'SA62 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(103, 'Gwynedd', 'Abererch', 'LL53 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(104, 'Mid Glamorgan', 'Aberfan', 'CF48 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(105, 'Perth and Kinross', 'Aberfeldy', 'PH15 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(106, 'Gwynedd', 'Aberffraw', 'LL63 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(107, 'Dyfed', 'Aberffrwd', 'SY23 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(108, 'West Yorkshire', 'Aberford', 'LS25 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(109, 'Stirling and Falkirk', 'Aberfoyle', 'FK8 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(110, 'Mid Glamorgan', 'Abergarw', 'CF32 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(111, 'West Glamorgan', 'Abergarwed', 'SA11 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(112, 'Gwent', 'Abergavenny / Y Fenni', 'NP7 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(113, 'Gwynedd', 'Abergeirw', 'LL40 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(114, 'Aberdeenshire', 'Abergeldie', 'AB35 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(115, 'Clwyd', 'Abergele', 'LL22 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(116, 'Dyfed', 'Aber-Giâr', 'SA40 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(117, 'Dyfed', 'Abergorlech', 'SA32 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(118, 'Powys', 'Abergwesyn', 'LD5 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(119, 'Dyfed', 'Abergwili', 'SA31 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(120, 'West Glamorgan', 'Abergwynfi', 'SA13 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(121, 'Gwynedd', 'Abergwyngregyn', 'LL33 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(122, 'Gwynedd', 'Abergynolwyn', 'LL36 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(123, 'Powys', 'Aberhafesp', 'SY16 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(124, 'Powys', 'Aberhosan', 'SY20 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(125, 'Mid Glamorgan', 'Aberkenfig / Abercynffig', 'CF32 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(126, 'East Lothian', 'Aberlady', 'EH32 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(127, 'Angus', 'Aberlemno', 'DD8 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(128, 'Dyfed', 'Aberlerry', 'SY24 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(129, 'Gwynedd', 'Aberllefenni', 'SY20 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(130, 'Dyfed', 'Abermagwr', 'SY23 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(131, 'Dyfed', 'Abermeurig', 'SA48 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(132, 'Clwyd', 'Abermorddu / Yr Hôb', 'LL12 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(133, 'Mid Glamorgan', 'Abermorlais', 'CF47 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(134, 'Powys', 'Abermule / Aber-miwl', 'SY15 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(135, 'Clwyd', 'Aber-nant', 'LL14 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(136, 'Dyfed', 'Abernant', 'SA33 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(137, 'Mid Glamorgan', 'Abernant', 'CF44 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(138, 'Perth and Kinross', 'Abernethy', 'PH2 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(139, 'Perth and Kinross', 'Abernyte', 'PH14 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(140, 'Clwyd', 'Aber-oer', 'LL14 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(141, 'Dyfed', 'Aberporth', 'SA43 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(142, 'Gwynedd', 'Aber Pwll', 'LL56 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(143, 'Powys', 'Aber Rhaeadr', 'SY10 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(144, 'Gwynedd', 'Abersoch', 'LL53 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(145, 'Gwent', 'Abersychan', 'NP4 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(146, 'Gwynedd', 'Aber-Tafol', 'LL35 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(147, 'South Glamorgan', 'Aberthin', 'CF71 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(148, 'Gwent', 'Abertillery / Abertyleri', 'NP13 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(149, 'Gwent', 'Abertridwr', 'CF83 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(150, 'Powys', 'Abertridwr', 'SY10 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(151, 'Gwynedd', 'Abertrinant', 'LL36 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(152, 'Gwent', 'Abertysswg', 'NP22 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(153, 'Perth and Kinross', 'Aberuthven', 'PH3 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(154, 'Powys', 'Aber Village', 'LD3 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(155, 'Clwyd', 'Aberwheeler / Aberchwiler', 'LL16 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(156, 'Powys', 'Aberyscir', 'LD3 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(157, 'Dyfed', 'Aberystwyth', 'SY23 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(158, 'Western Isles', 'Abhainn Suidhe', 'HS3 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(159, 'Oxfordshire', 'Abingdon-on-Thames', 'OX14 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(160, 'Surrey', 'Abinger Bottom', 'RH5 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(161, 'Surrey', 'Abinger Common', 'RH5 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(162, 'Surrey', 'Abinger Hammer', 'RH5 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(163, 'Lanarkshire', 'Abington', 'ML12 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(164, 'Northamptonshire', 'Abington', 'NN3 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(165, 'Cambridgeshire', 'Abington Pigotts', 'SG8 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(166, 'Northamptonshire', 'Abington Vale', 'NN3 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(167, 'West Sussex', 'Abingworth', 'RH20 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(168, 'Leicestershire', 'Ab Kettleby', 'LE14 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(169, 'Worcestershire', 'Ab Lench', 'WR11 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(170, 'Gloucestershire', 'Ablington', 'GL7 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(171, 'Wiltshire', 'Ablington', 'SP4 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(172, 'Derbyshire', 'Abney', 'S32 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(173, 'Staffordshire', 'Above Church', 'ST10 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(174, 'Aberdeenshire', 'Aboyne', 'AB34 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(175, 'Lancashire', 'Abraham Heights', 'LA1 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(176, 'Greater Manchester', 'Abram', 'WN2 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(177, 'Greater Manchester', 'Abram Brow', 'WN2 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(178, 'Inverness', 'Abriachan', 'IV3 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(179, 'Essex', 'Abridge', 'RM4 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(180, 'Dunbartonshire', 'Abronhill', 'G67 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(181, 'Hampshire', 'Abshot', 'PO14 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(182, 'Gloucestershire', 'Abson', 'BS30 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(183, 'Northamptonshire', 'Abthorpe', 'NN12 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(184, 'Orkney', 'Abune-the-Hill', 'KW17 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(185, 'Gloucestershire', 'Abwell', 'GL13 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(186, 'Lincolnshire', 'Aby', 'LN13 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(187, 'Western Isles', 'Acairseid', 'HS8 5', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(188, 'Inverness', 'Acarsaid', 'PH36 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(189, 'North Yorkshire', 'Acaster Malbis', 'YO23 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(190, 'North Yorkshire', 'Acaster Selby', 'YO23 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(191, 'Lancashire', 'Accrington', 'BB5 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(192, 'Argyll and Bute', 'Acha', 'PA78 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(193, 'Ross and Cromarty', 'Achadh a\'Choirce / Achachork', 'IV51 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(194, 'Inverness', 'Achadh nan Darach', 'PA38 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(195, 'Argyll and Bute', 'Achahoish', 'PA31 8', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(196, 'Argyll and Bute', 'Achaleven', 'PA37 1', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(197, 'Caithness', 'Achalone', 'KW12 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(198, 'Western Isles', 'Achamore / Acha Mòr', 'HS2 9', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(199, 'Ross and Cromarty', 'Achanalt', 'IV23 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(200, 'Ross and Cromarty', 'Achandunie', 'IV17 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(201, 'Argyll and Bute', 'Achanelid', 'PA22 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(202, 'Inverness', 'Ach\'an Tobhair', 'PH33 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(203, 'Sutherland', 'Achany', 'IV27 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(204, 'Inverness', 'Achaphubuil', 'PH33 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(205, 'Inverness', 'Acharacle / Àth-Tharracail', 'PH36 4', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(206, 'Sutherland', 'Achargary', 'KW14 7', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(207, 'Perth and Kinross', 'Acharn', 'PH15 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(208, 'Caithness', 'Achastle', 'KW3 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(209, 'Sutherland', 'Achavandra Muir', 'IV25 3', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(210, 'Caithness', 'Achavanich', 'KW5 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(211, 'Caithness', 'Achavar', 'KW3 6', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(212, 'Dyfed', 'Achddu', 'SA16 0', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(213, 'Ross and Cromarty', 'Achduart / Achadh Dubhaird', 'IV26 2', '2020-08-28 21:11:26', '2020-08-28 21:11:26'),
(214, 'Inverness', 'Achduchil', 'PH20 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(215, 'Ross and Cromarty', 'Acheninver', 'IV26 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(216, 'Sutherland', 'Achfary / Achadh Fairidh', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(217, 'Sutherland', 'Achfrish', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(218, 'Ross and Cromarty', 'Achgarve', 'IV22 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(219, 'Sutherland', 'Achiemore', 'KW13 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(220, 'Inverness', 'A\' Chill', 'PH44 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(221, 'Ross and Cromarty', 'Achiltibuie', 'IV26 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(222, 'Ross and Cromarty', 'Achilty', 'IV14 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(223, 'Sutherland', 'Achina', 'KW14 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(224, 'Nairn', 'Achindown', 'IV12 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(225, 'Sutherland', 'Achinduich', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(226, 'Caithness', 'Achingills', 'KW12 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(227, 'Sutherland', 'Achininver', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(228, 'Ross and Cromarty', 'Achintee', 'IV54 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(229, 'Ross and Cromarty', 'Achintraid / Achantraid', 'IV54 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(230, 'Argyll and Bute', 'Achleck', 'PA73 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(231, 'Argyll and Bute', 'Achlonan', 'PA35 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(232, 'Ross and Cromarty', 'Achlorachan', 'IV6 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(233, 'Inverness', 'Achluachrach', 'PH31 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(234, 'Sutherland', 'Achlyness', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(235, 'Sutherland', 'Achmelvich', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(236, 'Ross and Cromarty', 'Achmore', 'IV23 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(237, 'Ross and Cromarty', 'Achmore', 'IV53 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(238, 'Sutherland', 'Achnabat', 'KW14 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(239, 'Sutherland', 'Achnacarnin', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(240, 'Inverness', 'Achnacarry', 'PH34 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(241, 'Ross and Cromarty', 'Achnacloich', 'IV46 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(242, 'Inverness', 'Achnaconeran', 'IV63 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(243, 'Argyll and Bute', 'Achnacroish', 'PA34 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(244, 'Ross and Cromarty', 'Achnagarron', 'IV18 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(245, 'Argyll and Bute', 'Achnagoul', 'PA32 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(246, 'Inverness', 'Achnaha', 'PH36 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(247, 'Sutherland', 'Achnahanat', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(248, 'Inverness', 'Achnahannet', 'PH26 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(249, 'Argyll and Bute', 'Achnahard', 'PA67 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(250, 'Sutherland', 'Achnahuaigh', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(251, 'Sutherland', 'Achnairn', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(252, 'Argyll and Bute', 'Achnamara', 'PA31 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(253, 'Ross and Cromarty', 'Achnandarach', 'IV52 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(254, 'Ross and Cromarty', 'Achnasheen / Achadh na Sine', 'IV22 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(255, 'Ross and Cromarty', 'Achnashellach / Achadh na Seileach', 'IV54 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(256, 'Caithness', 'Achnavast', 'KW14 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(257, 'Inverness', 'Achosnich', 'PH36 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(258, 'Caithness', 'Achow', 'KW3 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(259, 'Inverness', 'Achranich', 'PA80 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(260, 'Caithness', 'Achreamie', 'KW14 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(261, 'Sutherland', 'Achriesgill', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(262, 'Sutherland', 'Achrimsdale', 'KW9 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(263, 'Caithness', 'Achscrabster', 'KW14 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(264, 'Ross and Cromarty', 'Achtalean', 'IV51 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(265, 'Ross and Cromarty', 'Achterneed', 'IV14 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(266, 'Sutherland', 'Achtoty', 'KW14 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(267, 'Northamptonshire', 'Achurch', 'PE8 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(268, 'Sutherland', 'Achuvoldrach', 'IV27 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(269, 'Cumbria', 'Ackenthwaite', 'LA7 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(270, 'Caithness', 'Ackergill', 'KW1 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(271, 'Caithness', 'Ackergillshore', 'KW1 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(272, 'Cheshire', 'Ackers Crossing', 'CW12 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(273, 'North Yorkshire', 'Acklam', 'TS5 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(274, 'North Yorkshire', 'Acklam', 'YO17 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(275, 'Shropshire', 'Ackleton', 'WV6 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(276, 'Northumberland', 'Acklington', 'NE65 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(277, 'West Yorkshire', 'Ackton', 'WF7 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(278, 'West Yorkshire', 'Ackworth Moor Top', 'WF7 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(279, 'Norfolk', 'Acle', 'NR13 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(280, 'West Midlands', 'Acocks Green', 'B27 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(281, 'Kent', 'Acol', 'CT7 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(282, 'Northumberland', 'Acomb', 'NE46 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(283, 'North Yorkshire', 'Acomb', 'YO24 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(284, 'Herefordshire', 'Aconbury', 'HR2 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(285, 'City of Glasgow', 'Acre', 'G20 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(286, 'Greater Manchester', 'Acre', 'OL1 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(287, 'Lancashire', 'Acre', 'BB4 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(288, 'Clwyd', 'Acrefair', 'LL14 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(289, 'Derbyshire', 'Acre Ridge Estate', 'DE55 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(290, 'Greater Manchester', 'Acres', 'OL1 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(291, 'Leicestershire', 'Acresford', 'DE12 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(292, 'Staffordshire', 'Acres Nook', 'ST6 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(293, 'Kent', 'Acrise', 'CT18 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(294, 'Cheshire', 'Acton', 'CW5 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(295, 'Clwyd', 'Acton', 'LL12 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(296, 'County Tyrone', 'Acton', 'BT71 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(297, 'Dorset', 'Acton', 'BH19 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(298, 'Greater London', 'Acton', 'W3 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(299, 'Kent', 'Acton', 'TN30 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(300, 'Shropshire', 'Acton', 'SY9 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(301, 'Staffordshire', 'Acton', 'ST5 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(302, 'Suffolk', 'Acton', 'CO10 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(303, 'Worcestershire', 'Acton', 'DY13 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(304, 'Herefordshire', 'Acton Beauchamp', 'WR6 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(305, 'Cheshire', 'Acton Bridge', 'CW8 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(306, 'Shropshire', 'Acton Burnell', 'SY5 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(307, 'Staffordshire', 'Acton Gate', 'ST17 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(308, 'Greater London', 'Acton Green', 'W4 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(309, 'Herefordshire', 'Acton Green', 'WR6 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(310, 'Shropshire', 'Acton Pigott', 'SY5 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(311, 'Suffolk', 'Acton Place', 'CO10 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(312, 'Shropshire', 'Acton Reynald', 'SY4 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(313, 'Shropshire', 'Acton Round', 'WV16 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(314, 'Shropshire', 'Acton Scott', 'SY6 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(315, 'Staffordshire', 'Acton Trussell', 'ST17 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(316, 'Gloucestershire', 'Acton Turville', 'GL9 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(317, 'Western Isles', 'Adabroc', 'HS2 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(318, 'West Lothian', 'Adambrae', 'EH54 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(319, 'South Glamorgan', 'Adamsdown', 'CF24 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(320, 'Dorset', 'Adam\'s Green', 'BA22 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(321, 'Dyfed', 'Adams Street', 'SY24 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(322, 'Staffordshire', 'Adbaston', 'ST20 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(323, 'Dorset', 'Adber', 'DT9 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(324, 'Nottinghamshire', 'Adbolton', 'NG2 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(325, 'Hampshire', 'Adbury', 'RG20 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(326, 'Oxfordshire', 'Adderbury', 'OX17 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(327, 'Shropshire', 'Adderley', 'TF9 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(328, 'Staffordshire', 'Adderley Green', 'ST3 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(329, 'Cheshire', 'Adder\'s Moss', 'SK10 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(330, 'West Lothian', 'Addiebrownhill', 'EH55 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(331, 'West Lothian', 'Addiewell', 'EH55 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(332, 'West Yorkshire', 'Addingford', 'WF4 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(333, 'West Yorkshire', 'Addingham', 'LS29 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(334, 'West Yorkshire', 'Addingham Moorside', 'LS29 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(335, 'Buckinghamshire', 'Addington', 'MK18 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(336, 'Cornwall', 'Addington', 'PL14 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(337, 'Greater London', 'Addington', 'CR0 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(338, 'Kent', 'Addington', 'ME19 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(339, 'Roxburgh, Ettrick and Lauderdale', 'Addinston', 'TD2 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(340, 'Greater London', 'Addiscombe', 'CR0 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(341, 'Kent', 'Addlestead', 'TN12 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(342, 'Surrey', 'Addlestone', 'KT15 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(343, 'Surrey', 'Addlestonemoor', 'KT15 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(344, 'Lincolnshire', 'Addlethorpe', 'PE24 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(345, 'West Yorkshire', 'Adel', 'LS16 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(346, 'West Yorkshire', 'Adel East Moor', 'LS16 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(347, 'Lancashire', 'Adelphi', 'PR1 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(348, 'Kincardineshire', 'Adendale', 'AB31 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(349, 'Shropshire', 'Adeney', 'TF10 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(350, 'Hertfordshire', 'Adeyfield', 'HP2 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(351, 'Powys', 'Adfa', 'SY16 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(352, 'Herefordshire', 'Adforton', 'SY7 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(353, 'Isle of Wight', 'Adgestone', 'PO36 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(354, 'Kent', 'Adisham', 'CT3 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(355, 'Gloucestershire', 'Adlestrop', 'GL56 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(356, 'Herefordshire', 'Adley Moor', 'SY7 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(357, 'East Riding of Yorkshire', 'Adlingfleet', 'DN14 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(358, 'Cheshire', 'Adlington', 'SK10 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(359, 'Lancashire', 'Adlington', 'PR6 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(360, 'Lancashire', 'Adlington Park', 'WN1 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(361, 'Shropshire', 'Admaston', 'TF5 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(362, 'Staffordshire', 'Admaston', 'WS15 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(363, 'Warwickshire', 'Admington', 'CV36 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(364, 'Dyfed', 'Adpar', 'SA38 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(365, 'Somerset', 'Adsborough', 'TA2 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(366, 'Somerset', 'Adscombe', 'TA5 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(367, 'West Sussex', 'Adsdean', 'PO18 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(368, 'Buckinghamshire', 'Adstock', 'MK18 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(369, 'Northamptonshire', 'Adstone', 'NN12 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(370, 'Greater Manchester', 'Adswood', 'SK3 8', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(371, 'West Sussex', 'Adversane', 'RH14 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(372, 'Inverness', 'Advie', 'PH26 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(373, 'West Yorkshire', 'Adwalton', 'BD11 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(374, 'Oxfordshire', 'Adwell', 'OX9 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(375, 'South Yorkshire', 'Adwick le Street', 'DN6 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(376, 'South Yorkshire', 'Adwick upon Dearne', 'S64 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(377, 'Dumfries', 'Ae', 'DG1 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(378, 'Dumfries', 'Ae Bridgend', 'DG1 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(379, 'Greater Manchester', 'Affetside', 'BL8 3', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(380, 'Aberdeenshire', 'Affleck', 'AB21 0', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(381, 'Dorset', 'Affpuddle', 'DT2 7', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(382, 'Clwyd', 'Afon Eitha', 'LL14 2', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(383, 'Clwyd', 'Afon-wen', 'CH7 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(384, 'Gwynedd', 'Afon Wen', 'LL53 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(385, 'Isle of Wight', 'Afton', 'PO40 9', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(386, 'Ayrshire and Arran', 'Afton Bridgend', 'KA18 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(387, 'Leicestershire', 'Agar Nook', 'LE67 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(388, 'West Yorkshire', 'Agbrigg', 'WF1 5', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(389, 'Worcestershire', 'Aggborough', 'DY10 1', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(390, 'North Yorkshire', 'Agglethorpe', 'DL8 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(391, 'County Armagh', 'Aghacommon', 'BT66 6', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(392, 'County Derry / Londonderry', 'Aghadowey', 'BT51 4', '2020-08-28 21:11:27', '2020-08-28 21:11:27'),
(393, 'County Fermanagh', 'Aghadrumsee', 'BT92 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(394, 'County Down', 'Aghagallon', 'BT67 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(395, 'County Antrim', 'Aghalee', 'BT67 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(396, 'Cumbria', 'Aglionby', 'CA4 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(397, 'Isle of Man', 'Agneash', 'IM7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(398, 'Western Isles', 'Ahmore / Athmòr', 'HS6 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(399, 'County Antrim', 'Ahoghill', 'BT42 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(400, 'Clwyd', 'Aifft', 'LL16 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(401, 'Merseyside', 'Aigburth', 'L19 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(402, 'Merseyside', 'Aigburth Vale', 'L17 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(403, 'Western Isles', 'Aignish / Aiginis', 'HS2 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(404, 'East Riding of Yorkshire', 'Aike', 'YO25 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(405, 'Orkney', 'Aikerness', 'KW17 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(406, 'Orkney', 'Aikers', 'KW17 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(407, 'Cumbria', 'Aiketgate', 'CA4 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(408, 'Cumbria', 'Aikhead', 'CA7 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(409, 'Cumbria', 'Aikrigg', 'LA9 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(410, 'Cumbria', 'Aikton', 'CA7 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(411, 'Lincolnshire', 'Ailby', 'LN13 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(412, 'Herefordshire', 'Ailscroft', 'HR8 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(413, 'Warwickshire', 'Ailstone', 'CV37 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(414, 'Cambridgeshire', 'Ailsworth', 'PE5 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(415, 'Essex', 'Aimes Green', 'EN9 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(416, 'North Yorkshire', 'Ainderby Quernhow', 'YO7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(417, 'North Yorkshire', 'Ainderby Steeple', 'DL7 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(418, 'Essex', 'Aingers Green', 'CO7 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(419, 'West Yorkshire', 'Ainley Top', 'HD2 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(420, 'Merseyside', 'Ainsdale', 'PR8 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(421, 'Merseyside', 'Ainsdale-on-Sea', 'PR8 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(422, 'Cumbria', 'Ainstable', 'CA4 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(423, 'Greater Manchester', 'Ainsworth', 'BL2 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(424, 'North Yorkshire', 'Ainthorpe', 'YO21 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(425, 'Merseyside', 'Aintree', 'L10 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(426, 'Argyll and Bute', 'Aird', 'PA31 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(427, 'Ross and Cromarty', 'Aird', 'IV51 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(428, 'Western Isles', 'Aird', 'HS2 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(429, 'Wigtown', 'Aird', 'DG9 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(430, 'Ross and Cromarty', 'Aird / An Àird', 'IV45 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(431, 'Sutherland', 'Airdens', 'IV24 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(432, 'Lanarkshire', 'Airdrie', 'ML6 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(433, 'Lanarkshire', 'Airdriehill', 'ML6 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(434, 'Argyll and Bute', 'Airds', 'PA28 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(435, 'Argyll and Bute', 'Airds Bay', 'PA35 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(436, 'Western Isles', 'Aird Tong / Àird Thunga', 'HS2 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(437, 'Sutherland', 'Airdtorrisdale', 'KW14 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(438, 'West Yorkshire', 'Airedale', 'WF10 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(439, 'North Yorkshire', 'Aire View', 'BD20 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(440, 'West Yorkshire', 'Aireworth', 'BD21 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(441, 'Angus', 'Airlie', 'DD8 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(442, 'East Riding of Yorkshire', 'Airmyn', 'DN14 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(443, 'Perth and Kinross', 'Airntully', 'PH1 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(444, 'Inverness', 'Airor', 'IV43 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(445, 'Stirling and Falkirk', 'Airth', 'FK2 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(446, 'Stirling and Falkirk', 'Airthrey Castle', 'FK9 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(447, 'North Yorkshire', 'Airton', 'BD23 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(448, 'North Yorkshire', 'Airy Hill', 'YO22 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(449, 'Lincolnshire', 'Aisby', 'DN21 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(450, 'Lincolnshire', 'Aisby', 'NG32 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(451, 'Western Isles', 'Aisgernis / Askernish', 'HS8 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(452, 'Devon', 'Aish', 'TQ9 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(453, 'Devon', 'Aish', 'TQ10 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(454, 'Somerset', 'Aisholt', 'TA5 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(455, 'North Yorkshire', 'Aiskew', 'DL8 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(456, 'Durham', 'Aislaby', 'TS16 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(457, 'North Yorkshire', 'Aislaby', 'YO18 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(458, 'North Yorkshire', 'Aislaby', 'YO21 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(459, 'Lincolnshire', 'Aisthorpe', 'LN1 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(460, 'Orkney', 'Aith', 'KW17 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(461, 'Shetland', 'Aith', 'ZE2 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(462, 'Powys', 'Aithnen', 'SY10 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(463, 'Shetland', 'Aithsetter', 'ZE2 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(464, 'Northumberland', 'Akeld', 'NE71 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(465, 'Buckinghamshire', 'Akeley', 'MK18 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(466, 'Suffolk', 'Akenham', 'IP1 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(467, 'West Yorkshire', 'Akroydon', 'HX3 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(468, 'Tyne and Wear', 'Albany', 'NE37 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(469, 'Greater London', 'Albany Park', 'DA14 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(470, 'Cornwall', 'Albaston', 'PL18 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(471, 'Shropshire', 'Alberbury', 'SY5 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(472, 'Durham', 'Albert Hill', 'DL1 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(473, 'Dyfed', 'Albert Town', 'SA61 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(474, 'Leicestershire', 'Albert Village', 'DE11 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(475, 'West Midlands', 'Albion', 'B70 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(476, 'West Sussex', 'Albourne', 'BN6 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(477, 'West Sussex', 'Albourne Green', 'BN6 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(478, 'West Sussex', 'Albourne Street', 'BN6 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(479, 'Shropshire', 'Albrighton', 'SY4 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(480, 'Shropshire', 'Albrighton', 'WV7 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(481, 'Dyfed', 'Albro Castle', 'SA43 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(482, 'Norfolk', 'Alburgh', 'IP20 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(483, 'Norfolk', 'Alburgh Street', 'IP20 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(484, 'Fife', 'Alburne Park', 'KY7 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(485, 'Hertfordshire', 'Albury', 'SG11 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(486, 'Oxfordshire', 'Albury', 'OX9 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(487, 'Surrey', 'Albury', 'GU5 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(488, 'Hertfordshire', 'Albury End', 'SG11 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(489, 'Surrey', 'Albury Heath', 'GU5 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(490, 'Norfolk', 'Alby', 'NR11 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(491, 'Cumbria', 'Albyfield', 'CA8 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(492, 'Norfolk', 'Alby Hill', 'NR11 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(493, 'Ross and Cromarty', 'Alcaig', 'IV7 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(494, 'Shropshire', 'Alcaston', 'SY6 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(495, 'Dorset', 'Alcester', 'SP7 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(496, 'Warwickshire', 'Alcester', 'B49 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(497, 'West Midlands', 'Alcester Lane\'s End', 'B14 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(498, 'East Sussex', 'Alciston', 'BN26 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(499, 'Somerset', 'Alcombe', 'TA24 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(500, 'Wiltshire', 'Alcombe', 'SN13 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(501, 'Cambridgeshire', 'Alconbury', 'PE28 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(502, 'Cambridgeshire', 'Alconbury Weston', 'PE28 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(503, 'Norfolk', 'Aldborough', 'NR11 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(504, 'North Yorkshire', 'Aldborough', 'YO51 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(505, 'Greater London', 'Aldborough Hatch', 'IG2 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(506, 'Wiltshire', 'Aldbourne', 'SN8 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(507, 'East Riding of Yorkshire', 'Aldbrough', 'HU11 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(508, 'North Yorkshire', 'Aldbrough St John', 'DL11 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(509, 'Hertfordshire', 'Aldbury', 'HP23 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(510, 'Lancashire', 'Aldcliffe', 'LA1 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(511, 'Perth and Kinross', 'Aldclune', 'PH16 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(512, 'Suffolk', 'Aldeburgh', 'IP15 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(513, 'Norfolk', 'Aldeby', 'NR34 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(514, 'Hertfordshire', 'Aldenham', 'WD25 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(515, 'East Sussex', 'Alderbrook', 'TN6 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(516, 'Wiltshire', 'Alderbury', 'SP5 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(517, 'Derbyshire', 'Aldercar', 'NG16 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(518, 'Devon', 'Alderford', 'EX35 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(519, 'Norfolk', 'Alderford', 'NR9 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(520, 'Greater Manchester', 'Alder Forest', 'M30 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(521, 'County Antrim', 'Aldergrove', 'BT29 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(522, 'Dorset', 'Alderholt', 'SP6 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(523, 'Gloucestershire', 'Alderley', 'GL12 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(524, 'Cheshire', 'Alderley Edge', 'SK9 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(525, 'West Midlands', 'Alderman\'s Green', 'CV2 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(526, 'Berkshire', 'Aldermaston', 'RG7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(527, 'Berkshire', 'Aldermaston Soke', 'RG7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(528, 'Berkshire', 'Aldermaston Wharf', 'RG7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(529, 'Warwickshire', 'Alderminster', 'CV37 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(530, 'Hampshire', 'Aldermoor', 'SO16 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(531, 'Staffordshire', 'Alder Moor', 'DE13 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(532, 'Dorset', 'Alderney', 'BH12 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(533, 'Greater Manchester', 'Alder Root', 'OL9 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(534, 'Somerset', 'Alder Row', 'BA11 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(535, 'Staffordshire', 'Alders', 'ST14 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(536, 'Greater London', 'Aldersbrook', 'E11 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(537, 'Herefordshire', 'Alder\'s End', 'HR1 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(538, 'Cheshire', 'Aldersey Green', 'CH3 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(539, 'Cheshire', 'Aldersey Park', 'CH3 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(540, 'Staffordshire', 'Aldershawe', 'WS14 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(541, 'Hampshire', 'Aldershot', 'GU11 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(542, 'West Midlands', 'Aldersley', 'WV6 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(543, 'Gloucestershire', 'Alderton', 'GL20 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(544, 'Northamptonshire', 'Alderton', 'NN12 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(545, 'Shropshire', 'Alderton', 'SY4 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(546, 'Suffolk', 'Alderton', 'IP12 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(547, 'Wiltshire', 'Alderton', 'SN14 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(548, 'Gloucestershire', 'Alderton Fields', 'GL54 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(549, 'Derbyshire', 'Alderwasley', 'DE56 2', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(550, 'Greater London', 'Alderwood Terrace', 'IG7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(551, 'North Yorkshire', 'Aldfield', 'HG4 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(552, 'Cheshire', 'Aldford', 'CH3 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(553, 'Greater London', 'Aldgate', 'EC3M 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(554, 'Rutland', 'Aldgate', 'PE9 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(555, 'Essex', 'Aldham', 'CO6 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(556, 'Suffolk', 'Aldham', 'IP7 6', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(557, 'Aberdeenshire', 'Aldie', 'AB42 0', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(558, 'West Sussex', 'Aldingbourne', 'PO20 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(559, 'Cumbria', 'Aldingham', 'LA12 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28');
INSERT INTO `postcodes` (`id`, `state`, `city`, `postcode`, `created_at`, `updated_at`) VALUES
(560, 'Kent', 'Aldington', 'TN25 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(561, 'Worcestershire', 'Aldington', 'WR11 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(562, 'Kent', 'Aldington Frith', 'TN25 7', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(563, 'Dunbartonshire', 'Aldochlay', 'G83 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(564, 'Shropshire', 'Aldon', 'SY7 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(565, 'Cumbria', 'Aldoth', 'CA7 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(566, 'Cambridgeshire', 'Aldreth', 'CB6 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(567, 'West Midlands', 'Aldridge', 'WS9 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(568, 'Suffolk', 'Aldringham', 'IP16 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(569, 'East Sussex', 'Aldrington', 'BN3 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(570, 'Gloucestershire', 'Aldsworth', 'GL54 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(571, 'West Sussex', 'Aldsworth', 'PO10 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(572, 'Derbyshire', 'Aldwark', 'DE4 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(573, 'North Yorkshire', 'Aldwark', 'YO61 1', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(574, 'South Yorkshire', 'Aldwarke', 'S65 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(575, 'Somerset', 'Aldwick', 'BS40 5', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(576, 'West Sussex', 'Aldwick', 'PO21 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(577, 'Northamptonshire', 'Aldwincle', 'NN14 3', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(578, 'Berkshire', 'Aldworth', 'RG8 9', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(579, 'Greater London', 'Aldwych', 'WC2B 4', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(580, 'Shropshire', 'Ale Oak', 'SY7 8', '2020-08-28 21:11:28', '2020-08-28 21:11:28'),
(581, 'Greater London', 'Alexandra Park', 'N22 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(582, 'Nottinghamshire', 'Alexandra Park', 'NG3 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(583, 'Dunbartonshire', 'Alexandria', 'G83 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(584, 'Somerset', 'Aley', 'TA5 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(585, 'Bedfordshire', 'Aley Green', 'LU1 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(586, 'Devon', 'Alfardisworthy', 'EX22 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(587, 'Devon', 'Alfington', 'EX11 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(588, 'Surrey', 'Alfold', 'GU6 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(589, 'West Sussex', 'Alfold Bars', 'RH14 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(590, 'Surrey', 'Alfold Crossways', 'GU6 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(591, 'Aberdeenshire', 'Alford', 'AB33 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(592, 'Lincolnshire', 'Alford', 'LN13 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(593, 'Somerset', 'Alford', 'BA7 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(594, 'Worcestershire', 'Alfred\'s Well', 'B61 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(595, 'Derbyshire', 'Alfreton', 'DE55 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(596, 'Worcestershire', 'Alfrick', 'WR6 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(597, 'Worcestershire', 'Alfrick Pound', 'WR6 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(598, 'East Sussex', 'Alfriston', 'BN26 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(599, 'Lincolnshire', 'Algarkirk', 'PE20 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(600, 'Somerset', 'Alhampton', 'BA4 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(601, 'Inverness', 'Alisary', 'PH38 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(602, 'Lincolnshire', 'Alkborough', 'DN15 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(603, 'Oxfordshire', 'Alkerton', 'OX15 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(604, 'Kent', 'Alkham', 'CT15 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(605, 'Shropshire', 'Alkington', 'SY13 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(606, 'Derbyshire', 'Alkmonton', 'DE6 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(607, 'Greater Manchester', 'Alkrington Garden Village', 'M24 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(608, 'Devon', 'Allaleigh', 'TQ9 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(609, 'Aberdeenshire', 'Allanaquoich', 'AB35 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(610, 'Lanarkshire', 'Allanbank', 'ML7 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(611, 'Stirling and Falkirk', 'Allandale', 'FK4 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(612, 'Roxburgh, Ettrick and Lauderdale', 'Allanshaugh', 'TD1 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(613, 'Roxburgh, Ettrick and Lauderdale', 'Allanshaws', 'TD1 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(614, 'Berwickshire', 'Allanton', 'TD11 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(615, 'Lanarkshire', 'Allanton', 'ML7 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(616, 'Lanarkshire', 'Allanton', 'ML3 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(617, 'Kincardineshire', 'Allardice', 'DD10 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(618, 'Western Isles', 'Allasdale / Allathasdal', 'HS9 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(619, 'Gloucestershire', 'Allaston', 'GL15 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(620, 'Hampshire', 'Allbrook', 'SO50 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(621, 'Wiltshire', 'All Cannings', 'SN10 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(622, 'Northumberland', 'Allendale Town', 'NE47 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(623, 'Warwickshire', 'Allen End', 'B78 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(624, 'Northumberland', 'Allenheads', 'NE47 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(625, 'Durham', 'Allensford', 'DH8 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(626, 'Hertfordshire', 'Allen\'s Green', 'CM21 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(627, 'Nottinghamshire', 'Allen\'s Green', 'NG16 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(628, 'Herefordshire', 'Allensmore', 'HR2 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(629, 'Derbyshire', 'Allenton', 'DE24 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(630, 'Cumbria', 'Allenwood', 'CA8 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(631, 'Devon', 'Aller', 'EX15 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(632, 'Dorset', 'Aller', 'DT2 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(633, 'Somerset', 'Aller', 'TA10 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(634, 'Cumbria', 'Allerby', 'CA7 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(635, 'Devon', 'Allercombe', 'EX5 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(636, 'Tyne and Wear', 'Allerdene', 'NE9 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(637, 'Somerset', 'Allerford', 'TA4 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(638, 'Somerset', 'Allerford', 'TA24 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(639, 'Devon', 'Aller Grove', 'EX5 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(640, 'Devon', 'Aller Park', 'TQ12 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(641, 'North Yorkshire', 'Allerston', 'YO18 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(642, 'East Riding of Yorkshire', 'Allerthorpe', 'YO42 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(643, 'Merseyside', 'Allerton', 'L18 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(644, 'West Yorkshire', 'Allerton', 'BD15 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(645, 'West Yorkshire', 'Allerton Bywater', 'WF10 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(646, 'North Yorkshire', 'Allerton Mauleverer', 'HG5 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(647, 'West Midlands', 'Allesley', 'CV5 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(648, 'West Midlands', 'Allesley Green', 'CV5 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(649, 'Derbyshire', 'Allestree', 'DE22 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(650, 'Cornwall', 'Allet', 'TR4 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(651, 'Leicestershire', 'Allexton', 'LE15 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(652, 'Lancashire', 'Alleytroyds', 'BB5 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(653, 'Cheshire', 'Allgreave', 'SK11 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(654, 'Kent', 'Allhallows', 'ME3 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(655, 'Kent', 'Allhallows-on-Sea', 'ME3 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(656, 'Ross and Cromarty', 'Alligin Shuas', 'IV22 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(657, 'Staffordshire', 'Allimore Green', 'ST18 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(658, 'Dorset', 'Allington', 'DT6 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(659, 'Kent', 'Allington', 'ME16 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(660, 'Lincolnshire', 'Allington', 'NG32 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(661, 'Wiltshire', 'Allington', 'SN14 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(662, 'Wiltshire', 'Allington', 'SN10 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(663, 'Wiltshire', 'Allington', 'SP4 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(664, 'Wiltshire', 'Allington Bar', 'SN14 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(665, 'Cumbria', 'Allithwaite', 'LA11 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(666, 'Clackmannan', 'Alloa', 'FK10 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(667, 'Cumbria', 'Allonby', 'CA15 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(668, 'Cheshire', 'Allostock', 'WA16 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(669, 'Ayrshire and Arran', 'Alloway', 'KA7 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(670, 'Somerset', 'Allowenshay', 'TA17 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(671, 'Devon', 'All Saints', 'EX13 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(672, 'West Midlands', 'All Saints', 'B18 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(673, 'Suffolk', 'All Saints\' South Elmham', 'IP19 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(674, 'Shropshire', 'Allscott', 'WV15 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(675, 'Shropshire', 'Allscott', 'TF6 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(676, 'Shropshire', 'All Stretton', 'SY6 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(677, 'Dyfed', 'Allt', 'SA14 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(678, 'Ross and Cromarty', 'Allt a\' Chruinn', 'IV40 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(679, 'Clwyd', 'Alltami', 'CH7 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(680, 'Powys', 'Alltmawr', 'LD2 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(681, 'Ross and Cromarty', 'Allt nan Sùgh', 'IV40 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(682, 'Inverness', 'Alltour', 'PH34 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(683, 'Inverness', 'Alltsigh', 'IV63 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(684, 'Dyfed', 'Alltwalis', 'SA32 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(685, 'West Glamorgan', 'Alltwen', 'SA8 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(686, 'Dyfed', 'Alltyblaca', 'SA40 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(687, 'Gwent', 'Allt-yr-yn', 'NP20 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(688, 'Hampshire', 'Allum Green', 'SO43 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(689, 'Suffolk', 'Allwood Green', 'IP22 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(690, 'Nottinghamshire', 'Alma', 'NG16 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(691, 'Dumfries', 'Almagill', 'DG11 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(692, 'Herefordshire', 'Almeley', 'HR3 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(693, 'Herefordshire', 'Almeley Wootton', 'HR3 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(694, 'Dorset', 'Almer', 'DT11 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(695, 'South Yorkshire', 'Almholme', 'DN5 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(696, 'Staffordshire', 'Almington', 'TF9 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(697, 'Devon', 'Alminstone Cross', 'EX39 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(698, 'West Sussex', 'Almodington', 'PO20 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(699, 'Perth and Kinross', 'Almondbank', 'PH1 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(700, 'West Yorkshire', 'Almondbury', 'HD5 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(701, 'West Yorkshire', 'Almondbury Common', 'HD4 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(702, 'City of Edinburgh', 'Almondhill', 'EH29 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(703, 'Gloucestershire', 'Almondsbury', 'BS32 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(704, 'West Lothian', 'Almondvale', 'EH54 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(705, 'Surrey', 'Almshouse Common', 'GU27 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(706, 'Essex', 'Almshouse Green', 'CO9 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(707, 'Suffolk', 'Almshouse Green', 'IP30 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(708, 'North Yorkshire', 'Alne', 'YO61 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(709, 'Warwickshire', 'Alne End', 'B49 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(710, 'Warwickshire', 'Alne Hills', 'B49 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(711, 'Ross and Cromarty', 'Alness', 'IV17 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(712, 'Ross and Cromarty', 'Alnessferry', 'IV7 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(713, 'North Yorkshire', 'Alne Station', 'YO61 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(714, 'Northumberland', 'Alnham', 'NE66 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(715, 'Northumberland', 'Alnmouth', 'NE66 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(716, 'Northumberland', 'Alnwick', 'NE66 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(717, 'City of Edinburgh', 'Alnwickhill', 'EH16 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(718, 'Greater London', 'Alperton', 'HA0 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(719, 'Essex', 'Alphamstone', 'CO8 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(720, 'Suffolk', 'Alpheton', 'CO10 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(721, 'Devon', 'Alphington', 'EX2 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(722, 'Norfolk', 'Alpington', 'NR14 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(723, 'Derbyshire', 'Alport', 'DE45 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(724, 'Powys', 'Alport', 'SY15 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(725, 'Cheshire', 'Alpraham', 'CW6 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(726, 'Essex', 'Alresford', 'CO7 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(727, 'Staffordshire', 'Alrewas', 'DE13 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(728, 'Cheshire', 'Alsager', 'ST7 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(729, 'Staffordshire', 'Alsagers Bank', 'ST7 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(730, 'Buckinghamshire', 'Alscot', 'HP27 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(731, 'Derbyshire', 'Alsop en le Dale', 'DE6 1', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(732, 'Cumbria', 'Alston', 'CA9 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(733, 'Devon', 'Alston', 'EX13 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(734, 'Gloucestershire', 'Alstone', 'GL51 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(735, 'Gloucestershire', 'Alstone', 'GL20 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(736, 'Somerset', 'Alstone', 'TA9 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(737, 'Staffordshire', 'Alstonefield', 'DE6 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(738, 'Somerset', 'Alston Sutton', 'BS26 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(739, 'Devon', 'Alswear', 'EX36 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(740, 'Greater Manchester', 'Alt', 'OL8 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(741, 'County Tyrone', 'Altamuskin', 'BT79 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(742, 'Ross and Cromarty', 'Altandhu', 'IV26 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(743, 'Cornwall', 'Altarnun', 'PL15 7', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(744, 'Sutherland', 'Altass', 'IV24 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(745, 'Herefordshire', 'Altbough', 'HR2 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(746, 'City of Aberdeen', 'Altens', 'AB12 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(747, 'Caithness', 'Alterwall', 'KW1 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(748, 'Lancashire', 'Altham', 'BB5 5', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(749, 'Greater Manchester', 'Alt Hill', 'OL6 8', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(750, 'Essex', 'Althorne', 'CM3 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(751, 'Lincolnshire', 'Althorpe', 'DN17 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(752, 'County Tyrone', 'Altishane', 'BT82 0', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(753, 'Berkshire', 'Altmore', 'SL6 3', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(754, 'County Tyrone', 'Altmore', 'BT79 9', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(755, 'Sutherland', 'Altnaharra', 'IV27 4', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(756, 'West Yorkshire', 'Altofts', 'WF6 2', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(757, 'Derbyshire', 'Alton', 'S42 6', '2020-08-28 21:11:29', '2020-08-28 21:11:29'),
(758, 'Hampshire', 'Alton', 'GU34 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(759, 'Staffordshire', 'Alton', 'ST10 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(760, 'Wiltshire', 'Alton', 'SP4 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(761, 'Wiltshire', 'Alton Barnes', 'SN8 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(762, 'Ayrshire and Arran', 'Altonhill', 'KA3 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(763, 'Dorset', 'Alton Pancras', 'DT2 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(764, 'Wiltshire', 'Alton Priors', 'SN8 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(765, 'Moray', 'Altonside', 'IV30 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(766, 'Greater Manchester', 'Altrincham', 'WA14 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(767, 'Stirling and Falkirk', 'Altskeith', 'FK8 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(768, 'Inverness', 'Alturlie', 'IV2 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(769, 'Dorset', 'Alum Chine', 'BH4 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(770, 'West Midlands', 'Alum Rock', 'B8 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(771, 'Durham', 'Alum Waters', 'DH7 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(772, 'Clackmannan', 'Alva', 'FK12 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(773, 'Cheshire', 'Alvanley', 'WA6 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(774, 'Derbyshire', 'Alvaston', 'DE24 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(775, 'Worcestershire', 'Alvechurch', 'B48 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(776, 'Warwickshire', 'Alvecote', 'B79 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(777, 'Wiltshire', 'Alvediston', 'SP5 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(778, 'Shropshire', 'Alveley', 'WV15 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(779, 'Devon', 'Alverdiscott', 'EX31 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(780, 'Hampshire', 'Alverstoke', 'PO12 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(781, 'Isle of Wight', 'Alverstone', 'PO36 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(782, 'Isle of Wight', 'Alverstone Garden Village', 'PO36 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(783, 'West Yorkshire', 'Alverthorpe', 'WF2 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(784, 'Cornwall', 'Alverton', 'TR18 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(785, 'Nottinghamshire', 'Alverton', 'NG13 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(786, 'Moray', 'Alves', 'IV30 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(787, 'Oxfordshire', 'Alvescot', 'OX18 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(788, 'Gloucestershire', 'Alveston', 'BS35 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(789, 'Warwickshire', 'Alveston', 'CV37 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(790, 'Gloucestershire', 'Alveston Down', 'BS35 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(791, 'Warwickshire', 'Alveston Hill', 'CV37 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(792, 'Inverness', 'Alvie', 'PH22 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(793, 'Lincolnshire', 'Alvingham', 'LN11 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(794, 'Gloucestershire', 'Alvington', 'GL15 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(795, 'Somerset', 'Alvington', 'BA22 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(796, 'Cambridgeshire', 'Alwalton', 'PE7 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(797, 'Gwent', 'Alway', 'NP19 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(798, 'Dorset', 'Alweston', 'DT9 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(799, 'Devon', 'Alwington', 'EX39 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(800, 'Northumberland', 'Alwinton', 'NE65 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(801, 'West Yorkshire', 'Alwoodley', 'LS17 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(802, 'West Yorkshire', 'Alwoodley Gates', 'LS17 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(803, 'West Yorkshire', 'Alwoodley Park', 'LS17 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(804, 'Perth and Kinross', 'Alyth', 'PH11 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(805, 'Cornwall', 'Amalebra', 'TR20 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(806, 'Cornwall', 'Amalveor', 'TR26 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(807, 'Sutherland', 'Amatnatua', 'IV24 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(808, 'Derbyshire', 'Ambaston', 'DE72 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(809, 'Derbyshire', 'Ambergate', 'DE56 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(810, 'Lincolnshire', 'Amber Hill', 'PE20 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(811, 'Gloucestershire', 'Amberley', 'GL5 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(812, 'Herefordshire', 'Amberley', 'HR1 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(813, 'West Sussex', 'Amberley', 'BN18 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(814, 'Northumberland', 'Amble', 'NE65 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(815, 'West Midlands', 'Amblecote', 'DY8 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(816, 'West Yorkshire', 'Ambler Thorn', 'BD13 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(817, 'Cumbria', 'Ambleside', 'LA22 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(818, 'Dyfed', 'Ambleston', 'SA62 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(819, 'Oxfordshire', 'Ambrosden', 'OX25 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(820, 'Lincolnshire', 'Amcotts', 'DN17 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(821, 'Berkshire', 'Amen Corner', 'RG12 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(822, 'West Yorkshire', 'America Moor', 'LS27 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(823, 'Buckinghamshire', 'Amersham', 'HP6 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(824, 'Buckinghamshire', 'Amersham Common', 'HP7 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(825, 'Buckinghamshire', 'Amersham Old Town', 'HP7 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(826, 'Buckinghamshire', 'Amersham on the Hill', 'HP6 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(827, 'Staffordshire', 'Amerton', 'ST18 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(828, 'Somerset', 'Amesbury', 'BA2 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(829, 'Wiltshire', 'Amesbury', 'SP4 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(830, 'Dorset', 'Ameysford', 'BH22 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(831, 'Staffordshire', 'Amington', 'B77 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(832, 'Dumfries', 'Amisfield', 'DG1 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(833, 'Gwynedd', 'Amlwch', 'LL68 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(834, 'Gwynedd', 'Amlwch Port / Porth Amlwch', 'LL68 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(835, 'Dyfed', 'Ammanford / Rhydaman', 'SA18 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(836, 'Somerset', 'Ammerham', 'TA20 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(837, 'North Yorkshire', 'Amotherby', 'YO17 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(838, 'Hampshire', 'Ampfield', 'SO51 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(839, 'North Yorkshire', 'Ampleforth', 'YO62 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(840, 'Gloucestershire', 'Ampney Crucis', 'GL7 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(841, 'Gloucestershire', 'Ampney St Mary', 'GL7 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(842, 'Gloucestershire', 'Ampney St Peter', 'GL7 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(843, 'Hampshire', 'Amport', 'SP11 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(844, 'Bedfordshire', 'Ampthill', 'MK45 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(845, 'Suffolk', 'Ampton', 'IP31 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(846, 'Dyfed', 'Amroth', 'SA67 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(847, 'Perth and Kinross', 'Amulree', 'PH8 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(848, 'Hertfordshire', 'Amwell', 'AL4 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(849, 'Inverness', 'Anagach', 'PH26 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(850, 'Inverness', 'Anaheilt', 'PH36 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(851, 'Ross and Cromarty', 'Anancaun', 'IV22 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(852, 'Ross and Cromarty', 'An Àrd', 'IV21 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(853, 'Lincolnshire', 'Ancaster', 'NG32 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(854, 'Lancashire', 'Anchor', 'BB3 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(855, 'Shropshire', 'Anchor', 'SY7 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(856, 'North Yorkshire', 'Anchorage Hill', 'DL10 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(857, 'Hampshire', 'Anchorage Park', 'PO3 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(858, 'Norfolk', 'Anchor Corner', 'NR17 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(859, 'Lancashire', 'Anchorsholme', 'FY5 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(860, 'Norfolk', 'Anchor Street', 'NR12 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(861, 'Western Isles', 'An Cnoc Ard', 'HS2 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(862, 'Greater Manchester', 'Ancoats', 'M1 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(863, 'Northumberland', 'Ancroft', 'TD15 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(864, 'Northumberland', 'Ancroft Northmoor', 'TD15 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(865, 'Roxburgh, Ettrick and Lauderdale', 'Ancrum', 'TD8 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(866, 'West Sussex', 'Ancton', 'PO22 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(867, 'Orkney', 'Ancumtoun', 'KW17 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(868, 'Lincolnshire', 'Anderby', 'PE24 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(869, 'Lincolnshire', 'Anderby Creek', 'PE24 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(870, 'Somerset', 'Andersea', 'TA7 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(871, 'Somerset', 'Andersfield', 'TA5 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(872, 'Dorset', 'Anderson', 'DT11 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(873, 'City of Glasgow', 'Anderston', 'G3 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(874, 'Cheshire', 'Anderton', 'CW9 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(875, 'Lancashire', 'Anderton', 'PR6 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(876, 'Lancashire', 'Andertons Mill', 'L40 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(877, 'Hampshire', 'Andover', 'SP10 1', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(878, 'Hampshire', 'Andover Down', 'SP11 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(879, 'Gloucestershire', 'Andoversford', 'GL54 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(880, 'Isle of Man', 'Andreas', 'IM7 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(881, 'West Sussex', 'Andrew\'s Hill', 'RH14 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(882, 'Hampshire', 'Andwell', 'RG27 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(883, 'Gwynedd', 'Anelog', 'LL53 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(884, 'Greater London', 'Anerley', 'SE20 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(885, 'Merseyside', 'Anfield', 'L4 2', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(886, 'Cornwall', 'Angarrack', 'TR27 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(887, 'Cornwall', 'Angarrick', 'TR11 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(888, 'Greater London', 'Angel', 'N1 9', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(889, 'Shropshire', 'Angelbank', 'SY8 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(890, 'Somerset', 'Angersleigh', 'TA3 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(891, 'Cumbria', 'Angerton', 'CA7 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(892, 'Dyfed', 'Angle', 'SA71 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(893, 'Western Isles', 'An Gleann Ur', 'HS2 0', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(894, 'Surrey', 'Anglefield Corner', 'RH9 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(895, 'West Sussex', 'Angmering', 'BN16 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(896, 'North Yorkshire', 'Angram', 'DL11 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(897, 'North Yorkshire', 'Angram', 'YO23 3', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(898, 'Northumberland', 'Anick', 'NE46 4', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(899, 'Worcestershire', 'Ankerdine Hill', 'WR6 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(900, 'East Riding of Yorkshire', 'Anlaby', 'HU10 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(901, 'East Riding of Yorkshire', 'Anlaby Common', 'HU4 7', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(902, 'East Riding of Yorkshire', 'Anlaby Park', 'HU4 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(903, 'Western Isles', 'An Leth Meadhanach', 'HS8 5', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(904, 'Ross and Cromarty', 'An Leth-Pheighinn / Lephin', 'IV55 8', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(905, 'Norfolk', 'Anmer', 'PE31 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(906, 'Hampshire', 'Anmore', 'PO7 6', '2020-08-28 21:11:30', '2020-08-28 21:11:30'),
(907, 'County Down', 'Annaclone', 'BT32 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(908, 'County Armagh', 'Annaghmore', 'BT62 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(909, 'County Down', 'Annahilt', 'BT26 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(910, 'County Armagh', 'Annahugh', 'BT61 8', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(911, 'County Down', 'Annalong', 'BT34 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(912, 'Dumfries', 'Annan', 'DG12 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(913, 'Cumbria', 'Annaside', 'LA19 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(914, 'Argyll and Bute', 'Annat', 'PA35 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(915, 'Ross and Cromarty', 'Annat', 'IV22 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(916, 'Lanarkshire', 'Annathill', 'ML5 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(917, 'Hampshire', 'Anna Valley', 'SP11 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(918, 'Ayrshire and Arran', 'Annbank', 'KA6 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(919, 'Nottinghamshire', 'Annesley', 'NG15 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(920, 'Nottinghamshire', 'Annesley Lane End', 'NG16 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(921, 'Nottinghamshire', 'Annesley Woodhouse', 'NG17 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(922, 'Suffolk', 'Annesons Corner', 'IP17 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(923, 'Durham', 'Annfield Plain', 'DH9 8', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(924, 'City of Glasgow', 'Anniesland', 'G13 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(925, 'Ross and Cromarty', 'Annishader', 'IV51 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(926, 'Suffolk', 'Annis Hill', 'NR35 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(927, 'Northumberland', 'Annitsford', 'NE23 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(928, 'Aberdeenshire', 'Annochie', 'AB41 8', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(929, 'County Down', 'Annsborough', 'BT31 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(930, 'Shropshire', 'Annscroft', 'SY5 8', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(931, 'Hampshire', 'Ann\'s Hill', 'PO12 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(932, 'Derbyshire', 'Annwell Place', 'LE65 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(933, 'Lancashire', 'Ansdell', 'FY8 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(934, 'Kent', 'Ansdore', 'CT4 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(935, 'Hertfordshire', 'Ansells End', 'SG4 8', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(936, 'Somerset', 'Ansford', 'BA7 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(937, 'Warwickshire', 'Ansley', 'CV10 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(938, 'Warwickshire', 'Ansley Common', 'CV10 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(939, 'Staffordshire', 'Anslow', 'DE13 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(940, 'Staffordshire', 'Anslow Common', 'DE13 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(941, 'Staffordshire', 'Anslow Gate', 'DE13 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(942, 'Surrey', 'Ansteadbrook', 'GU27 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(943, 'Hampshire', 'Anstey', 'GU34 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(944, 'Hertfordshire', 'Anstey', 'SG9 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(945, 'Leicestershire', 'Anstey', 'LE7 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(946, 'Fife', 'Anstruther', 'KY10 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(947, 'Fife', 'Anstruther Easter', 'KY10 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(948, 'Fife', 'Anstruther Wester', 'KY10 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(949, 'Dorset', 'Ansty', 'DT2 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(950, 'Warwickshire', 'Ansty', 'CV7 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(951, 'West Sussex', 'Ansty', 'RH17 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(952, 'Wiltshire', 'Ansty', 'SP3 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(953, 'Wiltshire', 'Ansty Coombe', 'SP3 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(954, 'Dorset', 'Ansty Cross', 'DT2 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(955, 'Hampshire', 'Anthill Common', 'PO7 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(956, 'Gloucestershire', 'Anthony\'s Cross', 'GL18 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(957, 'Cumbria', 'Anthorn', 'CA7 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(958, 'Norfolk', 'Antingham', 'NR28 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(959, 'Western Isles', 'An t-Ob', 'HS5 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(960, 'Lincolnshire', 'Anton\'s Gowt', 'PE22 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(961, 'Stirling and Falkirk', 'Antonshill', 'FK5 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(962, 'Cornwall', 'Antony', 'PL11 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(963, 'Cornwall', 'Antony Passage', 'PL12 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(964, 'County Antrim', 'Antrim', 'BT41 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(965, 'Cheshire', 'Antrobus', 'CW9 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(966, 'Cornwall', 'Antron', 'TR10 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(967, 'Kent', 'Anvil Green', 'CT4 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(968, 'Berkshire', 'Anvilles', 'RG17 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(969, 'Lincolnshire', 'Anwick', 'NG34 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(970, 'The Stewartry of Kirkcudbright', 'Anwoth', 'DG7 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(971, 'Inverness', 'Aonachan', 'PH34 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(972, 'Staffordshire', 'Apedale', 'ST5 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(973, 'Greater London', 'Aperfield', 'TN16 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(974, 'Worcestershire', 'Apes Dale', 'B60 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(975, 'Northamptonshire', 'Apethorpe', 'PE8 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(976, 'Staffordshire', 'Apeton', 'ST20 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(977, 'Lincolnshire', 'Apley', 'LN8 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(978, 'Shropshire', 'Apley Forge', 'WV16 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(979, 'Derbyshire', 'Apperknowle', 'S18 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(980, 'Gloucestershire', 'Apperley', 'GL19 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(981, 'West Yorkshire', 'Apperley Bridge', 'BD10 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(982, 'Northumberland', 'Apperley Dene', 'NE43 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(983, 'North Yorkshire', 'Appersett', 'DL8 3', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(984, 'Orkney', 'Appietown', 'KW17 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(985, 'Argyll and Bute', 'Appin', 'PA38 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(986, 'Lincolnshire', 'Appleby', 'DN15 0', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(987, 'Cumbria', 'Appleby-in-Westmorland', 'CA16 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(988, 'Leicestershire', 'Appleby Magna', 'DE12 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(989, 'Leicestershire', 'Appleby Parva', 'DE12 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(990, 'Ross and Cromarty', 'Applecross', 'IV54 8', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(991, 'Devon', 'Appledore', 'EX16 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(992, 'Devon', 'Appledore', 'EX39 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(993, 'Kent', 'Appledore', 'TN26 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(994, 'Kent', 'Appledore Heath', 'TN26 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(995, 'Oxfordshire', 'Appleford-on-Thames', 'OX14 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(996, 'North Yorkshire', 'Applegarth', 'DL10 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(997, 'Dumfries', 'Applegarthtown', 'DG11 1', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(998, 'Berkshire', 'Applehouse Hill', 'SL6 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(999, 'Hampshire', 'Applemore', 'SO45 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1000, 'Hampshire', 'Appleshaw', 'SP11 9', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1001, 'Cumbria', 'Applethwaite', 'CA12 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1002, 'Cheshire', 'Appleton', 'WA8 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1003, 'Oxfordshire', 'Appleton', 'OX13 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1004, 'North Yorkshire', 'Appleton-le-Moors', 'YO62 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1005, 'North Yorkshire', 'Appleton-le-Street', 'YO17 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1006, 'Cheshire', 'Appleton Park', 'WA4 5', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1007, 'North Yorkshire', 'Appleton Roebuck', 'YO23 7', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1008, 'Cheshire', 'Appleton Thorn', 'WA4 4', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1009, 'North Yorkshire', 'Appleton Wiske', 'DL6 2', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1010, 'Northamptonshire', 'Appletree', 'NN11 6', '2020-08-28 21:11:31', '2020-08-28 21:11:31'),
(1011, 'Powys', 'Appletree', 'SY5 0', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1012, 'Roxburgh, Ettrick and Lauderdale', 'Appletreehall', 'TD9 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1013, 'North Yorkshire', 'Appletreewick', 'BD23 6', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1014, 'Isle of Wight', 'Appley', 'PO33 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1015, 'Somerset', 'Appley', 'TA21 0', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1016, 'Lancashire', 'Appley Bridge', 'WN6 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1017, 'Bedfordshire', 'Appley Corner', 'MK45 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1018, 'Hertfordshire', 'Appspond', 'AL2 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1019, 'Isle of Wight', 'Apse Heath', 'PO36 0', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1020, 'Suffolk', 'Apsey Green', 'IP13 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1021, 'Hertfordshire', 'Apsley', 'HP3 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1022, 'Bedfordshire', 'Apsley End', 'SG5 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1023, 'West Sussex', 'Apuldram', 'PO20 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1024, 'Shropshire', 'Aqueduct', 'TF4 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1025, 'Aberdeenshire', 'Aquhythie', 'AB51 5', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1026, 'Ross and Cromarty', 'Arabella', 'IV19 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1027, 'Angus', 'Arbirlot', 'DD11 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1028, 'Berkshire', 'Arborfield', 'RG2 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1029, 'Berkshire', 'Arborfield Cross', 'RG2 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1030, 'Berkshire', 'Arborfield Garrison', 'RG2 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1031, 'South Yorkshire', 'Arbourthorne', 'S2 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1032, 'South Yorkshire', 'Arbourthorne Estate', 'S2 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1033, 'Angus', 'Arbroath', 'DD11 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1034, 'Cambridgeshire', 'Arbury', 'CB4 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1035, 'Kincardineshire', 'Arbuthnott', 'AB30 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1036, 'Ross and Cromarty', 'Arcan', 'IV6 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1037, 'Ross and Cromarty', 'Arcan Muir', 'IV6 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1038, 'Durham', 'Archdeacon Newton', 'DL2 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1039, 'Herefordshire', 'Archenfield', 'HR3 5', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1040, 'Herefordshire', 'Archenfield', 'HR9 5', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1041, 'East Lothian', 'Archerfield The Village', 'EH39 5', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1042, 'Moray', 'Archiestown', 'AB38 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1043, 'Greater London', 'Archway', 'N19 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1044, 'Cheshire', 'Arclid', 'CW11 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1045, 'Cheshire', 'Arclid Green', 'CW11 4', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1046, 'Sutherland', 'Ardachew', 'KW9 6', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1047, 'Sutherland', 'Ardachu', 'IV28 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1048, 'Argyll and Bute', 'Ardalanish', 'PA67 6', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1049, 'Aberdeenshire', 'Ardallie', 'AB42 5', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1050, 'Argyll and Bute', 'Ardanaiseig', 'PA35 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1051, 'Ross and Cromarty', 'Ardaneaskan', 'IV54 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1052, 'Argyll and Bute', 'Ardanstur', 'PA34 4', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1053, 'Ross and Cromarty', 'Ardarroch', 'IV54 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1054, 'Argyll and Bute', 'Ardbeg', 'PA42 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1055, 'Argyll and Bute', 'Ardbeg', 'PA20 0', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1056, 'County Tyrone', 'Ardboe', 'BT80 0', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1057, 'Argyll and Bute', 'Ardbrecknish', 'PA33 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1058, 'Ross and Cromarty', 'Ardcharnich', 'IV23 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1059, 'Argyll and Bute', 'Ardchattan', 'PA37 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1060, 'Argyll and Bute', 'Ardchiavaig', 'PA67 6', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1061, 'Argyll and Bute', 'Ardchonnell', 'PA35 1', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1062, 'Sutherland', 'Ardchronie', 'IV24 3', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1063, 'Stirling and Falkirk', 'Ardchullarie More', 'FK17 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1064, 'Stirling and Falkirk', 'Ardchyle', 'FK21 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1065, 'Ross and Cromarty', 'Ard-dhubh', 'IV54 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1066, 'Powys', 'Arddleen / Arddlin', 'SY22 6', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1067, 'Ross and Cromarty', 'Ard Dorch / An Àird Dhorcha', 'IV49 9', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1068, 'Hertfordshire', 'Ardeley', 'SG2 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1069, 'Ross and Cromarty', 'Ardelve', 'IV40 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1070, 'City of Glasgow', 'Arden', 'G46 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1071, 'Dunbartonshire', 'Arden', 'G83 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1072, 'Inverness', 'Ardendrain', 'IV4 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1073, 'Greater Manchester', 'Arden Park', 'SK6 2', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1074, 'Warwickshire', 'Ardens Grafton', 'B49 6', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1075, 'Argyll and Bute', 'Ardentallen', 'PA34 4', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1076, 'Argyll and Bute', 'Ardentinny', 'PA23 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1077, 'Stirling and Falkirk', 'Ardeonaig', 'FK21 8', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1078, 'Inverness', 'Ardersier', 'IV2 7', '2020-08-28 21:11:32', '2020-08-28 21:11:32'),
(1079, 'Inverness', 'Ardery', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1080, 'Ross and Cromarty', 'Ardessie', 'IV23 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1081, 'Argyll and Bute', 'Ardfern', 'PA31 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1082, 'Argyll and Bute', 'Ardfernal', 'PA60 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1083, 'Argyll and Bute', 'Ardfin', 'PA60 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1084, 'Argyll and Bute', 'Ardgartan', 'G83 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1085, 'County Derry / Londonderry', 'Ardgarvan', 'BT49 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1086, 'Sutherland', 'Ardgay', 'IV24 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1087, 'Sutherland', 'Ardgayhill', 'IV24 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1088, 'County Down', 'Ardglass', 'BT30 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1089, 'Western Isles', 'Ardhasaig / Àird Asaig', 'HS3 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1090, 'Western Isles', 'Ardheisker', 'HS6 5', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1091, 'Ross and Cromarty', 'Ardheslaig', 'IV54 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1092, 'Argyll and Bute', 'Ardifuir', 'PA31 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1093, 'Argyll and Bute', 'Ardinamir', 'PA34 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1094, 'Ross and Cromarty', 'Ardindrean', 'IV23 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1095, 'West Sussex', 'Ardingly', 'RH17 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1096, 'Oxfordshire', 'Ardington', 'OX12 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1097, 'Oxfordshire', 'Ardington Wick', 'OX12 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1098, 'Ross and Cromarty', 'Ardintoul', 'IV40 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1099, 'Aberdeenshire', 'Ardlawhill', 'AB43 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1100, 'Essex', 'Ardleigh', 'CO7 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1101, 'Greater London', 'Ardleigh Green', 'RM11 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1102, 'Essex', 'Ardleigh Heath', 'CO7 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1103, 'City of Dundee', 'Ardler', 'DD2 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1104, 'Perth and Kinross', 'Ardler', 'PH12 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1105, 'Oxfordshire', 'Ardley', 'OX27 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1106, 'Essex', 'Ardley End', 'CM22 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1107, 'Dunbartonshire', 'Ardlui', 'G83 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1108, 'Ross and Cromarty', 'Ardmair', 'IV26 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1109, 'Argyll and Bute', 'Ardmenish', 'PA60 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1110, 'Argyll and Bute', 'Ardminish', 'PA41 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1111, 'Inverness', 'Ardmolich', 'PH38 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1112, 'County Derry / Londonderry', 'Ardmore', 'BT47 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1113, 'Ross and Cromarty', 'Ardmore', 'IV19 1', '2020-08-28 21:11:33', '2020-08-28 21:11:33');
INSERT INTO `postcodes` (`id`, `state`, `city`, `postcode`, `created_at`, `updated_at`) VALUES
(1114, 'Western Isles', 'Ardmore / Àird Mhòr', 'HS8 5', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1115, 'Argyll and Bute', 'Ardnadam', 'PA23 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1116, 'Ross and Cromarty', 'Ardnagoine', 'IV26 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1117, 'Ross and Cromarty', 'Ardnagrask', 'IV6 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1118, 'Ross and Cromarty', 'Ardnarff', 'IV53 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1119, 'Inverness', 'Ardnastang', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1120, 'Aberdeenshire', 'Ardo', 'AB41 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1121, 'Dunbartonshire', 'Ardoch', 'G82 5', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1122, 'Aberdeenshire', 'Ardonald', 'AB54 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1123, 'Aberdeenshire', 'Ardoyne', 'AB52 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1124, 'Dunbartonshire', 'Ardpeaton', 'G84 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1125, 'Argyll and Bute', 'Ardrishaig', 'PA30 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1126, 'Ross and Cromarty', 'Ardroag', 'IV55 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1127, 'Western Isles', 'Ardroil', 'HS2 9', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1128, 'Ross and Cromarty', 'Ardross', 'IV17 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1129, 'Ayrshire and Arran', 'Ardrossan', 'KA22 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1130, 'Inverness', 'Ardshealach', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1131, 'Argyll and Bute', 'Ardskenish', 'PA61 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1132, 'Western Isles', 'Ardslave / Àird Shleibhe', 'HS3 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1133, 'South Yorkshire', 'Ardsley', 'S71 5', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1134, 'County Tyrone', 'Ardstraw', 'BT78 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1135, 'Perth and Kinross', 'Ardtalnaig', 'PH15 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1136, 'Inverness', 'Ardtoe / Àird Tobha', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1137, 'Ross and Cromarty', 'Ardtreck', 'IV47 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1138, 'Argyll and Bute', 'Ardtun', 'PA67 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1139, 'Argyll and Bute', 'Arduaine', 'PA34 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1140, 'Ross and Cromarty', 'Ardullie', 'IV16 9', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1141, 'Ross and Cromarty', 'Ardvannie', 'IV19 1', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1142, 'Ross and Cromarty', 'Ardvasar / Àird a\' Bhasair', 'IV45 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1143, 'Inverness', 'Ardverikie', 'PH20 1', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1144, 'Western Isles', 'Ardvey / Àird Mhìghe', 'HS3 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1145, 'Western Isles', 'Ardvourlie / Àird a\' Mhulaidh', 'HS3 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1146, 'Wigtown', 'Ardwell', 'DG9 9', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1147, 'Greater Manchester', 'Ardwick', 'M12 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1148, 'Inverness', 'Arean', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1149, 'Worcestershire', 'Areley Kings', 'DY13 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1150, 'Hampshire', 'Arford', 'GU35 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1151, 'Clwyd', 'Argoed', 'LL13 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1152, 'Gwent', 'Argoed', 'NP12 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1153, 'Shropshire', 'Argoed', 'SY7 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1154, 'Shropshire', 'Argoed', 'SY10 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1155, 'East Sussex', 'Argos Hill', 'TN6 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1156, 'Argyll and Bute', 'Aridhglas', 'PA66 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1157, 'Argyll and Bute', 'Arinagour', 'PA78 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1158, 'Inverness', 'Arisaig / Àrasaig', 'PH39 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1159, 'Inverness', 'Ariundle', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1160, 'Inverness', 'Arivegaig / Airigh Bheagaig', 'PH36 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1161, 'Western Isles', 'Arivruaich / Airidh a Bhruaich', 'HS2 9', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1162, 'North Yorkshire', 'Arkendale', 'HG5 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1163, 'Essex', 'Arkesden', 'CB11 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1164, 'Lancashire', 'Arkholme', 'LA6 1', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1165, 'Cumbria', 'Arkleby', 'CA7 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1166, 'North Yorkshire', 'Arkleside', 'DL8 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1167, 'Dumfries', 'Arkleton', 'DG13 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1168, 'North Yorkshire', 'Arkle Town', 'DL11 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1169, 'Greater London', 'Arkley', 'EN5 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1170, 'South Yorkshire', 'Arksey', 'DN5 0', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1171, 'Derbyshire', 'Arkwright Town', 'S44 5', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1172, 'Gloucestershire', 'Arle', 'GL51 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1173, 'Gloucestershire', 'Arlebrook', 'GL10 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1174, 'Cumbria', 'Arlecdon', 'CA26 3', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1175, 'Warwickshire', 'Arlescote', 'OX17 1', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1176, 'Bedfordshire', 'Arlesey', 'SG15 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1177, 'Shropshire', 'Arleston', 'TF1 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1178, 'Cheshire', 'Arley', 'CW9 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1179, 'Cheshire', 'Arley Green', 'CW9 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1180, 'Gloucestershire', 'Arlingham', 'GL2 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1181, 'Devon', 'Arlington', 'EX31 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1182, 'East Sussex', 'Arlington', 'BN26 6', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1183, 'Gloucestershire', 'Arlington', 'GL7 5', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1184, 'Norfolk', 'Arlington', 'NR2 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1185, 'Devon', 'Arlington Beccott', 'EX31 4', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1186, 'Sutherland', 'Armadale', 'KW14 7', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1187, 'West Lothian', 'Armadale', 'EH48 2', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1188, 'Ross and Cromarty', 'Armadale / Armadail', 'IV45 8', '2020-08-28 21:11:33', '2020-08-28 21:11:33'),
(1189, 'County Armagh', 'Armagh', 'BT61 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1190, 'Cumbria', 'Armathwaite', 'CA4 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1191, 'Essex', 'Armigers', 'CM6 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1192, 'Norfolk', 'Arminghall', 'NR14 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1193, 'Staffordshire', 'Armitage', 'WS15 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1194, 'West Yorkshire', 'Armitage Bridge', 'HD4 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1195, 'West Yorkshire', 'Armley', 'LS12 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1196, 'County Antrim', 'Armoy', 'BT53 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1197, 'Warwickshire', 'Armscote', 'CV37 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1198, 'Staffordshire', 'Armsdale', 'ST21 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1199, 'Staffordshire', 'Armshead', 'ST9 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1200, 'Northamptonshire', 'Armston', 'PE8 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1201, 'South Yorkshire', 'Armthorpe', 'DN3 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1202, 'Cumbria', 'Arnaby', 'LA18 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1203, 'Aberdeenshire', 'Arnage', 'AB41 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1204, 'North Yorkshire', 'Arncliffe', 'BD23 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1205, 'Fife', 'Arncroach', 'KY10 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1206, 'Dorset', 'Arne', 'BH20 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1207, 'Leicestershire', 'Arnesby', 'LE8 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1208, 'County Fermanagh', 'Arney', 'BT92 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1209, 'Ross and Cromarty', 'Arnisdale', 'IV40 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1210, 'Ross and Cromarty', 'Arnish', 'IV40 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1211, 'Midlothian', 'Arniston', 'EH23 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1212, 'Western Isles', 'Arnol', 'HS2 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1213, 'East Riding of Yorkshire', 'Arnold', 'HU11 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1214, 'Nottinghamshire', 'Arnold', 'NG5 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1215, 'Greater London', 'Arnos Grove', 'N11 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1216, 'Bristol', 'Arno\'s Vale', 'BS4 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1217, 'Stirling and Falkirk', 'Arnothill', 'FK1 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1218, 'Stirling and Falkirk', 'Arnprior', 'FK8 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1219, 'Cumbria', 'Arnside', 'LA5 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1220, 'Argyll and Bute', 'Aros', 'PA72 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1221, 'Clwyd', 'Arowry', 'SY13 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1222, 'Ross and Cromarty', 'Arpafeelie', 'IV1 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1223, 'Kent', 'Arpinge', 'CT18 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1224, 'Cumbria', 'Arrad Foot', 'LA12 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1225, 'Banffshire', 'Arradoul', 'AB56 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1226, 'East Riding of Yorkshire', 'Arram', 'HU17 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1227, 'North Yorkshire', 'Arrathorne', 'DL8 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1228, 'Isle of Wight', 'Arreton', 'PO30 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1229, 'Ross and Cromarty', 'Arrina / Arinacrinachd', 'IV54 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1230, 'Cambridgeshire', 'Arrington', 'SG8 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1231, 'Ross and Cromarty', 'Arrisa', 'IV54 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1232, 'Dunbartonshire', 'Arrochar / An t-Àrchar', 'G83 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1233, 'Warwickshire', 'Arrow', 'B49 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1234, 'Merseyside', 'Arrowe Hill', 'CH49 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1235, 'Worcestershire', 'Arrowfield Top', 'B48 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1236, 'Herefordshire', 'Arrow Green', 'HR6 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1237, 'Cumbria', 'Arrowthwaite', 'CA28 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1238, 'West Yorkshire', 'Arrunden', 'HD9 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1239, 'Shropshire', 'Arscott', 'SY5 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1240, 'Ross and Cromarty', 'Artafallie', 'IV1 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1241, 'Cheshire', 'Arthill', 'WA14 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1242, 'West Yorkshire', 'Arthington', 'LS21 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1243, 'Northamptonshire', 'Arthingworth', 'LE16 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1244, 'Gwynedd', 'Arthog', 'LL39 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1245, 'Aberdeenshire', 'Arthrath', 'AB41 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1246, 'Renfrewshire', 'Arthurlie', 'G78 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1247, 'West Yorkshire', 'Arthursdale', 'LS15 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1248, 'Tyne and Wear', 'Arthur\'s Hill', 'NE4 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1249, 'Perth and Kinross', 'Arthurstone', 'PH12 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1250, 'County Derry / Londonderry', 'Articlave', 'BT51 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1251, 'County Tyrone', 'Artigarvan', 'BT82 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1252, 'County Derry / Londonderry', 'Artikelly', 'BT49 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1253, 'Surrey', 'Artington', 'GU3 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1254, 'West Sussex', 'Arundel', 'BN18 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1255, 'Inverness', 'Aryhoulan', 'PH33 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1256, 'Cumbria', 'Asby', 'CA14 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1257, 'Argyll and Bute', 'Ascog', 'PA20 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1258, 'Berkshire', 'Ascot', 'SL5 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1259, 'Buckinghamshire', 'Ascott', 'LU7 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1260, 'Warwickshire', 'Ascott', 'CV36 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1261, 'Oxfordshire', 'Ascott d\' Oyley', 'OX7 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1262, 'Oxfordshire', 'Ascott Earl', 'OX7 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1263, 'Oxfordshire', 'Ascott-under-Wychwood', 'OX7 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1264, 'Angus', 'Ascreavie', 'DD8 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1265, 'North Yorkshire', 'Asenby', 'YO7 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1266, 'Leicestershire', 'Asfordby', 'LE14 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1267, 'Leicestershire', 'Asfordby Hill', 'LE14 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1268, 'Lincolnshire', 'Asgarby', 'NG34 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1269, 'Lincolnshire', 'Asgarby', 'PE23 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1270, 'Devon', 'Ash', 'TQ6 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1271, 'Dorset', 'Ash', 'DT11 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1272, 'Kent', 'Ash', 'TN15 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1273, 'Kent', 'Ash', 'CT3 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1274, 'Somerset', 'Ash', 'TA12 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1275, 'Surrey', 'Ash', 'GU12 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1276, 'Ross and Cromarty', 'Ashaig / Aisig', 'IV42 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1277, 'Berkshire', 'Ashampstead', 'RG8 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1278, 'Berkshire', 'Ashampstead Green', 'RG8 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1279, 'Kent', 'Ashbank', 'ME17 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1280, 'Staffordshire', 'Ash Bank', 'ST2 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1281, 'Somerset', 'Ashbeer', 'TA4 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1282, 'Suffolk', 'Ashbocking', 'IP6 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1283, 'Derbyshire', 'Ashbourne', 'DE6 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1284, 'Wiltshire', 'Ash Brake', 'SN25 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1285, 'Somerset', 'Ashbrittle', 'TA21 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1286, 'Hertfordshire', 'Ashbrook', 'SG4 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1287, 'Shropshire', 'Ashbrook', 'SY6 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1288, 'Tyne and Wear', 'Ashbrooke', 'SR2 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1289, 'East Sussex', 'Ashburnham Forge', 'TN33 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1290, 'Devon', 'Ashburton', 'TQ13 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1291, 'Devon', 'Ashbury', 'EX20 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1292, 'Oxfordshire', 'Ashbury', 'SN6 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1293, 'Lincolnshire', 'Ashby', 'DN16 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1294, 'Lincolnshire', 'Ashby by Partney', 'PE23 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1295, 'Lincolnshire', 'Ashby cum Fenby', 'DN37 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1296, 'Lincolnshire', 'Ashby de la Launde', 'LN4 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1297, 'Leicestershire', 'Ashby-de-la-Zouch', 'LE65 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1298, 'Leicestershire', 'Ashby Folville', 'LE14 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1299, 'Lincolnshire', 'Ashby Hill', 'DN37 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1300, 'Leicestershire', 'Ashby Magna', 'LE17 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1301, 'Leicestershire', 'Ashby Parva', 'LE17 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1302, 'Lincolnshire', 'Ashby Puerorum', 'LN9 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1303, 'Northamptonshire', 'Ashby St Ledgers', 'CV23 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1304, 'Norfolk', 'Ashby St Mary', 'NR14 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1305, 'Leicestershire', 'Ashby Woulds', 'DE12 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1306, 'Gloucestershire', 'Ashchurch', 'GL20 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1307, 'Devon', 'Ashcombe', 'EX7 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1308, 'Somerset', 'Ashcombe Park', 'BS22 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1309, 'Suffolk', 'Ash Corner', 'IP13 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1310, 'Somerset', 'Ashcott', 'TA7 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1311, 'Somerset', 'Ashcott Corner', 'BA6 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1312, 'Devon', 'Ash Cross', 'EX20 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1313, 'Somerset', 'Ash Cross', 'TA3 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1314, 'Devon', 'Ashculme', 'EX15 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1315, 'Essex', 'Ashdon', 'CB10 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1316, 'Hampshire', 'Ashe', 'RG25 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1317, 'Essex', 'Asheldham', 'CM0 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1318, 'Essex', 'Ashen', 'CO10 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1319, 'Buckinghamshire', 'Ashendon', 'HP18 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1320, 'Isle of Wight', 'Ashengrove', 'PO30 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1321, 'West Yorkshire', 'Ashenhurst', 'HD4 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1322, 'Buckinghamshire', 'Asheridge', 'HP5 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1323, 'Surrey', 'Ash Estates', 'TW17 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1324, 'Hampshire', 'Ashe Warren', 'RG25 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1325, 'Isle of Wight', 'Ashey', 'PO33 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1326, 'Dyfed', 'Ashfield', 'SA19 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1327, 'Hampshire', 'Ashfield', 'SO51 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1328, 'Herefordshire', 'Ashfield', 'HR9 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1329, 'Stirling and Falkirk', 'Ashfield', 'FK15 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1330, 'West Yorkshire', 'Ashfield', 'WF6 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1331, 'Worcestershire', 'Ashfield', 'WR13 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1332, 'Suffolk', 'Ashfield Cum Thorpe', 'IP14 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1333, 'Suffolk', 'Ashfield Green', 'IP21 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1334, 'Suffolk', 'Ashfield Green', 'CB8 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1335, 'Shropshire', 'Ashfields', 'TF9 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1336, 'West Sussex', 'Ashfold Crossways', 'RH13 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1337, 'North Yorkshire', 'Ashfold Side', 'HG3 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1338, 'Devon', 'Ashford', 'TQ7 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1339, 'Devon', 'Ashford', 'EX31 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1340, 'Hampshire', 'Ashford', 'SP6 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1341, 'Kent', 'Ashford', 'TN23 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1342, 'Surrey', 'Ashford', 'TW15 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1343, 'Shropshire', 'Ashford Bowdler', 'SY8 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1344, 'Shropshire', 'Ashford Carbonell', 'SY8 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1345, 'Surrey', 'Ashford Common', 'TW15 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1346, 'Hampshire', 'Ashford Hill', 'RG19 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1347, 'Derbyshire', 'Ashford in the Water', 'DE45 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1348, 'Derbyshire', 'Ashgate', 'S42 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1349, 'Derbyshire', 'Ashgate', 'S40 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1350, 'Lanarkshire', 'Ashgill', 'ML9 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1351, 'Surrey', 'Ash Green', 'GU12 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1352, 'Warwickshire', 'Ash Green', 'CV7 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1353, 'Somerset', 'Ashgrove', 'BA2 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1354, 'Devon', 'Ash Hill', 'TQ14 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1355, 'Roxburgh, Ettrick and Lauderdale', 'Ashiestiel', 'TD1 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1356, 'Devon', 'Ashill', 'EX15 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1357, 'Norfolk', 'Ashill', 'IP25 7', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1358, 'Somerset', 'Ashill', 'TA19 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1359, 'Essex', 'Ashingdon', 'SS4 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1360, 'Dorset', 'Ashington', 'BH21 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1361, 'Northumberland', 'Ashington', 'NE63 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1362, 'Somerset', 'Ashington', 'BA22 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1363, 'West Sussex', 'Ashington', 'RH20 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1364, 'Lincolnshire', 'Ashington End', 'PE24 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1365, 'Roxburgh, Ettrick and Lauderdale', 'Ashkirk', 'TD7 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1366, 'Buckinghamshire', 'Ashland', 'MK6 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1367, 'Hampshire', 'Ashlett', 'SO45 1', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1368, 'Gloucestershire', 'Ashleworth', 'GL19 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1369, 'Cambridgeshire', 'Ashley', 'CB8 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1370, 'Cheshire', 'Ashley', 'WA15 0', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1371, 'Dorset', 'Ashley', 'BH24 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1372, 'Gloucestershire', 'Ashley', 'GL8 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1373, 'Hampshire', 'Ashley', 'SO20 6', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1374, 'Hampshire', 'Ashley', 'BH25 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1375, 'Kent', 'Ashley', 'CT15 5', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1376, 'Northamptonshire', 'Ashley', 'LE16 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1377, 'Staffordshire', 'Ashley', 'TF9 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1378, 'Wiltshire', 'Ashley', 'SN13 8', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1379, 'Staffordshire', 'Ashley Dale', 'TF9 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1380, 'Bristol', 'Ashley Down', 'BS7 9', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1381, 'Buckinghamshire', 'Ashley Green', 'HP5 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1382, 'Derbyshire', 'Ashleyhay', 'DE4 4', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1383, 'Dorset', 'Ashley Heath', 'BH24 2', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1384, 'Greater Manchester', 'Ashley Heath', 'WA14 3', '2020-08-28 21:11:34', '2020-08-28 21:11:34'),
(1385, 'Staffordshire', 'Ashley Heath', 'TF9 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1386, 'Herefordshire', 'Ashley Moor', 'SY8 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1387, 'Surrey', 'Ashley Park', 'KT12 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1388, 'Shropshire', 'Ash Magna', 'SY13 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1389, 'Norfolk', 'Ashmanhaugh', 'NR12 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1390, 'Hampshire', 'Ashmansworth', 'RG20 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1391, 'Devon', 'Ashmansworthy', 'EX39 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1392, 'Gloucestershire', 'Ashmead Green', 'GL11 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1393, 'Devon', 'Ashmill', 'EX21 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1394, 'Devon', 'Ash Mill', 'EX36 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1395, 'Devon', 'Ash Moor', 'EX36 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1396, 'Dorset', 'Ashmore', 'SP5 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1397, 'Staffordshire', 'Ashmore Brook', 'WS13 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1398, 'Berkshire', 'Ashmore Green', 'RG18 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1399, 'West Midlands', 'Ashmore Lake', 'WV12 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1400, 'West Midlands', 'Ashmore Park', 'WV11 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1401, 'Derbyshire', 'Ashopton', 'S33 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1402, 'Warwickshire', 'Ashorne', 'CV35 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1403, 'Derbyshire', 'Ashover', 'S45 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1404, 'Derbyshire', 'Ashover Hay', 'S45 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1405, 'Warwickshire', 'Ashow', 'CV8 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1406, 'Shropshire', 'Ash Parva', 'SY13 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1407, 'Herefordshire', 'Ashperton', 'HR8 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1408, 'Devon', 'Ashprington', 'TQ9 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1409, 'Somerset', 'Ash Priors', 'TA4 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1410, 'Devon', 'Ashreigney', 'EX18 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1411, 'Devon', 'Ashridge Court', 'EX20 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1412, 'Suffolk', 'Ash Street', 'IP7 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1413, 'Surrey', 'Ashtead', 'KT21 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1414, 'Surrey', 'Ashtead Common', 'KT21 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1415, 'Devon', 'Ash Thomas', 'EX16 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1416, 'Cambridgeshire', 'Ashton', 'PE9 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1417, 'Cornwall', 'Ashton', 'PL17 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1418, 'Cornwall', 'Ashton', 'TR13 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1419, 'Hampshire', 'Ashton', 'SO32 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1420, 'Herefordshire', 'Ashton', 'HR6 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1421, 'Northamptonshire', 'Ashton', 'PE8 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1422, 'Northamptonshire', 'Ashton', 'NN7 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1423, 'Renfrewshire', 'Ashton', 'PA19 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1424, 'Somerset', 'Ashton', 'BS28 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1425, 'Lancashire', 'Ashton Bank', 'PR2 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1426, 'Wiltshire', 'Ashton Common', 'BA14 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1427, 'Bristol', 'Ashton Gate', 'BS3 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1428, 'East Sussex', 'Ashton Green', 'BN8 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1429, 'Cheshire', 'Ashton Hayes', 'CH3 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1430, 'Greater Manchester', 'Ashton Heath', 'WN4 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1431, 'Greater Manchester', 'Ashton-in-Makerfield', 'WN4 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1432, 'Wiltshire', 'Ashton Keynes', 'SN6 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1433, 'Lancashire', 'Ashton-on-Ribble', 'PR2 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1434, 'Merseyside', 'Ashton\'s Green', 'WA9 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1435, 'Worcestershire', 'Ashton under Hill', 'WR11 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1436, 'Greater Manchester', 'Ashton-under-Lyne', 'OL6 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1437, 'Greater Manchester', 'Ashton upon Mersey', 'M33 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1438, 'Bristol', 'Ashton Vale', 'BS3 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1439, 'Somerset', 'Ashton Watering', 'BS48 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1440, 'Hampshire', 'Ashurst', 'SO40 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1441, 'Kent', 'Ashurst', 'TN3 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1442, 'Lancashire', 'Ashurst', 'WN8 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1443, 'West Sussex', 'Ashurst', 'BN44 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1444, 'Hampshire', 'Ashurst Bridge', 'SO40 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1445, 'West Sussex', 'Ashurst Wood', 'RH19 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1446, 'Gwent', 'Ashvale', 'NP22 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1447, 'Surrey', 'Ash Vale', 'GU12 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1448, 'Devon', 'Ashwater', 'EX21 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1449, 'Hertfordshire', 'Ashwell', 'SG7 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1450, 'Rutland', 'Ashwell', 'LE15 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1451, 'Somerset', 'Ashwell', 'TA19 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1452, 'Hertfordshire', 'Ashwell End', 'SG7 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1453, 'Norfolk', 'Ashwellthorpe', 'NR16 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1454, 'Somerset', 'Ashwick', 'BA3 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1455, 'Norfolk', 'Ashwicken', 'PE32 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1456, 'Staffordshire', 'Ashwood', 'DY6 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1457, 'Cumbria', 'Askam in Furness', 'LA16 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1458, 'North Yorkshire', 'Aske', 'DL10 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1459, 'South Yorkshire', 'Askern', 'DN6 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1460, 'Dorset', 'Askerswell', 'DT2 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1461, 'Lincolnshire', 'Askerton Hill', 'NG23 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1462, 'Buckinghamshire', 'Askett', 'HP27 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1463, 'Cumbria', 'Askham', 'CA10 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1464, 'Nottinghamshire', 'Askham', 'NG22 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1465, 'North Yorkshire', 'Askham Bryan', 'YO23 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1466, 'North Yorkshire', 'Askham Richard', 'YO23 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1467, 'Argyll and Bute', 'Asknish', 'PA31 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1468, 'Argyll and Bute', 'Askomill', 'PA28 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1469, 'North Yorkshire', 'Askrigg', 'DL8 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1470, 'North Yorkshire', 'Askwith', 'LS21 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1471, 'Lincolnshire', 'Aslackby', 'NG34 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1472, 'Norfolk', 'Aslacton', 'NR15 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1473, 'Nottinghamshire', 'Aslockton', 'NG13 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1474, 'Somerset', 'Asney', 'BA16 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1475, 'Suffolk', 'Aspall', 'IP14 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1476, 'Cumbria', 'Aspatria', 'CA7 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1477, 'Hertfordshire', 'Aspenden', 'SG9 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1478, 'Lincolnshire', 'Asperton', 'PE20 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1479, 'Nottinghamshire', 'Aspley', 'NG8 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1480, 'Staffordshire', 'Aspley', 'ST21 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1481, 'West Yorkshire', 'Aspley', 'HD1 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1482, 'Bedfordshire', 'Aspley Guise', 'MK17 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1483, 'Bedfordshire', 'Aspley Heath', 'MK17 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1484, 'Warwickshire', 'Aspley Heath', 'B94 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1485, 'Greater Manchester', 'Aspull', 'WN2 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1486, 'Greater Manchester', 'Aspull Common', 'WN7 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1487, 'Shetland', 'Assater', 'ZE2 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1488, 'East Riding of Yorkshire', 'Asselby', 'DN14 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1489, 'Lincolnshire', 'Asserby', 'LN13 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1490, 'Lincolnshire', 'Asserby Turn', 'LN13 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1491, 'Suffolk', 'Assington', 'CO10 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1492, 'Suffolk', 'Assington Green', 'CO10 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1493, 'Cheshire', 'Astbury', 'CW12 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1494, 'Cheshire', 'Astbury Marsh', 'CW12 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1495, 'Northamptonshire', 'Astcote', 'NN12 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1496, 'Lincolnshire', 'Asterby', 'LN9 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1497, 'Shropshire', 'Asterley', 'SY5 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1498, 'Shropshire', 'Asterton', 'SY7 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1499, 'Oxfordshire', 'Asthall', 'OX18 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1500, 'Oxfordshire', 'Asthall Leigh', 'OX29 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1501, 'Sutherland', 'Astle', 'IV25 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1502, 'Greater Manchester', 'Astley', 'M29 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1503, 'Shropshire', 'Astley', 'SY4 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1504, 'Warwickshire', 'Astley', 'CV10 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1505, 'Worcestershire', 'Astley', 'DY13 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1506, 'Shropshire', 'Astley Abbotts', 'WV16 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1507, 'Greater Manchester', 'Astley Bridge', 'BL1 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1508, 'Worcestershire', 'Astley Burf', 'DY13 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1509, 'Worcestershire', 'Astley Cross', 'DY13 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1510, 'Greater Manchester', 'Astley Green', 'M29 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1511, 'Lancashire', 'Astley Village', 'PR7 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1512, 'Cheshire', 'Astmoor', 'WA7 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1513, 'Berkshire', 'Aston', 'RG9 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1514, 'Cheshire', 'Aston', 'WA7 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1515, 'Cheshire', 'Aston', 'CW5 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1516, 'Clwyd', 'Aston', 'CH5 1', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1517, 'Derbyshire', 'Aston', 'S33 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1518, 'Derbyshire', 'Aston', 'DE6 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1519, 'Herefordshire', 'Aston', 'HR6 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1520, 'Hertfordshire', 'Aston', 'SG2 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1521, 'Oxfordshire', 'Aston', 'OX18 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1522, 'Shropshire', 'Aston', 'TF6 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1523, 'Shropshire', 'Aston', 'WV5 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1524, 'Shropshire', 'Aston', 'SY4 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1525, 'South Yorkshire', 'Aston', 'S26 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1526, 'Staffordshire', 'Aston', 'ST18 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1527, 'Staffordshire', 'Aston', 'TF9 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1528, 'West Midlands', 'Aston', 'B6 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1529, 'Buckinghamshire', 'Aston Abbotts', 'HP22 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1530, 'Worcestershire', 'Aston Bank', 'WR15 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1531, 'Shropshire', 'Aston Botterell', 'WV16 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1532, 'Staffordshire', 'Aston-by-Stone', 'ST15 0', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1533, 'Warwickshire', 'Aston Cantlow', 'B95 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1534, 'Buckinghamshire', 'Aston Clinton', 'HP22 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1535, 'Herefordshire', 'Aston Crews', 'HR9 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1536, 'Gloucestershire', 'Aston Cross', 'GL20 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1537, 'Hertfordshire', 'Aston End', 'SG2 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1538, 'Shropshire', 'Aston Eyre', 'WV16 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1539, 'Worcestershire', 'Aston Fields', 'B60 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1540, 'Leicestershire', 'Aston Flamville', 'LE10 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1541, 'Cheshire', 'Aston Heath', 'WA7 3', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1542, 'Derbyshire', 'Aston Heath', 'DE6 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1543, 'Herefordshire', 'Aston Ingham', 'HR9 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1544, 'Cheshire', 'Aston juxta Mondrum', 'CW5 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1545, 'Northamptonshire', 'Aston le Walls', 'NN11 6', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1546, 'Gloucestershire', 'Aston Magna', 'GL56 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1547, 'Shropshire', 'Aston Munslow', 'SY7 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1548, 'West Midlands', 'Aston New Town', 'B6 4', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1549, 'Gloucestershire', 'Aston on Carrant', 'GL20 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1550, 'Shropshire', 'Aston on Clun', 'SY7 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1551, 'Derbyshire', 'Aston-on-Trent', 'DE72 2', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1552, 'Shropshire', 'Aston Pigott', 'SY5 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1553, 'Shropshire', 'Aston Rogers', 'SY5 9', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1554, 'Oxfordshire', 'Aston Rowant', 'OX49 5', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1555, 'Buckinghamshire', 'Aston Sandford', 'HP17 8', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1556, 'Worcestershire', 'Aston Somerville', 'WR12 7', '2020-08-28 21:11:35', '2020-08-28 21:11:35'),
(1557, 'Shropshire', 'Aston Square', 'SY11 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1558, 'Gloucestershire', 'Aston Subedge', 'GL55 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1559, 'Oxfordshire', 'Aston Tirrold', 'OX11 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1560, 'Oxfordshire', 'Aston Upthorpe', 'OX11 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1561, 'Northamptonshire', 'Astrop', 'OX17 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1562, 'Hertfordshire', 'Astrope', 'HP23 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1563, 'Bedfordshire', 'Astwick', 'SG5 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1564, 'Derbyshire', 'Astwith', 'S45 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1565, 'Buckinghamshire', 'Astwood', 'MK16 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1566, 'Worcestershire', 'Astwood', 'B60 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1567, 'Worcestershire', 'Astwood', 'WR3 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1568, 'Worcestershire', 'Astwood Bank', 'B96 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1569, 'Lincolnshire', 'Aswarby', 'NG34 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1570, 'Lincolnshire', 'Aswardby', 'PE23 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1571, 'Shropshire', 'Atcham', 'SY5 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1572, 'Worcestershire', 'Atch Lench', 'WR11 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1573, 'Dorset', 'Athelhampton', 'DT2 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1574, 'Suffolk', 'Athelington', 'IP21 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1575, 'Somerset', 'Athelney', 'TA7 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1576, 'East Lothian', 'Athelstaneford', 'EH39 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1577, 'Isle of Wight', 'Atherfield Green', 'PO38 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1578, 'Devon', 'Atherington', 'EX37 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1579, 'West Sussex', 'Atherington', 'BN17 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1580, 'South Yorkshire', 'Athersley North', 'S71 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1581, 'South Yorkshire', 'Athersley South', 'S71 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1582, 'Somerset', 'Atherstone', 'TA19 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1583, 'Warwickshire', 'Atherstone', 'CV9 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1584, 'Warwickshire', 'Atherstone on Stour', 'CV37 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1585, 'Greater Manchester', 'Atherton', 'M46 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1586, 'West Yorkshire', 'Atkinson Hill', 'LS10 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1587, 'South Glamorgan', 'Atlantic Wharf', 'CF10 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1588, 'Derbyshire', 'Atlow', 'DE6 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1589, 'Dorset', 'Atrim', 'DT6 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1590, 'Ross and Cromarty', 'Attadale', 'IV54 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1591, 'Nottinghamshire', 'Attenborough', 'NG9 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1592, 'Buckinghamshire', 'Atterbury', 'MK10 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1593, 'Lincolnshire', 'Atterby', 'LN8 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1594, 'South Yorkshire', 'Attercliffe', 'S9 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1595, 'South Yorkshire', 'Attercliffe Hill Top', 'S9 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1596, 'Shropshire', 'Atterley', 'TF13 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1597, 'Leicestershire', 'Atterton', 'CV13 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1598, 'County Down', 'Atticall', 'BT34 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1599, 'Norfolk', 'Attleborough', 'NR17 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1600, 'Warwickshire', 'Attleborough', 'CV11 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1601, 'Norfolk', 'Attlebridge', 'NR9 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1602, 'Suffolk', 'Attleton Green', 'CB8 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1603, 'East Riding of Yorkshire', 'Atwick', 'YO25 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1604, 'Wiltshire', 'Atworth', 'SN12 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1605, 'Herefordshire', 'Auberrow', 'HR4 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1606, 'Lincolnshire', 'Aubourn', 'LN5 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1607, 'Ayrshire and Arran', 'Auchagallon', 'KA27 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1608, 'Aberdeenshire', 'Aucharnie', 'AB54 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1609, 'Kincardineshire', 'Auchattie', 'AB31 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1610, 'Banffshire', 'Auchbreck', 'AB37 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1611, 'Renfrewshire', 'Auchenback', 'G78 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1612, 'Dumfries', 'Auchenbainzie', 'DG3 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1613, 'Kincardineshire', 'Auchenblae', 'AB30 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1614, 'Stirling and Falkirk', 'Auchenbowie', 'FK7 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1615, 'Ayrshire and Arran', 'Auchencairn', 'KA27 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1616, 'Dumfries', 'Auchencairn', 'DG1 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1617, 'The Stewartry of Kirkcudbright', 'Auchencairn', 'DG7 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1618, 'Ayrshire and Arran', 'Auchencar', 'KA27 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1619, 'Berwickshire', 'Auchencrow', 'TD14 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1620, 'Midlothian', 'Auchendinny', 'EH26 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1621, 'Aberdeenshire', 'Auchendryne', 'AB35 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1622, 'Lanarkshire', 'Auchengray', 'ML11 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1623, 'Moray', 'Auchenhalrig', 'IV32 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1624, 'Ayrshire and Arran', 'Auchenharvie', 'KA20 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1625, 'Lanarkshire', 'Auchenheath', 'ML11 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1626, 'Ayrshire and Arran', 'Auchenhew', 'KA27 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1627, 'Argyll and Bute', 'Auchenlochan', 'PA21 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1628, 'Wigtown', 'Auchenmalg', 'DG8 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1629, 'Dunbartonshire', 'Auchenreoch', 'G66 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1630, 'Lanarkshire', 'Auchentibber', 'G72 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1631, 'Ayrshire and Arran', 'Auchentiber', 'KA13 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1632, 'Dunbartonshire', 'Auchinairn', 'G64 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1633, 'Stirling and Falkirk', 'Auchincloch', 'FK4 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1634, 'Banffshire', 'Auchinderran', 'AB55 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1635, 'Argyll and Bute', 'Auchindrain', 'PA32 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1636, 'Ross and Cromarty', 'Auchindrean', 'IV23 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1637, 'Banffshire', 'Auchingoul', 'AB54 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1638, 'Banffshire', 'Auchininna', 'AB53 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1639, 'Ayrshire and Arran', 'Auchinleck', 'KA18 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1640, 'Angus', 'Auchinleish', 'PH11 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1641, 'Lanarkshire', 'Auchinloch', 'G66 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1642, 'Lanarkshire', 'Auchinraith', 'G72 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1643, 'Dunbartonshire', 'Auchinstarry', 'G65 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1644, 'Sutherland', 'Auchintoul', 'IV27 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1645, 'Aberdeenshire', 'Auchleven', 'AB52 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1646, 'Lanarkshire', 'Auchlochan', 'ML11 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1647, 'Kincardineshire', 'Auchlunies', 'AB12 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1648, 'Stirling and Falkirk', 'Auchlyne', 'FK21 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1649, 'Aberdeenshire', 'Auchmaliddie', 'AB42 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1650, 'Ayrshire and Arran', 'Auchmillan', 'KA5 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1651, 'Angus', 'Auchmithie', 'DD11 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1652, 'Perth and Kinross', 'Auchmuirbridge', 'KY6 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1653, 'Fife', 'Auchmuty', 'KY7 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1654, 'Angus', 'Auchnacree', 'DD8 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1655, 'Perth and Kinross', 'Auchnafree', 'PH8 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1656, 'Aberdeenshire', 'Auchnagatt', 'AB41 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1657, 'Inverness', 'Auchnahillin', 'IV2 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1658, 'Banffshire', 'Auchnarrow', 'AB37 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1659, 'Perth and Kinross', 'Auchterarder', 'PH3 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1660, 'Inverness', 'Auchteraw', 'PH32 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1661, 'Ross and Cromarty', 'Auchtercairn', 'IV21 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1662, 'Fife', 'Auchterderran', 'KY5 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36');
INSERT INTO `postcodes` (`id`, `state`, `city`, `postcode`, `created_at`, `updated_at`) VALUES
(1663, 'Angus', 'Auchterhouse', 'DD3 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1664, 'Fife', 'Auchtermuchty', 'KY14 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1665, 'Fife', 'Auchtertool', 'KY2 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1666, 'Ross and Cromarty', 'Auchtertyre', 'IV40 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1667, 'Stirling and Falkirk', 'Auchtertyre', 'FK20 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1668, 'Stirling and Falkirk', 'Auchtubh', 'FK19 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1669, 'Caithness', 'Auckengill', 'KW1 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1670, 'South Yorkshire', 'Auckley', 'DN9 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1671, 'Greater Manchester', 'Audenshaw', 'M34 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1672, 'Cheshire', 'Audlem', 'CW3 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1673, 'Staffordshire', 'Audley', 'ST7 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1674, 'Essex', 'Audley End', 'CB11 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1675, 'Essex', 'Audley End', 'CO9 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1676, 'Suffolk', 'Audley End', 'IP29 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1677, 'County Antrim', 'Aughafatten', 'BT42 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1678, 'County Tyrone', 'Augher', 'BT77 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1679, 'Cumbria', 'Aughertree', 'CA7 1', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1680, 'County Tyrone', 'Aughnacloy', 'BT69 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1681, 'East Riding of Yorkshire', 'Aughton', 'YO42 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1682, 'Lancashire', 'Aughton', 'LA2 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1683, 'Lancashire', 'Aughton', 'L39 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1684, 'South Yorkshire', 'Aughton', 'S26 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1685, 'Wiltshire', 'Aughton', 'SN8 3', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1686, 'Lancashire', 'Aughton Park', 'L39 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1687, 'Durham', 'Aukside', 'DL12 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1688, 'Nairn', 'Auldearn', 'IV12 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1689, 'Herefordshire', 'Aulden', 'HR6 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1690, 'Dumfries', 'Auldgirth', 'DG2 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1691, 'City of Glasgow', 'Auldhouse', 'G43 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1692, 'Lanarkshire', 'Auldhouse', 'G75 9', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1693, 'Aberdeenshire', 'Auldyoch', 'AB53 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1694, 'Ross and Cromarty', 'Aultbea', 'IV22 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1695, 'Ross and Cromarty', 'Aultgrishan', 'IV21 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1696, 'Derbyshire', 'Ault Hucknall', 'S44 5', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1697, 'Sutherland', 'Aultiphurst', 'KW14 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1698, 'Sutherland', 'Aultivullin', 'KW14 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1699, 'Banffshire', 'Aultmore', 'AB55 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1700, 'Inverness', 'Ault-na-goire', 'IV2 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1701, 'Ross and Cromarty', 'Aultvaich', 'IV4 7', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1702, 'Inverness', 'Aultvoulin', 'PH41 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1703, 'Lincolnshire', 'Aunby', 'PE9 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1704, 'Devon', 'Aunk', 'EX15 2', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1705, 'Lincolnshire', 'Aunsby', 'NG34 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1706, 'Gloucestershire', 'Aust', 'BS35 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1707, 'Lincolnshire', 'Austendike', 'PE12 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1708, 'Lincolnshire', 'Austen Fen', 'LN11 0', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1709, 'Buckinghamshire', 'Austenwood', 'SL9 8', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1710, 'South Yorkshire', 'Austerfield', 'DN10 6', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1711, 'Greater Manchester', 'Austerlands', 'OL4 4', '2020-08-28 21:11:36', '2020-08-28 21:11:36'),
(1712, 'West Yorkshire', 'Austhorpe', 'LS15 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1713, 'Warwickshire', 'Austrey', 'CV9 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1714, 'North Yorkshire', 'Austwick', 'LA2 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1715, 'Lincolnshire', 'Authorpe', 'LN11 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1716, 'Lincolnshire', 'Authorpe Row', 'PE24 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1717, 'Wiltshire', 'Avebury', 'SN8 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1718, 'Wiltshire', 'Avebury Trusloe', 'SN8 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1719, 'Essex', 'Aveley', 'RM15 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1720, 'Lancashire', 'Avenham', 'PR1 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1721, 'Gloucestershire', 'Avening', 'GL8 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1722, 'Gloucestershire', 'Avening Green', 'GL12 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1723, 'Nottinghamshire', 'Averham', 'NG23 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1724, 'Nottinghamshire', 'Averham Park', 'NG23 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1725, 'Ross and Cromarty', 'Avernish', 'IV40 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1726, 'Greater London', 'Avery Hill', 'SE9 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1727, 'Devon', 'Aveton Gifford', 'TQ7 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1728, 'Inverness', 'Avielochan', 'PH22 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1729, 'Inverness', 'Aviemore', 'PH22 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1730, 'Berkshire', 'Avington', 'RG17 0', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1731, 'Hampshire', 'Avington', 'SO21 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1732, 'West Sussex', 'Avisford', 'BN18 0', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1733, 'Ross and Cromarty', 'Avoch', 'IV9 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1734, 'Hampshire', 'Avon', 'BH23 7', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1735, 'Wiltshire', 'Avon', 'SN15 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1736, 'Stirling and Falkirk', 'Avonbridge', 'FK1 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1737, 'Dorset', 'Avon Castle', 'BH24 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1738, 'Wiltshire', 'Avoncliff', 'BA15 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1739, 'Dorset', 'Avon Common', 'BH23 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1740, 'Warwickshire', 'Avon Dassett', 'CV47 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1741, 'Bristol', 'Avonmouth', 'BS11 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1742, 'Devon', 'Avonwick', 'TQ10 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1743, 'Hampshire', 'Awbridge', 'SO51 0', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1744, 'Gloucestershire', 'Awkley', 'BS32 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1745, 'Devon', 'Awliscombe', 'EX14 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1746, 'Gloucestershire', 'Awre', 'GL14 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1747, 'Nottinghamshire', 'Awsworth', 'NG16 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1748, 'Somerset', 'Axbridge', 'BS26 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1749, 'Somerset', 'Axeford Estate', 'TA20 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1750, 'Hampshire', 'Axford', 'RG25 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1751, 'Wiltshire', 'Axford', 'SN8 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1752, 'Hampshire', 'Axmansford', 'RG26 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1753, 'Devon', 'Axminster', 'EX13 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1754, 'Devon', 'Axmouth', 'EX12 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1755, 'Clwyd', 'Axton', 'CH8 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1756, 'Devon', 'Axtown', 'PL20 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1757, 'Tyne and Wear', 'Axwell Park', 'NE21 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1758, 'Kent', 'Aycliff', 'CT17 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1759, 'Durham', 'Aycliffe Village', 'DL5 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1760, 'Northumberland', 'Aydon', 'NE45 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1761, 'Northumberland', 'Aydon Road Estate', 'NE45 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1762, 'Durham', 'Aykley Heads', 'DH1 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1763, 'Gloucestershire', 'Aylburton', 'GL15 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1764, 'Gloucestershire', 'Aylburton Common', 'GL15 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1765, 'Northumberland', 'Ayle', 'CA9 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1766, 'Gloucestershire', 'Ayleford', 'GL15 4', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1767, 'Devon', 'Aylesbeare', 'EX5 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1768, 'Buckinghamshire', 'Aylesbury', 'HP20 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1769, 'Lincolnshire', 'Aylesby', 'DN37 7', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1770, 'Kent', 'Aylesford', 'ME20 7', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1771, 'Kent', 'Aylesham', 'CT3 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1772, 'Leicestershire', 'Aylestone', 'LE2 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1773, 'Herefordshire', 'Aylestone Hill', 'HR1 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1774, 'Leicestershire', 'Aylestone Park', 'LE2 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1775, 'Norfolk', 'Aylmerton', 'NR11 8', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1776, 'Norfolk', 'Aylsham', 'NR11 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1777, 'Herefordshire', 'Aylton', 'HR8 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1778, 'Gloucestershire', 'Aylworth', 'GL54 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1779, 'Herefordshire', 'Aymestrey', 'HR6 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1780, 'Northamptonshire', 'Aynho', 'OX17 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1781, 'Hertfordshire', 'Ayot Green', 'AL6 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1782, 'Hertfordshire', 'Ayot St Lawrence', 'AL6 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1783, 'Hertfordshire', 'Ayot St Peter', 'AL6 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1784, 'Ayrshire and Arran', 'Ayr', 'KA7 2', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1785, 'Hertfordshire', 'Ayres End', 'AL5 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1786, 'Shetland', 'Ayres of Selivoe', 'ZE2 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1787, 'Tyne and Wear', 'Ayre\'s Quay', 'SR4 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1788, 'North Yorkshire', 'Aysgarth', 'DL8 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1789, 'Devon', 'Ayshford', 'EX16 7', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1790, 'Cumbria', 'Ayside', 'LA11 6', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1791, 'Rutland', 'Ayston', 'LE15 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1792, 'Essex', 'Aythorpe Roding', 'CM6 1', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1793, 'Berwickshire', 'Ayton', 'TD14 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1794, 'Tyne and Wear', 'Ayton', 'NE38 0', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1795, 'Berwickshire', 'Ayton Castle', 'TD14 5', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1796, 'Shetland', 'Aywick', 'ZE2 9', '2020-08-28 21:11:37', '2020-08-28 21:11:37'),
(1797, 'North Yorkshire', 'Azerley', 'HG4 3', '2020-08-28 21:11:37', '2020-08-28 21:11:37');

-- --------------------------------------------------------

--
-- Table structure for table `qtn_optional_descriptions`
--

CREATE TABLE `qtn_optional_descriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oe_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oe_quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oe_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_oe_price` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `qtn_optional_descriptions`
--

INSERT INTO `qtn_optional_descriptions` (`id`, `uniqid`, `oe_description`, `oe_quantity`, `oe_price`, `total_oe_price`, `created_at`, `updated_at`) VALUES
(2, 'MPH05155048', 'test', '1', '500', '500', '2021-05-15 20:14:27', '2021-05-15 20:14:27'),
(3, 'MPH05172556', 'ddd', '1', '45', '45', '2021-05-17 19:47:22', '2021-05-17 19:47:22'),
(7, 'MPH05170107', 'test', '1', '300', '300', '2021-05-17 21:04:52', '2021-05-17 21:04:52'),
(8, 'MPH05171425', 'fg', '1', '300', '300', '2021-05-17 23:17:21', '2021-05-17 23:17:21'),
(9, 'MPH05184127', 'qdqwd', '12', '1212', '14544', '2021-05-18 22:44:53', '2021-05-18 22:44:53'),
(10, 'MPH05180322', 't', '1', '150', '150', '2021-05-18 23:11:12', '2021-05-18 23:11:12'),
(17, 'MPH05202357', 'test', '1', '300', '300', '2021-05-20 21:25:17', '2021-05-20 21:25:17'),
(19, 'MPH05204235', 'test', '2', '500', '1000', '2021-05-20 21:52:37', '2021-05-20 21:52:37'),
(21, 'MPH05204235', 'Opt2', '2', '200', '400', '2021-05-20 21:53:22', '2021-05-20 21:53:22'),
(24, 'MPH05200955', 'test', '1', '40', '40', '2021-05-20 22:14:27', '2021-05-20 22:14:27'),
(25, 'MPH05200955', 'test1', '2', '40', '80', '2021-05-20 22:14:47', '2021-05-20 22:14:47'),
(27, 'MPH06035329', '600 x 600 Rad', '2', '300', '600', '2021-06-04 00:56:43', '2021-06-04 00:56:43'),
(29, 'MPH06035329', '1000 x 600', '1', '300', '300', '2021-06-04 00:57:04', '2021-06-04 00:57:04'),
(30, 'MPH06035329', '1200 x 600', '1', '300', '300', '2021-06-04 00:57:11', '2021-06-04 00:57:11'),
(31, 'MPH06090452', 'test', '1', '100', '100', '2021-06-09 20:07:58', '2021-06-09 20:07:58');

-- --------------------------------------------------------

--
-- Table structure for table `qtn_radiator_measurement_locations`
--

CREATE TABLE `qtn_radiator_measurement_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_height` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_width` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rml_psd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `qtn_radiator_measurement_locations`
--

INSERT INTO `qtn_radiator_measurement_locations` (`id`, `uniqid`, `rml_location`, `rml_height`, `rml_width`, `rml_psd`, `created_at`, `updated_at`) VALUES
(18, '5f73175deb583', 'Bedroom 2', '300', '500', 'K1', '2020-09-29 23:46:53', '2020-09-29 23:46:53'),
(19, '5f73175deb583', 'Bedroom 2', '300', '500', 'K1', '2020-09-29 23:46:56', '2020-09-29 23:46:56'),
(20, '5f856e77702d1', 'Ensuite 3', '350', '1700', 'K1', '2020-10-13 21:39:20', '2020-10-13 21:39:20'),
(21, '5f856e77702d1', 'Ensuite 3', '350', '1700', 'K2', '2020-10-13 21:39:23', '2020-10-13 21:39:23'),
(22, '5fcdf817d68c3', 'Kitchen', '300', '1700', 'P+', '2020-12-07 22:11:57', '2020-12-07 22:11:57'),
(23, '5fcdf817d68c3', 'Kitchen', '300', '1700', 'P+', '2020-12-07 22:12:09', '2020-12-07 22:12:09'),
(30, '608a7f2c1f2f7', 'Kitchen', '300', '1200', 'K1', '2021-04-29 19:12:05', '2021-04-29 19:12:05');

-- --------------------------------------------------------

--
-- Table structure for table `qtn_thermostatic_radiator_valves`
--

CREATE TABLE `qtn_thermostatic_radiator_valves` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trv_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trv_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trv_quantity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `qtn_thermostatic_radiator_valves`
--

INSERT INTO `qtn_thermostatic_radiator_valves` (`id`, `uniqid`, `trv_size`, `trv_type`, `trv_quantity`, `created_at`, `updated_at`) VALUES
(13, '5f71bc1da484c', '4', '2', '1', '2020-09-28 23:12:29', '2020-09-28 23:12:29'),
(17, '5f856e77702d1', '3', '2', '2', '2020-10-13 21:39:26', '2020-10-13 21:39:26'),
(18, '5f856e77702d1', '3', '2', '3', '2020-10-13 21:39:29', '2020-10-13 21:39:29'),
(19, '608a93cb4c305', '2', '2', '1', '2021-04-29 20:41:51', '2021-04-29 20:41:51'),
(20, '608a93cb4c305', '1', '2', '3', '2021-04-29 20:41:56', '2021-04-29 20:41:56');

-- --------------------------------------------------------

--
-- Table structure for table `qtn_towel_rail_measurements`
--

CREATE TABLE `qtn_towel_rail_measurements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_height` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_width` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trm_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `qtn_towel_rail_measurements`
--

INSERT INTO `qtn_towel_rail_measurements` (`id`, `uniqid`, `trm_location`, `trm_height`, `trm_width`, `trm_color`, `created_at`, `updated_at`) VALUES
(19, '5f71bc1da484c', '2', '2', '2', '2', '2020-09-28 23:12:35', '2020-09-28 23:12:35'),
(20, '5f71c058c9ff1', '2', '2', '2', '2', '2020-09-28 23:29:11', '2020-09-28 23:29:11'),
(21, '5f71c20eab1b1', '2', '2', '2', '2', '2020-09-28 23:29:39', '2020-09-28 23:29:39'),
(24, '5f853ae12485c', '1', '1', '2', '2', '2020-10-13 17:59:07', '2020-10-13 17:59:07'),
(25, '5f853ae12485c', '1', '1', '2', '2', '2020-10-13 17:59:08', '2020-10-13 17:59:08'),
(31, '5f856e77702d1', '3', '2', '2', '2', '2020-10-13 21:39:34', '2020-10-13 21:39:34'),
(32, '5f856e77702d1', '3', '2', '2', '4', '2020-10-13 21:39:37', '2020-10-13 21:39:37');

-- --------------------------------------------------------

--
-- Table structure for table `qtn_towel_rail_valves`
--

CREATE TABLE `qtn_towel_rail_valves` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniqid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `torv_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `torv_angel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `torv_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `qtn_towel_rail_valves`
--

INSERT INTO `qtn_towel_rail_valves` (`id`, `uniqid`, `torv_type`, `torv_angel`, `torv_number`, `created_at`, `updated_at`) VALUES
(7, '5f71be4b083ff', '2', '3', '3', '2020-09-28 23:14:19', '2020-09-28 23:14:19'),
(8, '5f71c20eab1b1', '2', '2', '3', '2020-09-28 23:29:45', '2020-09-28 23:29:45'),
(9, '5f71c260034b0', '2', '3', '3', '2020-09-28 23:31:46', '2020-09-28 23:31:46'),
(10, '5f71c260034b0', '2', '3', '3', '2020-09-28 23:31:48', '2020-09-28 23:31:48'),
(12, '5f853ae12485c', '1', '2', '2', '2020-10-13 17:59:12', '2020-10-13 17:59:12'),
(15, '5f856e77702d1', '1', '2', '1', '2020-10-13 21:39:53', '2020-10-13 21:39:53');

-- --------------------------------------------------------

--
-- Table structure for table `radiator_requirements`
--

CREATE TABLE `radiator_requirements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `radiator_requirements`
--

INSERT INTO `radiator_requirements` (`id`, `name`, `created_at`, `updated_at`) VALUES
(4, 'No Radiators Required', '2020-09-25 18:44:27', '2020-09-25 18:44:27'),
(5, 'Radiators Required', '2020-09-25 18:44:36', '2020-09-25 18:44:36'),
(6, 'TRV\'s / Lockshields Required', '2020-09-25 18:44:42', '2020-09-25 18:44:42'),
(7, 'Towel Rails Required', '2020-09-25 18:44:48', '2020-09-25 18:44:48');

-- --------------------------------------------------------

--
-- Table structure for table `removals`
--

CREATE TABLE `removals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `removals`
--

INSERT INTO `removals` (`id`, `name`, `created_at`, `updated_at`) VALUES
(3, 'Old Boiler', '2020-09-18 18:15:14', '2020-09-18 18:15:14'),
(4, 'Hot Water Cylinder', '2020-09-18 18:15:20', '2020-09-18 18:15:20'),
(5, 'Cold Water Tank', '2020-09-18 18:15:26', '2020-09-18 18:15:26'),
(6, 'Feed and Expansion Tank', '2020-09-18 18:15:31', '2020-09-18 18:15:31'),
(7, 'Radiators', '2020-09-18 18:15:35', '2020-09-18 18:15:35'),
(8, 'Shower Pump', '2020-09-18 18:15:40', '2020-09-18 18:15:40'),
(9, 'Flue Liner', '2020-09-18 18:15:46', '2020-09-18 18:15:46'),
(10, 'Gas Back Boiler + Fire', '2020-09-18 18:15:51', '2020-09-18 18:15:51'),
(11, 'Solid Fuel Back Boiler + Fire', '2020-09-18 18:15:57', '2020-09-18 18:15:57'),
(12, 'Warm Air Unit', '2020-09-18 18:16:02', '2020-09-18 18:16:02'),
(13, 'Fireplace', '2020-09-18 18:16:06', '2020-09-18 18:16:06'),
(14, 'Multipoint Water Heater', '2020-09-18 18:16:11', '2020-09-18 18:16:11'),
(18, 'RemovalKL90', '2021-03-22 23:36:36', '2021-03-22 23:36:44');

-- --------------------------------------------------------

--
-- Table structure for table `scheduletasks`
--

CREATE TABLE `scheduletasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `time` time DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `assigned_user_id` int(255) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `scheduletasks`
--

INSERT INTO `scheduletasks` (`id`, `title`, `date`, `time`, `note`, `type`, `lead_id`, `user_id`, `assigned_user_id`, `status`, `created_at`, `updated_at`) VALUES
(5, 'test2', '2021-05-17 02:00:00', NULL, 'checking', 'meeting', 3, 1, 12, 'upcoming', '2021-05-17 06:00:00', '2021-05-17 06:00:00'),
(7, 'test3', '2021-05-22 00:30:00', NULL, 'check for test 3', 'meeting', 2, 1, 12, 'completed', '2021-05-22 04:30:00', '2021-05-22 04:30:00'),
(8, 'test10', '2021-05-18 03:00:00', NULL, 'check for test 10', 'meeting', 3, 1, 12, 'completed', '2021-05-18 19:50:40', '2021-05-21 14:31:24'),
(9, 'test11', '2021-05-19 02:30:00', NULL, 'check for test 11', 'meeting', 3, 1, 13, 'upcoming', '2021-05-19 06:30:00', '2021-05-19 06:30:00'),
(16, '12345', '2021-05-19 11:00:00', NULL, '12345', 'meeting', 6, 1, 13, 'upcoming', '2021-05-19 14:45:29', '2021-05-19 14:45:29'),
(17, '589', '2021-05-19 13:00:00', NULL, 'mmmmmmmmmm', 'meeting', 6, 1, 11, 'upcoming', '2021-05-19 14:47:32', '2021-05-19 14:47:32'),
(19, 'SC BY ALEX ADMIN', '2021-05-19 12:00:00', NULL, 'SC BY ALEX ADMIN', 'meeting', 6, 1, 11, 'upcoming', '2021-05-19 14:52:50', '2021-05-19 14:52:50'),
(20, 'SC BY ALEX SUAA', '2021-05-19 15:00:00', NULL, 'SC BY ALEX SUAA', 'meeting', 6, 11, 11, 'upcoming', '2021-05-19 14:54:29', '2021-05-19 14:54:29'),
(21, 'first', '2021-05-19 11:32:00', NULL, 'check for first', 'meeting', 8, 1, 13, 'completed', '2021-05-19 15:32:50', '2021-05-20 21:09:05'),
(23, 'avc', '2021-05-20 19:00:00', NULL, 'avc1', 'meeting', 10, 1, 10, 'upcoming', '2021-05-20 20:19:02', '2021-05-20 20:19:02'),
(27, 'SC BY ADMIN TODAY', '2021-05-20 20:00:00', NULL, 'SC BY ADMIN TODAY', 'meeting', 10, 1, 10, 'upcoming', '2021-05-20 21:11:33', '2021-05-20 21:11:33'),
(29, 'final', '2021-05-21 10:28:00', NULL, 'check final', 'meeting', 11, 1, 14, 'upcoming', '2021-05-21 14:28:00', '2021-05-21 14:28:00'),
(30, 'boiler lead app', '2021-05-25 14:17:00', NULL, 'broken boiler', 'meeting', 12, 1, 1, 'upcoming', '2021-05-24 22:47:51', '2021-05-24 22:47:51'),
(31, 'Sales app', '2021-06-01 10:30:00', NULL, 'fb\r\n1 bed 1 bath \r\nupgraded\r\n1 adult lives alone', 'meeting', 14, 1, 16, 'upcoming', '2021-06-01 19:01:44', '2021-06-01 19:01:44'),
(32, 'Sales app', '2021-06-01 13:00:00', NULL, 'b2\r\n4 bed 3 bath\r\nupgraded\r\n2 adults confirmed', 'meeting', 15, 1, 16, 'upcoming', '2021-06-01 19:04:02', '2021-06-01 19:04:02'),
(33, 'Sales app', '2021-06-01 13:00:00', NULL, 'CURRENTLY ONLY HAS A HOT WATER TANK - HE IS RUNNNG ELECTRIC HEATERS FROM ASDA', 'meeting', 16, 1, 15, 'upcoming', '2021-06-01 19:06:22', '2021-06-01 19:06:22'),
(34, 'Sales app', '2021-06-01 18:00:00', NULL, 'PCP\r\nBROKEN\r\n4 BED 2 BATH\r\n2 ADULTS CONFIRMED', 'meeting', 17, 1, 15, 'upcoming', '2021-06-01 19:08:38', '2021-06-01 19:08:38'),
(35, 'Sales app', '2021-06-02 10:30:00', NULL, 'B2u\r\n\r\ncurrent boiler is getting old so looking for prices to upgrade\r\n\r\nboth to be there', 'meeting', 19, 1, 15, 'upcoming', '2021-06-01 19:11:20', '2021-06-01 19:11:20'),
(36, 'Sales app', '2021-06-03 19:00:00', NULL, 'pcp\r\n4 bed 2 bath\r\nwants bosch\r\n2 adults confirmed', 'meeting', 20, 1, 15, 'upcoming', '2021-06-01 19:13:41', '2021-06-01 19:13:41'),
(37, 'Sales app', '2021-06-04 12:00:00', NULL, 'Pick up booked for fri 4th', 'meeting', 21, 1, 15, 'upcoming', '2021-06-01 19:15:51', '2021-06-01 19:15:51'),
(38, 'checking1', '2021-06-09 17:00:00', NULL, 'checking1 checking1', 'meeting', 7, 1, 14, 'completed', '2021-06-09 20:22:27', '2021-06-16 18:28:01');

-- --------------------------------------------------------

--
-- Table structure for table `selectradiocheckboxchoices`
--

CREATE TABLE `selectradiocheckboxchoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bolt` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `select` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT 0,
  `user_id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `title`, `slug`, `order`, `user_id`, `lead_id`, `created_at`, `updated_at`) VALUES
(1, 'IDEAL PROPOSAL', 'ideal-proposal', 0, 0, 0, NULL, NULL),
(2, 'FOLLOW UP', 'follow-up', 0, 0, 0, NULL, NULL),
(3, 'NEGOTIATION', 'negotiation', 0, 0, 0, NULL, NULL),
(4, 'LOST', 'lost', 0, 0, 0, NULL, NULL),
(5, 'WON', 'won', 0, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT 0,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lead_id` int(11) NOT NULL,
  `userAssign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `amount`, `order`, `user_id`, `status_id`, `created_at`, `updated_at`, `lead_id`, `userAssign_id`) VALUES
(1, 'DEAL BY ADMIN', 'DEAL BY ADMIN', 100.00, 0, 1, 5, '2021-05-19 15:02:21', '2021-05-21 14:26:56', 6, 11),
(2, 'ggg', '566', 1000.00, 0, 1, 5, '2021-05-19 15:25:35', '2021-05-21 14:26:58', 8, 13),
(3, 'SC BY ALEX SUAA', 'SC BY ALEX SUAA', 100.00, 0, 10, 3, '2021-05-19 16:32:03', '2021-05-21 14:27:09', 5, 10),
(4, 'SC BY ALEX SUAA1', 'SC BY ALEX SUAA1', 200.00, 0, 10, 3, '2021-05-19 16:38:57', '2021-05-21 14:27:04', 2, 10),
(5, 'agg', 'vsdvsdv', 400000.00, 0, 1, 5, '2021-05-20 21:11:18', '2021-05-21 14:26:50', 7, 14),
(6, 'vvs', 'abc', 500.00, 0, 14, 5, '2021-05-21 14:12:47', '2021-05-21 14:26:53', 11, 14),
(7, 'boiler app', 'broken boiler on hold', 2800.00, 0, 1, 5, '2021-05-24 22:50:44', '2021-05-24 22:50:56', 12, 1),
(8, 'ggg', 'iiiiiiiiiii', 1000.00, 0, 1, 4, '2021-06-09 20:25:26', '2021-06-09 20:26:36', 7, 14);

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `publish` int(11) NOT NULL DEFAULT 1,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pslug` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `created_at`, `updated_at`, `publish`, `title`, `body`, `pslug`) VALUES
(4, '2020-09-02 01:11:04', '2020-09-02 01:11:04', 0, 'testing purpose', '<p>{{lead.name}} for testing</p>', 'new-template'),
(5, '2020-12-03 19:59:11', '2020-12-03 19:59:11', 0, NULL, NULL, NULL),
(6, '2021-03-22 19:22:29', '2021-03-22 19:22:29', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userrole` int(11) NOT NULL,
  `colortype` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isAdmin` int(11) NOT NULL,
  `acinstatus` int(11) DEFAULT NULL,
  `userprofilepic` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `email_verifycode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passreset_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `location`, `username`, `userrole`, `colortype`, `isAdmin`, `acinstatus`, `userprofilepic`, `email_verified_at`, `email_verifycode`, `password`, `passreset_code`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'david parker', 'david@gmail.com', NULL, NULL, 'david parker', 1, '#DC143C', 1, 1, NULL, NULL, NULL, '$2y$10$RR6pnirONqSnRsRLu64N1eyUCZNxwM5PJtmUpVaTOS0XGVTrWzzDu', NULL, NULL, '2021-04-24 13:54:21', '2021-04-24 13:54:21'),
(10, 'steve smith', 'steve@gmail.com', NULL, NULL, 'steve smith', 2, '#c810d5', 1, 1, NULL, NULL, NULL, '$2y$10$y9ix2AhfIxnqH.PybrbUUOfPfZmT8ufgf1KMg4.joZTC.Almd.ooC', NULL, NULL, '2021-05-15 18:55:09', '2021-05-15 18:55:09'),
(11, 'alex', 'alex@gmail.com', NULL, NULL, 'alex smith', 2, '#56e7fb', 1, 1, 'public/storage/uploadimage/1621511223157.jpg', NULL, NULL, '$2y$10$CP9JkFildzk1MmFFZCvTAOJOzj4s856lnWx9YZvoKsLkqehQX5zWe', NULL, NULL, '2021-05-15 19:17:35', '2021-05-20 21:17:03'),
(12, 'louis parker', 'louis@gmail.com', NULL, NULL, 'louis parker', 2, '#137cd8', 1, 1, NULL, NULL, NULL, '$2y$10$5I9cwUUblWH33Y6LFIjqcu4C8yKOzg3Ib/lxO9d0bFa/rpilOnksS', NULL, NULL, '2021-05-17 19:41:59', '2021-05-17 19:41:59'),
(13, 'james anderson', 'james@gmail.com', NULL, NULL, 'james@gmail.com', 2, '#dd720e', 1, 1, NULL, NULL, NULL, '$2y$10$1Gy60SSFIxoRVWjhavTIi.byvyMphcxUSlseu4q.6fOHyYHTMcwaK', NULL, NULL, '2021-05-18 19:43:10', '2021-05-18 19:43:10'),
(14, 'Nathan lyon', 'nathan@gmail.com', NULL, NULL, 'Nathan lyon', 2, '#0eec50', 1, 1, NULL, NULL, NULL, '$2y$10$emBfhB2jP6j6wghdKeImSemJmIEAKjH91Bsj0zsjzpnH1.Gw.Nu0a', NULL, NULL, '2021-05-20 20:50:06', '2021-05-20 20:50:06'),
(15, 'Neil Collett', 'neilc1202@icloud.com', NULL, NULL, 'Neil Collett', 2, '#da4fe3', 1, 1, NULL, NULL, NULL, '$2y$10$KoSlBMs/3vwnfw0HhvuJWOLnvbvLJd6fItRAjJhcqc3TbstQh.7yu', NULL, NULL, '2021-06-01 18:57:22', '2021-06-01 18:57:22'),
(16, 'David Scott', 'arc@cloybank.net', NULL, NULL, 'David Scott', 2, '#e3d04f', 1, 1, NULL, NULL, NULL, '$2y$10$93L/rhrBClaClSx5LWRQX.ztvO6hciXwc3wk/acNmGOo1bXG9DwY.', NULL, NULL, '2021-06-01 18:57:51', '2021-06-01 18:57:51'),
(17, 'Gavin Brown', 'gavin8264@gmail.com', NULL, NULL, 'Gavin Brown', 2, '#4fe3da', 1, 1, NULL, NULL, NULL, '$2y$10$JhEEsq9dlXHpagDp7rfwneI2iPrbcIA4UY9tuS2e61jURyQ5DzDBC', NULL, NULL, '2021-06-01 18:58:14', '2021-06-01 18:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `vented_cylinder_dimensions`
--

CREATE TABLE `vented_cylinder_dimensions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vented_cylinder_dimensions`
--

INSERT INTO `vented_cylinder_dimensions` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(7, '(1x) 400x900 Staineless Steel Indirect Cylinder (96 LITRES)', 0, '2020-09-22 23:27:05', '2020-09-22 23:27:05'),
(8, '(1x) 450x900 Staineless Steel Indirect Cylinder (117 LITRES)', 0, '2020-09-22 23:27:16', '2020-09-22 23:27:16'),
(9, '(1x) 400x1050 Staineless Steel Indirect Cylinder (114 LITRES)', 90, '2020-09-22 23:27:23', '2021-04-17 14:38:48'),
(10, '(1x) 450x1050 Staineless Steel Indirect Cylinder (140 LITRES)', 0, '2020-09-22 23:27:35', '2020-09-22 23:27:35'),
(11, '(1x) 450x1200 Staineless Steel Indirect Cylinder (162 LITRES)', 0, '2020-09-22 23:27:41', '2020-09-22 23:27:41'),
(12, '(1x) 450x900 Direct Cylinder (117 LITRES)', 78, '2020-09-22 23:27:48', '2021-03-23 17:53:14');

-- --------------------------------------------------------

--
-- Table structure for table `widths`
--

CREATE TABLE `widths` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `widths`
--

INSERT INTO `widths` (`id`, `name`, `created_at`, `updated_at`) VALUES
(4, '300', '2020-10-14 21:29:58', '2020-10-14 21:29:58'),
(5, '400', '2020-10-14 21:30:00', '2020-10-14 21:30:00'),
(6, '500', '2020-10-14 21:30:01', '2020-10-14 21:30:01'),
(7, '600', '2020-10-14 21:30:03', '2020-10-14 21:30:03'),
(8, '700', '2020-10-14 21:30:05', '2020-10-14 21:30:05'),
(9, '800', '2020-10-14 21:30:07', '2020-10-14 21:30:07'),
(10, '900', '2020-10-14 21:30:09', '2020-10-14 21:30:09'),
(11, '1000', '2020-10-14 21:30:11', '2020-10-14 21:30:11'),
(12, '1100', '2020-10-14 21:30:13', '2020-10-14 21:30:13'),
(13, '123', '2020-10-14 21:30:15', '2021-03-23 18:58:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `a_c_m_s`
--
ALTER TABLE `a_c_m_s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boilerchoises`
--
ALTER TABLE `boilerchoises`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boilers`
--
ALTER TABLE `boilers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boilertypechildrens`
--
ALTER TABLE `boilertypechildrens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boilertypes`
--
ALTER TABLE `boilertypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boiler_controls`
--
ALTER TABLE `boiler_controls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boltschoosens`
--
ALTER TABLE `boltschoosens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bolt_ons`
--
ALTER TABLE `bolt_ons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calls`
--
ALTER TABLE `calls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `call_note`
--
ALTER TABLE `call_note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `chemical_system_treatments`
--
ALTER TABLE `chemical_system_treatments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `condensate_terminations`
--
ALTER TABLE `condensate_terminations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_lists`
--
ALTER TABLE `contact_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cupboard_need_alts`
--
ALTER TABLE `cupboard_need_alts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_boiler_locations`
--
ALTER TABLE `current_boiler_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_boiler_types`
--
ALTER TABLE `current_boiler_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_flues`
--
ALTER TABLE `current_flues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deals`
--
ALTER TABLE `deals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `electrical_work_requireds`
--
ALTER TABLE `electrical_work_requireds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `existing_showers`
--
ALTER TABLE `existing_showers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flue_kits`
--
ALTER TABLE `flue_kits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flue_kit_details`
--
ALTER TABLE `flue_kit_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gas_supply_lengths`
--
ALTER TABLE `gas_supply_lengths`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gas_supply_requirements`
--
ALTER TABLE `gas_supply_requirements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `heights`
--
ALTER TABLE `heights`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_quotations`
--
ALTER TABLE `lead_quotations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `magnetic_system_filters`
--
ALTER TABLE `magnetic_system_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newfule_types`
--
ALTER TABLE `newfule_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_boiler_types`
--
ALTER TABLE `new_boiler_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_controls`
--
ALTER TABLE `new_controls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_flues`
--
ALTER TABLE `new_flues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_flue_locations`
--
ALTER TABLE `new_flue_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `optional_extras`
--
ALTER TABLE `optional_extras`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parking_requirements`
--
ALTER TABLE `parking_requirements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `postcodes`
--
ALTER TABLE `postcodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qtn_optional_descriptions`
--
ALTER TABLE `qtn_optional_descriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qtn_radiator_measurement_locations`
--
ALTER TABLE `qtn_radiator_measurement_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qtn_thermostatic_radiator_valves`
--
ALTER TABLE `qtn_thermostatic_radiator_valves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qtn_towel_rail_measurements`
--
ALTER TABLE `qtn_towel_rail_measurements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qtn_towel_rail_valves`
--
ALTER TABLE `qtn_towel_rail_valves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `radiator_requirements`
--
ALTER TABLE `radiator_requirements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `removals`
--
ALTER TABLE `removals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scheduletasks`
--
ALTER TABLE `scheduletasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `selectradiocheckboxchoices`
--
ALTER TABLE `selectradiocheckboxchoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vented_cylinder_dimensions`
--
ALTER TABLE `vented_cylinder_dimensions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widths`
--
ALTER TABLE `widths`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `a_c_m_s`
--
ALTER TABLE `a_c_m_s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `boilerchoises`
--
ALTER TABLE `boilerchoises`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `boilers`
--
ALTER TABLE `boilers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `boilertypechildrens`
--
ALTER TABLE `boilertypechildrens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `boilertypes`
--
ALTER TABLE `boilertypes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=382;

--
-- AUTO_INCREMENT for table `boiler_controls`
--
ALTER TABLE `boiler_controls`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `boltschoosens`
--
ALTER TABLE `boltschoosens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `bolt_ons`
--
ALTER TABLE `bolt_ons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `calls`
--
ALTER TABLE `calls`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `call_note`
--
ALTER TABLE `call_note`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `chemical_system_treatments`
--
ALTER TABLE `chemical_system_treatments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `condensate_terminations`
--
ALTER TABLE `condensate_terminations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `contact_lists`
--
ALTER TABLE `contact_lists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cupboard_need_alts`
--
ALTER TABLE `cupboard_need_alts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `current_boiler_locations`
--
ALTER TABLE `current_boiler_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `current_boiler_types`
--
ALTER TABLE `current_boiler_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `current_flues`
--
ALTER TABLE `current_flues`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `deals`
--
ALTER TABLE `deals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `electrical_work_requireds`
--
ALTER TABLE `electrical_work_requireds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `existing_showers`
--
ALTER TABLE `existing_showers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flue_kits`
--
ALTER TABLE `flue_kits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `flue_kit_details`
--
ALTER TABLE `flue_kit_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gas_supply_lengths`
--
ALTER TABLE `gas_supply_lengths`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `gas_supply_requirements`
--
ALTER TABLE `gas_supply_requirements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `heights`
--
ALTER TABLE `heights`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `lead_quotations`
--
ALTER TABLE `lead_quotations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `magnetic_system_filters`
--
ALTER TABLE `magnetic_system_filters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `newfule_types`
--
ALTER TABLE `newfule_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `new_boiler_types`
--
ALTER TABLE `new_boiler_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `new_controls`
--
ALTER TABLE `new_controls`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `new_flues`
--
ALTER TABLE `new_flues`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `new_flue_locations`
--
ALTER TABLE `new_flue_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

--
-- AUTO_INCREMENT for table `optional_extras`
--
ALTER TABLE `optional_extras`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parking_requirements`
--
ALTER TABLE `parking_requirements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `postcodes`
--
ALTER TABLE `postcodes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1798;

--
-- AUTO_INCREMENT for table `qtn_optional_descriptions`
--
ALTER TABLE `qtn_optional_descriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `qtn_radiator_measurement_locations`
--
ALTER TABLE `qtn_radiator_measurement_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `qtn_thermostatic_radiator_valves`
--
ALTER TABLE `qtn_thermostatic_radiator_valves`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `qtn_towel_rail_measurements`
--
ALTER TABLE `qtn_towel_rail_measurements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `qtn_towel_rail_valves`
--
ALTER TABLE `qtn_towel_rail_valves`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `radiator_requirements`
--
ALTER TABLE `radiator_requirements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `removals`
--
ALTER TABLE `removals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `scheduletasks`
--
ALTER TABLE `scheduletasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `selectradiocheckboxchoices`
--
ALTER TABLE `selectradiocheckboxchoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `vented_cylinder_dimensions`
--
ALTER TABLE `vented_cylinder_dimensions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `widths`
--
ALTER TABLE `widths`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
